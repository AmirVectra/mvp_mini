# display_cli.py

import sys
import argparse


## for packaging
from .deserialize import convertJSONToDrawViewsDict
from .views_cluster.cluster import ViewCluster
from .views_cluster.cluster_visualizer import displayViewClusterObject,displayViews

## for developer
# from drawview_root.src.drawview.deserialize import convertJSONToDrawViewsDict
# from drawview_root.src.drawview.views_cluster.cluster import ViewCluster
# from drawview_root.src.drawview.views_cluster.cluster_visualizer import displayViewClusterObject


def build_view_cluster_from_dict(data_dict) -> ViewCluster:
    """
    Convert the dictionary from convertDrawViewJSONtoDict
    into a ViewCluster object.
    """

    view_cluster = ViewCluster(data_dict)
    return view_cluster


def main1():
    parser = argparse.ArgumentParser(
        description="Visualize Views from DrawView JSON file"
    )
    parser.add_argument(
        "json_path",
        type=str,
        help="Path to the DrawView JSON file"
    )

    args = parser.parse_args()
    json_path = args.json_path

    print(f"[INFO] Loading JSON from: {json_path}")

    try:
        data_dict = convertJSONToDrawViewsDict(json_path)
    except Exception as e:
        print(f"[ERROR] Failed to read/convert JSON: {e}")
        sys.exit(1)

    try:
        view_cluster = build_view_cluster_from_dict(data_dict)
    except Exception as e:
        print(f"[ERROR] Failed to build Views: {e}")
        sys.exit(1)

    print("[INFO] Rendering Views...")
    displayViewClusterObject(view_cluster)

def main2():
    parser = argparse.ArgumentParser(
        description="Visualize Views from DrawView JSON file"
    )
    parser.add_argument(
        "json_path",
        type=str,
        help="Path to the DrawView JSON file"
    )

    args = parser.parse_args()
    json_path = args.json_path

    print(f"[INFO] Loading JSON from: {json_path}")

    try:
        data_dict = convertJSONToDrawViewsDict(json_path)
    except Exception as e:
        print(f"[ERROR] Failed to read/convert JSON: {e}")
        sys.exit(1)


    print("[INFO] Rendering Views...")
    displayViews(viewsIdObjectDict=data_dict)