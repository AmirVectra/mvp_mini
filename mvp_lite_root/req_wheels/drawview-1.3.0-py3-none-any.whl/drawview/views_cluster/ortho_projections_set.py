import copy

from vct_o_geom.vector import Vector

from drawview.views_cluster.cluster import ViewCluster
from drawview.views_cluster.cluster_visualizer import displayViewsCluster
from drawview.deserialize import convertJSONToDrawViewsDict




# defining all the valid relative orders from center view
VALID_RELATIVE_ORDERS=['R','L','T','B']

# defining the center view default relative order
CENTER_VIEW_ABBR='CTR'

def filterViewsWith_CenterView_NoRelativeOrder(viewsIdObjectDict):

    viewNames=[viewObject.view_name for viewObject in viewsIdObjectDict.values()]

    viewsIdObjectDictWithParentViewOnly = {view_id:view for view_id, view in viewsIdObjectDict.items() if
                                     ( view.rel_order in [None,""] )and (view.rel_order not in VALID_RELATIVE_ORDERS ) and (view.ctr_view  in viewNames)}
    return viewsIdObjectDictWithParentViewOnly


def filterViewsWith_RelativeOrder_NoCenterView(viewsIdObjectDict):
    viewNames = [viewObject.view_name for viewObject in viewsIdObjectDict.values()]
    viewsIdObjectDictWithRelativeOrderOnly= {view_id:view for view_id, view in viewsIdObjectDict.items()
                                           if  (view.rel_order  in VALID_RELATIVE_ORDERS) and ( (view.ctr_view  in [None,""])or (view.ctr_view not in viewNames) )}
    return viewsIdObjectDictWithRelativeOrderOnly


def filterViewsWith_NoRelativeOrder_NoCenterView(viewsIdObjectDict):
    viewNames = [viewObject.view_name for viewObject in viewsIdObjectDict.values()]
    viewsIdObjectDictWithRelativeOrderOnly= {view_id:view for view_id, view in viewsIdObjectDict.items()
                                           if  (view.rel_order not in VALID_RELATIVE_ORDERS) and ( (view.ctr_view  in [None,""])or (view.ctr_view not in viewNames) )}
    return viewsIdObjectDictWithRelativeOrderOnly


def filterViewsWith_UnknownRelativeOrders(viewsIdObjectDict):

    allValidRelativeOrders=[CENTER_VIEW_ABBR]
    allValidRelativeOrders.extend(VALID_RELATIVE_ORDERS)


    viewsIdObjectDictWithRelativeOrderOnly= {view_id:view for view_id, view in viewsIdObjectDict.items()
                                           if  view.rel_order not in allValidRelativeOrders }
    return viewsIdObjectDictWithRelativeOrderOnly

def filterStandAloneViews(viewsIdObjectDict):
    return filterViewsWith_NoRelativeOrder_NoCenterView(viewsIdObjectDict)

def filterPartialStandAloneViews(viewsIdObjectDict):
    partialViewsIdObjectDict={}

    result1= filterViewsWith_RelativeOrder_NoCenterView(viewsIdObjectDict)

    result2= filterViewsWith_CenterView_NoRelativeOrder(viewsIdObjectDict)

    result3= filterViewsWith_NoRelativeOrder_NoCenterView(viewsIdObjectDict)

    result4= filterViewsWith_UnknownRelativeOrders(viewsIdObjectDict)


    partialViewsIdObjectDict|=result1
    partialViewsIdObjectDict|=result2
    partialViewsIdObjectDict|=result3
    partialViewsIdObjectDict|=result4

    return partialViewsIdObjectDict

def filterRelatedViews(viewsIdObjectDict):
    originalViewsIdObjectDict=viewsIdObjectDict.copy()
    partialViewsIdObjectDict=filterPartialStandAloneViews(viewsIdObjectDict)

    relatedViewsIdObjectDict = {k: originalViewsIdObjectDict[k] for k,v in originalViewsIdObjectDict.items() if k not in partialViewsIdObjectDict.keys()}

    return relatedViewsIdObjectDict






class OrthographicProjectionSet:
    """
    Handles positioning and attachment of orthographic projection views.

    This class arranges views relative to one another based on their
    orthographic relationship (Left, Right, Top, Bottom, etc.).
    The placement calculations consider:

    - View geometry (L1, L2 dimensions)
    - Bounding rectangle offsets
    - User-defined center view margin

    Parameters
    ----------
    viewsIdObjectDict : dict
        Dictionary containing view IDs mapped to view objects.

    MVP_Config : dict, optional
        Configuration dictionary.

        Supported keys:
        - ctrViewMargin : float
            Gap maintained between attached views.
    """

    def __init__(self, viewsIdObjectDict: dict, MVP_Config: dict = None):

        self.viewsIdObjectDict = viewsIdObjectDict
        self.OPS_Pairs = []

        if MVP_Config is None:
            MVP_Config = {'ctrViewMargin': 0}
        else:
            MVP_Config = dict(MVP_Config)  # Prevent external modification

        self.ctrViewMargin = MVP_Config.get('ctrViewMargin', 0)

        self._arrangeMVP()

    def zoneOffset(self, viewObject, zone):
        """
        Compute offset between a view's bounding rectangle and actual geometry
        along a specified zone.

        Parameters
        ----------
        viewObject : DrawView
            View whose offset is to be calculated.

        zone : str
            Zone identifier.

            Supported values:
            - 'L' : Left
            - 'R' : Right
            - 'T' : Top
            - 'B' : Bottom

        Returns
        -------
        float
            Distance between the corresponding basis points of the
            bounding rectangle and the actual view geometry.
        """

        viewBRect = viewObject.boundingRectangle()
        zoneOffset = 0

        basis_map = {
            'L': 'CL',
            'R': 'CR',
            'T': 'CT',
            'B': 'CB'
        }

        if zone in basis_map:

            basis = basis_map[zone]

            # Corresponding basis point on bounding rectangle
            viewBRect_pt = viewBRect.basis_point(basis)

            # Corresponding basis point on actual view geometry
            viewObject_pt = viewObject.basis_point(basis)

            if zone in ['L', 'R']:
                zoneOffset = abs(viewBRect_pt[0] - viewObject_pt[0])

            elif zone in ['T', 'B']:
                zoneOffset = abs(viewBRect_pt[1] - viewObject_pt[1])

        return zoneOffset

    def getTopVExtentFromCenter(self, viewObject):
        """
        Compute top vertical extent from view center.

        The extent includes:
        - Distance from geometry to bounding rectangle.
        - Half view height.

        Parameters
        ----------
        viewObject : DrawView

        Returns
        -------
        float
            Top extent measured from view center.
        """

        return self.zoneOffset(viewObject, 'T') + viewObject.L2 / 2

    def getBottomVExtentFromCenter(self, viewObject):
        """
        Compute bottom vertical extent from view center.

        Returns
        -------
        float
            Bottom extent measured from view center.
        """

        return self.zoneOffset(viewObject, 'B') + viewObject.L2 / 2

    def getRightHExtentFromCenter(self, viewObject):
        """
        Compute right horizontal extent from view center.

        Returns
        -------
        float
            Right extent measured from view center.
        """

        return self.zoneOffset(viewObject, 'R') + viewObject.L1 / 2

    def getLeftHExtentFromCenter(self, viewObject):
        """
        Compute left horizontal extent from view center.

        Returns
        -------
        float
            Left extent measured from view center.
        """

        return self.zoneOffset(viewObject, 'L') + viewObject.L1 / 2

    ###----------- Orthogonal  View Attachment Methods ###############
    def attachLeftView(self, parentView, leftChildView):
        """
        Attach a child view to the left side of a parent view.

        The child view is aligned vertically with the parent's center and
        positioned horizontally based on the extents of both views and
        configured margin.

        Parameters
        ----------
        parentView : DrawView
            Reference view.

        leftChildView : DrawView
            View to be placed on the left.

        Returns
        -------
        DrawView
            Updated child view.
        """
        relativeView=leftChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY =  ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction

        xDistanceFromCenterView=self.getLeftHExtentFromCenter(ctrView) + self.ctrViewMargin +self.getRightHExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx=ctrView_CTRCoordX-xDistanceFromCenterView
        # adjust relative view's center point in Y-direction which will be same as parent view's center point'
        leftView_TargetCTRy = ctrView_CTRCoordY

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachRightView(self, parentView, rightChildView):
        """
        Attach a child view to the right side of a parent view.

        Returns
        -------
        DrawView
            Updated child view.
        """
        relativeView=rightChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction
        xDistanceFromCenterView = self.getRightHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getLeftHExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX + xDistanceFromCenterView
        # adjust relative view's center point in Y-direction which will be same as parent view's center point'
        leftView_TargetCTRy = ctrView_CTRCoordY

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachTopView(self, parentView, topChildView):
        """
        Attach a child view above a parent view.

        Returns
        -------
        DrawView
            Updated child view.
        """
        relativeView=topChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust relative view's center point in X-direction which will be same as parent view's center point'
        leftViewTargetCTRx = ctrView_CTRCoordX
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY + yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachBottomView(self, parentView, bottomChildView):
        """
        Attach a child view below a parent view.

        Returns
        -------
        DrawView
            Updated child view.
        """
        relativeView=bottomChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust relative view's center point in X-direction which will be same as parent view's center point'
        leftViewTargetCTRx = ctrView_CTRCoordX
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY - yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    ###----------- Diagonal View Attachment Methods ###############
    def attachRightTopView(self, parentView, rightTopChildView):
        """
        Attach a child view to the top-right of the parent view.

        Returns
        -------
        DrawView
            Updated child view.
        """

        relativeView = rightTopChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction
        xDistanceFromCenterView = self.getRightHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getLeftHExtentFromCenter(relativeView)


        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX + xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY + yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachRightBottomView(self, parentView, rightBottomChildView):
        """
        Attach a child view to the bottom-right of the parent view.

        Returns
        -------
        DrawView
            Updated child view.
        """

        relativeView = rightBottomChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction
        xDistanceFromCenterView = self.getRightHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getLeftHExtentFromCenter(relativeView)

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX + xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY - yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachLeftBottomView(self, parentView, leftBottomChildView):
        """
        Attach a child view to the bottom-left of the parent view.

        Returns
        -------
        DrawView
            Updated child view.
        """
        relativeView = leftBottomChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction

        xDistanceFromCenterView = self.getLeftHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getRightHExtentFromCenter(relativeView)

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX - xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY - yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachLeftTopView(self, parentView, leftTopChildView):
        """
        Attach a child view to the top-left of the parent view.

        Returns
        -------
        DrawView
            Updated child view.
        """
        relativeView = leftTopChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction

        xDistanceFromCenterView = self.getLeftHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getRightHExtentFromCenter(relativeView)

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX - xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY + yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachViewBasedOnRelativeOrder(self, centerView, relativeView):
        """
        Attach a view relative to a center view based on its
        relative-order attribute.

        Supported relations:
        - L : Left
        - R : Right
        - T : Top
        - B : Bottom

        Parameters
        ----------
        centerView : DrawView
            Reference view.

        relativeView : DrawView
            View containing rel_order attribute.

        Returns
        -------
        DrawView
            Attached and repositioned view.
        """

        relativeOrder_AttachChildView = {
            'L': self.attachLeftView,
            'R': self.attachRightView,
            'T': self.attachTopView,
            'B': self.attachBottomView,
        }

        return relativeOrder_AttachChildView[
            relativeView.rel_order
        ](centerView, relativeView)

    #########-------- METHODS FOR VALIDATION BEFORE OPS is formed -------------- ##########
    def validateSingleCenterView(self, opsViews):
        """
        Ensure exactly one center view exists in the OPS.

        The center view acts as the root node of the projection graph.
        It is identified by:

            view.view_name == view.ctr_view

        Examples
        --------
        Valid:
            C1 -> C1

        Invalid:
            No center view present.

        Invalid:
            Multiple center views present.

        Parameters
        ----------
        opsViews : dict[int, DrawView]

        Raises
        ------
        ValueError
            If the number of center views is not exactly one.
        """

        centerViews = [
            view
            for view in opsViews.values()
            if view.view_name == view.ctr_view
        ]

        if len(centerViews) != 1:
            raise ValueError(
                f"Expected exactly one center view, "
                f"found {len(centerViews)}."
            )

    def validateRelativeAssignments(self, opsViews):
        """
        Ensure that no two views occupy the same relative position
        with respect to the same parent view.

        This validation prevents multiple views from being assigned
        to the same logical location around a parent view.

        Example
        -------
        Invalid:

            C1
             ├── R1 (R)
             └── R2 (R)

        because both views attempt to occupy the Right position
        of the same parent.

        Parameters
        ----------
        opsViews : dict[int, DrawView]

        Raises
        ------
        ValueError
            If multiple views are assigned to the same
            (CTR_VIEW, REL_ORDER) pair.
        """

        occupiedPositions = {}

        for view in opsViews.values():

            # Skip the root center view.
            if view.view_name == view.ctr_view:
                continue

            positionKey = (
                view.ctr_view,
                view.rel_order
            )

            if positionKey in occupiedPositions:
                existingView = occupiedPositions[positionKey]

                raise ValueError(
                    f"Views '{existingView}' and "
                    f"'{view.view_name}' are both assigned to "
                    f"'{view.rel_order}' of '{view.ctr_view}'."
                )

            occupiedPositions[positionKey] = view.view_name

    def validateNoCycles(self, opsViews):
        """
        Ensure that the OPS parent-child relationships do not
        contain cyclic dependencies.

        A valid OPS must form an acyclic graph so that view
        placement can be resolved unambiguously.

        Example
        -------
        Invalid:

            C1 -> R1
            R1 -> R2
            R2 -> C1

        because traversal eventually returns to a previously
        visited node.

        Parameters
        ----------
        opsViews : dict[int, DrawView]

        Raises
        ------
        ValueError
            If a cyclic dependency is detected.
        """

        # Build adjacency list:
        # Parent View -> Child Views
        graph = {}

        for view in opsViews.values():

            # Skip center/root view.
            if view.view_name == view.ctr_view:
                continue

            graph.setdefault(
                view.ctr_view,
                []
            ).append(view.view_name)

        visited = set()
        recursionStack = set()

        def dfs(viewName):
            """
            Depth-first traversal used to detect cycles.

            Parameters
            ----------
            viewName : str

            Returns
            -------
            bool
                True if a cycle is found.
            """

            visited.add(viewName)
            recursionStack.add(viewName)

            for childViewName in graph.get(viewName, []):

                # Explore unvisited child.
                if childViewName not in visited:

                    if dfs(childViewName):
                        return True

                # Child already exists in the current DFS path.
                elif childViewName in recursionStack:
                    return True

            recursionStack.remove(viewName)
            return False

        # Check every disconnected component.
        for viewName in graph:

            if viewName not in visited:

                if dfs(viewName):
                    raise ValueError(
                        "Cycle detected in OPS view relationships."
                    )

    def validateCTRViewReferences(self, opsViews):
        """
        Ensure that every non-center view references a valid
        parent view through its CTR_VIEW attribute.

        Every view that is not a center view must point to an
        existing view within the same OPS.

        Example
        -------
        Valid:

            C1 -> C1
            R1 -> C1
            R2 -> R1

        Invalid:

            C1 -> C1
            R1 -> XYZ

        because view 'XYZ' does not exist in the OPS.

        Parameters
        ----------
        opsViews : dict[int, DrawView]

        Raises
        ------
        ValueError
            If a CTR_VIEW references a non-existent view.
        """

        # Collect all available view names.
        validViewNames = {
            view.view_name
            for view in opsViews.values()
        }

        for view in opsViews.values():

            # Skip root center view.
            if view.view_name == view.ctr_view:
                continue

            if view.ctr_view not in validViewNames:
                raise ValueError(
                    f"View '{view.view_name}' references "
                    f"non-existent CTR_VIEW '{view.ctr_view}'."
                )
    #########################--------------------------------------###########################

    ######### FILTER METHOD for OPS Views ################
    @staticmethod
    def filterOPSViews(viewsIdObjectDict):
        """
        Build a valid OPS subset from the given views.

        Rules
        -----
        1. A valid OPS must contain exactly one center view.
           If multiple center views exist, the first one is kept and
           the rest are rejected.

        2. A view is accepted only if its CTR_VIEW points to a view
           already accepted into the OPS.

        3. For a given parent view, only one child may occupy a given
           relative position (L, R, T, B).
           Duplicate assignments are rejected.

        4. Views not reachable from the chosen center view are rejected.

        Returns
        -------
        tuple[dict, dict]
            (validOpsViewsIdObjectDict, rejectedViewsIdObjectDict)
        """

        validOpsViewsIdObjectDict = {}
        rejectedViewsIdObjectDict = {}

        # -------------------------------------------------
        # Step 1: Find center views
        # -------------------------------------------------
        centerViews = [
            view
            for view in viewsIdObjectDict.values()
            if view.view_name == view.ctr_view
        ]

        # No center view -> no OPS possible
        if not centerViews:
            return {}, viewsIdObjectDict.copy()

        # Keep first center view
        centerView = centerViews[0]
        validOpsViewsIdObjectDict[centerView.view_id] = centerView

        # Reject additional center views
        for extraCenter in centerViews[1:]:
            rejectedViewsIdObjectDict[extraCenter.view_id] = extraCenter

        # -------------------------------------------------
        # Step 2: Build OPS hierarchy
        # -------------------------------------------------
        occupiedPositions = set()
        visited = {centerView.view_name}

        changed = True

        while changed:

            changed = False

            for viewId, view in viewsIdObjectDict.items():

                # Already processed
                if (
                        viewId in validOpsViewsIdObjectDict
                        or viewId in rejectedViewsIdObjectDict
                ):
                    continue

                # Additional center views already handled
                if view.view_name == view.ctr_view:
                    rejectedViewsIdObjectDict[viewId] = view
                    continue

                # Parent must already belong to OPS
                if view.ctr_view not in visited:
                    continue

                # Duplicate relative position under same parent
                positionKey = (
                    view.ctr_view,
                    view.rel_order
                )

                if positionKey in occupiedPositions:
                    rejectedViewsIdObjectDict[viewId] = view
                    continue

                occupiedPositions.add(positionKey)

                validOpsViewsIdObjectDict[viewId] = view
                visited.add(view.view_name)

                changed = True

        # -------------------------------------------------
        # Step 3: Reject everything unreachable
        # -------------------------------------------------
        for viewId, view in viewsIdObjectDict.items():

            if (
                    viewId not in validOpsViewsIdObjectDict
                    and viewId not in rejectedViewsIdObjectDict
            ):
                rejectedViewsIdObjectDict[viewId] = view

        return (
            validOpsViewsIdObjectDict,
            rejectedViewsIdObjectDict
        )


    ######### Main Validation Method for OPS Views ################
    def validateOPS(self, opsViews):
        """
        Validate the Orthographic Projection Set (OPS) topology.

        This validation is performed before any view arrangement is attempted.
        The goal is to ensure that the OPS definition is logically consistent
        and can be safely processed by the arrangement algorithm.

        Validation checks
        -----------------
        1. Exactly one center view exists.
           A center view is identified by:

               view.view_name == view.ctr_view

        2. Every CTR_VIEW reference is valid.
           Each non-center view must reference an existing view
           within the OPS.

           Example (Invalid):

               VIEW_NAME = "R1"
               CTR_VIEW  = "UNKNOWN_VIEW"

        3. No duplicate relative assignments exist.
           For a given parent view, only one child may occupy a given
           relative position (L, R, T, B).

           Example (Invalid):

               C1 -> R1 (R)
               C1 -> R2 (R)

        4. The OPS forms a valid directed acyclic graph (DAG).
           The parent-child relationships must form an acyclic graph
           that can be traversed from the center view.

           Example (Invalid):

               C1 -> R1
               R1 -> R2
               R2 -> C1

        Parameters
        ----------
        opsViews : dict[int, DrawView]
            Dictionary containing only the views that participate in
            the Orthographic Projection Set.

        Raises
        ------
        ValueError
            If any OPS validation rule is violated.
        """

        self.validateSingleCenterView(opsViews)
        self.validateCTRViewReferences(opsViews)
        self.validateRelativeAssignments(opsViews)
        self.validateNoCycles(opsViews)

    def _arrangeMVP(self):
        """
        Arrange all Orthographic Projection Sets (OPS).

        This method identifies all OPS root views (center views),
        traverses each OPS hierarchy using Breadth-First Search (BFS),
        and positions child views relative to their parent views
        according to their REL_ORDER (L, R, T, B).

        For each discovered OPS:

        1. Start from the center/root view.
        2. Traverse all descendant views.
        3. Compute the placement of each child view relative
           to its parent view.
        4. Validate the resulting OPS topology.
        5. Store the arranged OPS in self.OPS_Pairs.

        Notes
        -----
        A center view is identified by:

            view.view_name == view.ctr_view

        Multiple independent OPS trees are supported and are stored
        separately in self.OPS_Pairs.

        After processing, self.viewsIdObjectDict is updated with
        the first OPS in self.OPS_Pairs for backward compatibility.

        Raises
        ------
        ValueError
            If OPS validation fails.
        """

        # Extract only the views participating in OPS.
        unprocessedViews =filterRelatedViews(self.viewsIdObjectDict)



        # Identify all OPS root views.
        # A root view references itself as its center view.
        centerViews = {
            vid: vobj
            for vid, vobj in unprocessedViews.items()
            if vobj.view_name == vobj.ctr_view
        }

        # Track views already processed during traversal.
        processed = set()

        def get_children(parentView):
            """
            Retrieve all direct children of a parent view.

            Parameters
            ----------
            parentView : DrawView

            Returns
            -------
            dict[int, DrawView]
                Dictionary of child views whose CTR_VIEW
                references the supplied parent view.
            """
            return {
                vid: vobj
                for vid, vobj in unprocessedViews.items()
                if vobj.ctr_view == parentView.view_name
                   and vobj.view_name != parentView.view_name
            }

        # Process each OPS tree independently.
        for centerViewId, centerViewObject in centerViews.items():

            # Stores all arranged views belonging to the current OPS.
            viewsIdObjectDict_ForOPS = {}

            # BFS queue initialized with root view.
            queue = [(centerViewId, centerViewObject)]

            while queue:

                # Get next view to process.
                currId, currObj = queue.pop(0)

                # Skip already processed views.
                if currId in processed:
                    continue

                processed.add(currId)

                # Store the current arranged view.
                viewsIdObjectDict_ForOPS[currId] = currObj

                # Find and arrange all direct child views.
                for childId, childObj in get_children(currObj).items():
                    # Position child relative to current view.

                    updatedChild = self.attachViewBasedOnRelativeOrder(
                        centerView=currObj,
                        relativeView=childObj
                    )

                    # Store updated child and schedule it
                    # for further traversal.
                    viewsIdObjectDict_ForOPS[childId] = copy.deepcopy(
                        updatedChild
                    )

                    queue.append((childId, updatedChild))

            # Validate the fully constructed OPS tree.
            self.validateOPS(viewsIdObjectDict_ForOPS)

            # Store arranged OPS.
            self.OPS_Pairs.append(viewsIdObjectDict_ForOPS)


        # Maintain existing behavior by exposing
        # the first OPS as the active view dictionary.
        if not self.OPS_Pairs:
            self.viewsIdObjectDict=False
        self.viewsIdObjectDict = self.OPS_Pairs[0]

#### the test main requires external file input
def test_main1():
    #pass you file path in viewsJsonPath
    pass
    # viewsJsonPath=r"C:\Users\vectra\Desktop\Vectra\my_repos\shared_lib\drawview_root\sample_data\drawviews_output_ops.json"
    # viewsDict=convertJSONToDrawViewsDict(jsonPathOrData=viewsJsonPath)
    # # create dictionary of views objects with view_id as key and view object as value
    # drawViewsIdObjectsDict = viewsDict

    # opsViews, rejectedViews = OrthographicProjectionSet.filterOPSViews(
    #     viewsIdObjectDict=viewsDict
    # )
    # print(f'{opsViews.keys()=} {rejectedViews.keys()=}')

    # for view_id,viewObject in drawViewsIdObjectsDict.items():
    #     print(f'{view_id=} : view name={viewObject.view_name}  ctr_view={viewObject.ctr_view=}  rel_order = {viewObject.rel_order}')
    #
    # results=OrthographicProjectionSet(drawViewsIdObjectsDict,MVP_Config={'ctrViewMargin': 20})
    #
    # print(f"views Id for OPS={results.viewsIdObjectDict.keys()}")
    #
    #
    # cluster=ViewCluster(viewsIdObjectDict=results.viewsIdObjectDict)
    # displayViewsCluster(cluster.viewsIdObjectDict)

##### test_main2 and test_main3 has hardcoded view json data
def test_main2():
    jsonData = {
        "UNITS": "mm",
        "VIEWS": [
            {
                "VIEW_ID": 1,
                "VIEW_NAME": "Top@1",
                "H": 865,
                "V": 135,
                "ANCHOR_TAG": "CTR",
                "ANCHOR_POINT": {
                    "X": 0,
                    "Y": 0
                },
                "DRAW_ZONES": {
                    "L": 41,
                    "R": 34,
                    "T": 45,
                    "B": 45
                },
                "CTR_VIEW": "Top@1",
                "REL_ORDER": "CTR",
                "SCALE": 1,
                "SHT_ID": 1
            },
            {
                "VIEW_ID": 2,
                "VIEW_NAME": "ORTHO@3",
                "H": 73,
                "V": 133.5,
                "ANCHOR_TAG": "CTR",
                "ANCHOR_POINT": {
                    "X": 0,
                    "Y": 0
                },
                "DRAW_ZONES": {
                    "L": 7,
                    "R": 33,
                    "T": 30,
                    "B": 6.5
                },
                "CTR_VIEW": "Top@1",
                "REL_ORDER": "R",
                "SCALE": 1,
                "SHT_ID": 1
            },
            {
                "VIEW_ID": 3,
                "VIEW_NAME": "ORTHO@2",
                "H": 865,
                "V": 75,
                "ANCHOR_TAG": "CTR",
                "ANCHOR_POINT": {
                    "X": 0,
                    "Y": 0
                },
                "DRAW_ZONES": {
                    "L": 41,
                    "R": 34,
                    "T": 32.5,
                    "B": 67.5
                },
                "CTR_VIEW": "TOP@1",
                "REL_ORDER": "B",
                "SCALE": 1,
                "SHT_ID": 1
            }

        ]
    }

    viewsIdObjectsDict = convertJSONToDrawViewsDict(jsonData)
    print(f'views Id :Before OPS arrange:{viewsIdObjectsDict.keys()}')
    results = OrthographicProjectionSet(viewsIdObjectsDict, MVP_Config={'ctrViewMargin': 20})

    print(f"views Id :After OPS arrange: {results.viewsIdObjectDict.keys()}")

    cluster = ViewCluster(viewsIdObjectDict=results.viewsIdObjectDict)
    displayViewsCluster(cluster.viewsIdObjectDict)
def test_main3():
    jsonData={
            "UNITS": "mm",
            "VIEWS": [
                {
                    "VIEW_ID": 1,
                    "VIEW_NAME": "C1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "CTR",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 2,
                    "VIEW_NAME": "R1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "R",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 22,
                    "VIEW_NAME": "R1'",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "",
                    "REL_ORDER": "",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 3,
                    "VIEW_NAME": "R2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "R1",
                    "REL_ORDER": "R",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 4,
                    "VIEW_NAME": "L1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "L",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 5,
                    "VIEW_NAME": "L2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "L1",
                    "REL_ORDER": "L",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },

                   {
                    "VIEW_ID": 7,
                    "VIEW_NAME": "T1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "T",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 8,
                    "VIEW_NAME": "T2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "T1",
                    "REL_ORDER": "T",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                   {
                    "VIEW_ID": 9,
                    "VIEW_NAME": "B1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "B",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 10,
                    "VIEW_NAME": "B2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "B1",
                    "REL_ORDER": "B",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                 {
                    "VIEW_ID": 11,
                    "VIEW_NAME": "R3",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "R2",
                    "REL_ORDER": "R",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                 {
                    "VIEW_ID": 12,
                    "VIEW_NAME": "RB1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "B1",
                    "REL_ORDER": "R",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                 {
                    "VIEW_ID": 13,
                    "VIEW_NAME": "LT1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "T1",
                    "REL_ORDER": "L",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                }, {
                    "VIEW_ID": 14,
                    "VIEW_NAME": "LB1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                         "L": 10,
                        "R": 4,
                        "T": 6,
                        "B": 4
                    },
                    "CTR_VIEW": "L1",
                    "REL_ORDER": "B",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                }
            ]
        }
    viewsIdObjectsDict = convertJSONToDrawViewsDict(jsonData)
    print(f'views Id :Before OPS arrange:{viewsIdObjectsDict.keys()}')
    results = OrthographicProjectionSet(viewsIdObjectsDict, MVP_Config={'ctrViewMargin': 20})

    print(f"views Id :After OPS arrange: {results.viewsIdObjectDict.keys()}")

    cluster = ViewCluster(viewsIdObjectDict=results.viewsIdObjectDict)
    displayViewsCluster(cluster.viewsIdObjectDict)

