from vct_o_geom.vector import *


class Point:

    def __init__(self, *attrs):

        if np.reshape(np.array(attrs), -1).shape[0] == 3:
            self.array = np.reshape(np.array(attrs), (1, 3))
        if np.reshape(np.array(attrs), -1).shape[0] == 2:
            self.array = np.reshape(np.array(attrs), (1, 2))

    def __add__(self, other):
        # point = Point3D(self.xCoord + other.xCoord, self.yCoord + other.yCoord, self.zCoord + other.zCoord)
        return Point(self.array + other.array)

    def __sub__(self, other):
        return Point(self.array - other.array)

    def __truediv__(self, number):
        return Point(self.array / number)

    def __eq__(self, other):
        return True if np.all(self.array == other.array) else False

    def __getitem__(self, idx):
        return self.array[0][idx]

    def __repr__(self):
        return f"Point ({', '.join(self.array[0].astype(str)[:])})"

    def isPointIn_3D(self):
        return self.array.shape[-1] == 3

    def as_NDArray(self):
        return self.array

    def distanceToPoint(self, other):
        """
        Computes the distance between two points
        :param other: Instance of Point3D
        :return: Distance between two points
        """
        distVect = other - self
        return np.linalg.norm(distVect.array)

    def pointAtDistance(self, distance: Union[int, float], dirVector: Vector):
        """
        Computes a point at a given distance from the given point in the direction of "dirVector"
        :param distance: units of distance
        :param dirVector: Instance of Vector along which the point should lie
        :return: The point at a given distance from the given point in the direction of "dirVector"
        """
        distVector = dirVector * distance
        return Point(self.array[0][0] + distVector.array[0][0],
                     self.array[0][1] + distVector.array[0][1],
                     self.array[0][2] + distVector.array[0][2])

    def distanceVector(self, other):
        """
        Computes the direction vector between two points
        :param other: Instance of Point3D
        :return: Direction vector between two points (Instance of Vector)
        """
        return Vector(other.array - self.array)

    def projectedDistance(self, other, dirVector: Vector):
        """
        Computes the projection of a line defined by two points and a direction vector
        :param other: Instance of Point3D
        :param dirVector: Instance of Vector
        :return: Projected distance
        """
        # compute distance vector between self and other
        distVector = self.distanceVector(other)

        # normalize dirVector
        normalizedDirVector = dirVector.normalize()

        # compute dot prod (distance vector, normalized dirVector)
        dotProd = distVector.dot_product(normalizedDirVector)

        # return abs(dot product)
        return abs(dotProd)

# todo: tests to be written for following functions.
