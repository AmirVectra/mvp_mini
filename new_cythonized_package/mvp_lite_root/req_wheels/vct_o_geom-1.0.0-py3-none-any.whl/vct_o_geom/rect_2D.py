import numpy as np
from vct_o_geom.vector import Vector

"""
Revision history

[05-Feb-25][Jagjeet]: Added <updateAnchorPoint()>
[31-Jan-25][Jagjeet]: Added <_is_overlapping_SAT>   

"""


class Rect2D:

    def __init__(self, L1, L2, basis_vector1=Vector(1, 0), basis_vector2=Vector(0, 1),
                 anchor_tag="LB", anchor_point=Vector(0, 0)):
        # L1 is the length of the first basis vector
        self.L1 = L1
        # L2 is the length of the second basis vector
        self.L2 = L2
        # basis_vector1 and basis_vector2 are the basis vectors
        self.basis_vector1 = basis_vector1
        self.basis_vector2 = basis_vector2
        # anchor_tag is the tag of the anchor point
        self._anchor_tag = anchor_tag
        # anchor_point is the anchor point of the rectangle in the form of a vector
        self._anchor_point = anchor_point
        # alignment is the alignment of the rectangle with respect to the basis vectors
        self.__alignment = self.__checkAlignment()

    def __add__(self, other):
        """
        The magic method to merge two rectangle objects. Only aligned Rect2D objects can be merged.
        Args:
            other: Rect2D object

        Returns:
                Returns a new Rect2D object with the anchor_tag as CTR.
        """
        # TODO: should extents two rectangles along basis vectors.
        # Magic method to merge two rectangle objects.
        if self.__alignment == 'aligned' and other.__alignment == 'aligned':
            # get LB , RT of self and other
            selfLB = self.basis_point('LB')
            otherLB = other.basis_point('LB')

            selfRT = self.basis_point('RT')
            otherRT = other.basis_point('RT')
            # compute leftBottom and rightTop point for merged Rect2D
            leftBottom_xCoord = min(selfLB[0], otherLB[0], selfRT[0], otherRT[0])
            leftBottom_yCoord = min(selfLB[1], otherLB[1], selfRT[1], otherRT[1])
            leftBottomPoint = Vector(leftBottom_xCoord, leftBottom_yCoord)

            rightTop_xCoord = max(selfLB[0], otherLB[0], selfRT[0], otherRT[0])
            rightTop_yCoord = max(selfLB[1], otherLB[1], selfRT[1], otherRT[1])
            rightTopPoint = Vector(rightTop_xCoord, rightTop_yCoord)
            # print(leftBottomPoint.distanceVector(rightTopPoint))
            # compute CTR anchor_point of merged Rect2D
            center = (leftBottomPoint + rightTopPoint) / 2
            # compute width and height of merged Rect2D
            width = abs(rightTop_xCoord - leftBottom_xCoord)
            height = abs(rightTop_yCoord - leftBottom_yCoord)

            return Rect2D(L1=width, L2=height, anchor_point=center, anchor_tag='CTR')
        else:
            raise ValueError('addition of Rec2Ds only works for Aligned Type.')

    def __eq__(self, other):

        # Magic method to check equality of two rectangle objects.
        if self.L1 == other.L1 and self.L2 == other.L2 and self.basis_point('CTR') == other.basis_point('CTR'):
            return True

        return False

    def __str__(self):
        """
        # User-friendly string representation of Rect2D.
        """
        return (f"Rect(L1={self.L1}, L2={self.L2}, "
                f"Basis1={self.basis_vector1}, Basis2={self.basis_vector2}, "
                f"Anchor Tag='{self.anchor_tag}', Anchor Point={self.anchor_point})")

    def __checkAlignment(self):
        """
        This function checks if the rectangle is aligned or inclined with respect to the basis vectors.
        Returns: returns "aligned" or "inclined" depending on the alignment

        """
        if (self.basis_vector1 == Vector(1, 0)) and self.basis_vector2 == Vector(0, 1):
            return "aligned"
        else:
            return "inclined"

    def _steps_from_anchortag_to_ctr(self, input_anchor_tag, dir_flag=1):
        """
        This function returns the steps from the anchor tag to the center of the rectangle.
        Args:
            input_anchor_tag: the allowed values are "LB", "LT", "RT", "RB", "LC", "RC", "TC", "BC","CTR"
            dir_flag: the direction of the steps (1 or -1)

        Returns:
            return the steps from the anchor tag to the center of the rectangle

        """
        l1, l2 = self.L1, self.L2
        bv1, bv2 = self.basis_vector1, self.basis_vector2

        dict_steps = {

            'LB': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag))],
            'LT': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag))],
            'RT': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag))],
            'RB': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag))],
            'CL': [(l1 / 2, bv1.scalar_product(dir_flag))],
            'CT': [(l2 / 2, -bv2.scalar_product(dir_flag))],
            'CR': [(l1 / 2, -bv1.scalar_product(dir_flag))],
            'CB': [(l2 / 2, bv2.scalar_product(dir_flag))],
            'CTR': []
        }
        return dict_steps[input_anchor_tag]

    # TODO: 6 FEB 2023 VArma suggested to have is_overlap() that returns True/False
    def _project_rectangle(self, axis):
        """Projects the rectangle onto the given axis and returns min/max values.
        :param axis: Vector(ndarray (1,2))
        :returns float : min and max"""

        corners = [self.basis_point(anchor_tag).dot_product(axis) for anchor_tag in ['LB', 'RB', 'RT', 'LT']]
        return min(corners), max(corners)

    # To check overlap b/w mis aligned rect
    def _is_overlapping_SAT(self, other):
        """
        Uses Separating Axis Theorem (SAT) to check if two rectangles overlap with not aligned basis vectors
        :param other: rect2d object
        :return: True if overlapping, False otherwise
        """
        # Four basis vectors to project points
        axes = [self.basis_vector1, self.basis_vector2, other.basis_vector1, other.basis_vector2]

        # Check projections on each axis, if even a single seprating axis found means no overlap
        for axis in axes:
            self_Min, self_Max = self._project_rectangle(axis)
            other_Min, other_Max = other._project_rectangle(axis)
            if self_Max < other_Min or other_Max < self_Min:
                return False  # Separating axis found → no overlap

        return True  # Overlapping

    # Getters and Setters
    @property
    def anchor_tag(self):
        return self._anchor_tag

    @anchor_tag.setter
    def anchor_tag(self, new_anchor_tag):

        self._anchor_tag = new_anchor_tag

    @property
    def anchor_point(self):
        return self._anchor_point

    @anchor_point.setter
    def anchor_point(self, new_anchor_point):

        self._anchor_point = new_anchor_point

    def basis_point(self, input_anchor_tag):
        """
        This function returns the basis point of the rectangle based on the input anchor tag.
        Args:
            input_anchor_tag: allowed values are "LB", "LT", "RT", "RB", "LC", "RC", "TC", "BC","CTR"

        Returns:
            return the basis point of the rectangle of the given input_anchor_tag

        """
        # if the input anchor tag is the same as the anchor tag of the rectangle, return the anchor point
        if input_anchor_tag == self.anchor_tag:
            return self.anchor_point
        # else, calculate the basis point based on the input anchor tag
        steps_to_ctr = self._steps_from_anchortag_to_ctr(self.anchor_tag, 1)
        steps_from_ctr = self._steps_from_anchortag_to_ctr(input_anchor_tag, -1)

        total_steps_to_basis_point = steps_to_ctr + steps_from_ctr

        basis_point = self.anchor_point
        for step in total_steps_to_basis_point:
            len = step[0]
            dir = step[1]
            basis_point = basis_point.point_at_distance(len, dir)
        return basis_point

    def updateAnchorPoint(self, new_anchor_tag: str):
        """Update the rect anchor tag and point"""
        newAnchorpoint = self.basis_point(input_anchor_tag=new_anchor_tag)
        self.anchor_point = newAnchorpoint
        self.anchor_tag = new_anchor_tag

    def area(self):
        # Area of a rectangle is L1*L2
        return self.L1 * self.L2

    def perimeter(self):
        # Perimeter of a rectangle is 2*(L1+L2)
        return 2 * (self.L1 + self.L2)

    def diagonal(self):
        # Diagonal of a rectangle is sqrt(L1^2+L2^2)
        return np.sqrt(self.L1 ** 2 + self.L2 ** 2)

    def boundingRectangle(self):
        """
        This function returns the bounding rectangle of the rectangle.
        Returns: return the bounding rectangle (Rect2D object) of the rectangle

        """
        if self.__alignment == 'aligned':
            # print('Rect2d class')
            LB_Coord, RT_Coord = self.basis_point("LB"), self.basis_point("RT")
            L1, L2 = RT_Coord[0] - LB_Coord[0], RT_Coord[1] - LB_Coord[1]
            return Rect2D(L1=L1, L2=L2, anchor_tag="LB", anchor_point=LB_Coord)

    # Todo : 27 Jan 25 Varma suggested to rename method to intersects_with
    def is_overlap(self, other):
        """
        Check for overlapping between the current (self) Rect2D object and another Rect2D object.

        Args:
            other (Rect2D): The Rect2D object to check for overlapping with the current Rect2D object.

        Returns:
            bool: True if the two Rect2D objects overlap or touch at the edges, else False.

    Case 1 (To check overlap b/w rect) : Overlapping each other
        rect1 = Rect2D(L1=8, L2=5, basis_vector1=Vector(1, 0), basis_vector2=Vector(0, 1), anchor_tag="LB", anchor_point=Vector(3, 2))
        rect2 = Rect2D(L1=5, L2=5, basis_vector1=Vector(0.7071, 0.7071), basis_vector2=Vector(-0.7071, 0.7071), anchor_tag="LB", anchor_point=Vector(12, 3))

    Case 2: Rectangles with rotated axes and non-overlapping
        rect1 = Rect2D(L1=8, L2=5, basis_vector1=Vector(1, 0), basis_vector2=Vector(0, 1), anchor_tag="LB",
                 anchor_point=Vector(3, 2))
        rect2 = Rect2D(L1=5, L2=5, basis_vector1=Vector(0.7071, 0.7071), basis_vector2=Vector(-0.7071, 0.7071),
                 anchor_tag="LB", anchor_point=Vector(17, 3))

        """
        # To check if both Rect2D objects have same Aligned Vectors (1,0) & (0,1)
        if self.__alignment == 'aligned' and other.__alignment == 'aligned':
            self_LB_x, self_LB_y = self.basis_point('LB')
            self_RT_x, self_RT_y = self.basis_point('RT')

            other_LB_x, other_LB_y = other.basis_point('LB')
            other_RT_x, other_RT_y = other.basis_point('RT')
            if (self_LB_x >= other_RT_x) or (self_RT_x <= other_LB_x) or (self_RT_y <= other_LB_y) or (
                    self_LB_y >= other_RT_y):
                return False
            return True  # Overlapping
        else:
            return self._is_overlapping_SAT(other)

    def overlap_extents(self, other):
        """
        Calculate the overlap extents between the current (self) Rect2D object and another Rect2D object.

        Args:
            other (Rect2D): The other Rect2D object to calculate overlap extents with.

        Returns:
            list: A list containing the horizontal (overlap_dH) and vertical (overlap_dV) overlap differences between the two Rect2D objects.

        Example:
            If the horizontal overlap between the rectangles is 10 units and the vertical overlap is 5 units,
            the returned list will be [10, 5] which is [overlap_dH, overlap_dV].

        """

        # check to see if both Rect2D objects are aligned :
        # if self.basis_vector1==Vector(1,0)==other.basis_vector1 and self.basis_vector2==Vector(0,1)==other.basis_vector2:
        if self.__alignment == 'aligned' and other.__alignment == 'aligned':

            # get max xCoord from the left edges of the rectangles
            LeftEdge_max_x = max(self.minXCoord(), other.minXCoord())
            # LeftEdge_max_x= max(self.basis_point('LB')[0],other.basis_point('LB')[0] )

            # get min xCoord from the right edges of the rectangles
            RightEdge_min_x = min(self.maxXCoord(), other.maxXCoord())

            # get max yCoord from Bottom edges of the rectangles
            BottomEdge_max_y = max(self.minYCoord(), other.minYCoord())

            # get min yCoord from Top edges of the rectangles
            TopEdge_min_y = min(self.maxYCoord(), other.maxYCoord())

            # initialize overlap extents
            overlap_dH = 0  # horizontal overlap difference
            overlap_dV = 0  # vertical overlap difference

            if LeftEdge_max_x < RightEdge_min_x:  # overlap exists horizontally
                overlap_dH = RightEdge_min_x - LeftEdge_max_x
            if BottomEdge_max_y < TopEdge_min_y:  # overlap exists vertically
                overlap_dV = TopEdge_min_y - BottomEdge_max_y

            return [overlap_dH, overlap_dV]

    def is_touching(self, other):
        """
        Returns False when both Rect2D Object are far apart.
        Else it will return "H" and "V", where H means two Rect2Ds have no gaps in Horizontal direction and V for no gaps in vertical direction

        'H' when two Rect2D objects are  touching on vertical edges side by side
        ******             ******@@@@@
        ******#####  OR    ******@@@@@
        ******#####        ******@@@@@
              #####

              'V" when two Rect2D objects are touching on horizontal egdes one above the other

        #####               @@@@@@
        #####               @@@@@@
        #####        OR     @@@@@@
          *****             ******
          *****             ******
          *****             ******

        Args:
            other: the alternative Rect2D object

        Returns:
            False if both Rect2D are far apart, Else return "H" or "V" depending on overlap.

        """
        if not (self.is_overlap(other)):  # for touching cases , is_overlap will result in False.
            horizontalOverlap, verticalOverlap = self.overlap_extents(other)
            if horizontalOverlap == 0 and verticalOverlap != 0:
                return 'H'
            elif horizontalOverlap != 0 and verticalOverlap == 0:
                return 'V'
        return False

    # TODO: Future enhancement with scaleDirection.
    def scale_rect_bv1(self, scaleFactor, scaleDirection="CTR"):
        """
        This method scales the current Rect2D Object with the scaleFactor along basis_vector1 (L1)
        Args:
            scaleFactor: The scale value that scales  horizontally
            scaleDirection:direction of scaling.

        Returns:
            None, scales the current Rect2D Object with the scaleFactor
        Note:
            L1 , anchor_point will be updated for the current Rect2D object)
            L2 , anchor_tag will remain unchanged.

        """
        if self.__alignment == 'aligned':
            directionVector = self.basis_vector1
            transformMatrix = np.array([[scaleFactor, 0], [0, 1]])  # numpy array

            self.scale_rect(scaleFactor=scaleFactor, transformationMatrix=transformMatrix,
                            scaleDirection=scaleDirection,
                            directionVector=directionVector)

        else:
            print('The scale_rect_bv1 only handles "aligned" Rect2D object')

    #TODO: Future enchancement with scaleDirection.
    def scale_rect_bv2(self, scaleFactor, scaleDirection="CTR"):

        """
        This method scales the current Rect2D Object with the scaleFactor along basis_vector2 (L2)
        Args:
            scaleFactor: The scale value that scales  vertically
            scaleDirection: the direction of scaling.

        Returns:
            None, scales the current Rect2D Object with the scaleFactor
        Note:
            L2 , anchor_point will be updated for the current Rect2D object)
            lenght1 , anchor_tag will remain unchanged.

        """
        if self.__alignment == 'aligned':
            directionVector = self.basis_vector2
            transformMatrix = np.array([[1, 0], [0, scaleFactor]])  # numpy array

            self.scale_rect(scaleFactor=scaleFactor, transformationMatrix=transformMatrix,
                            directionVector=directionVector,
                            scaleDirection=scaleDirection)
        else:
            print('The scale_rect_bv2 only handles "aligned" Rect2D object')

    #TODO: future enhancement with scaleDirection
    def scale_rect_uniform(self, scaleFactor, scaleDirection="CTR"):
        """
        This method scales the current Rect2D Object with the scaleFactor along both basis_vector1 and basis_vector2
        Args:
            scaleFactor: The scale value that scales  both vertical and horizontal direction
            scaleDirection: the direction of scaling.
        Returns:
            None, scales the current Rect2D Object with the scaleFactor
        Note:
            L1 ,L2, anchor_point will be updated for the current Rect2D object)
            Only anchor_tag will remain unchanged.


        """
        # directionVector = (self.basis_vector1 + self.basis_vector2).normalize() transformMatrix = np.array([[scaleFactor, 0], [0, scaleFactor]])
        # numpy array self.scale_rect(scaleFactor=scaleFactor, transformationMatrix=transformMatrix, directionVector=directionVector,
        # scaleDirection=scaleDirection)

        if self.__alignment == 'aligned':
            oldAnchorPoint = self.basis_point(scaleDirection)

            # uniform scaling means applying scaling along bv1 and bv2 direction
            self.scale_rect_bv1(scaleFactor=scaleFactor, scaleDirection=scaleDirection)
            self.scale_rect_bv2(scaleFactor=scaleFactor, scaleDirection=scaleDirection)

        else:
            print('The scale_rect_uniform only handles "aligned" Rect2D object')

    def scale_rect(self, scaleFactor, transformationMatrix, directionVector: Vector,
                   scaleDirection="CTR"):  # TODO: needs to be added in G-doc
        """

        Scale the current Rect2D object based on specified parameters.

        Args:
            scaleFactor (float): The scalar value used for scaling the Rect2D object.
            transformationMatrix (matrix): A matrix defining the scaling transformation for the Rect2D object.
            directionVector (vector): The direction of scaling: horizontal (basis_vector1), vertical (basis_vector2), or uniform (normalize of
            basis_vector1 and basis_vector2).
            scaleDirection: direction of scaling By default it is "CTR", scaling in centralized way.

        Returns:
            Rect2D: The updated scaled Rect2D object.

        Note:

            This function now computes the directionVector internally using the displacement value in L1 and L2.
            It handles only "aligned" Rect2D objects.
            Kept the directionVector argument as it is for future scope when dealing "inclined" Rect2D objects.
            scaleDirection only handles centralized scaling (CTR) .

        """
        if self.__alignment == 'aligned':
            # storing the original L1 and L2
            prev_length1, prev_length2 = self.L1, self.L2
            # matrix multiplication of transformationMatrix with   [L1,L2] where  L1 and L2 gets scaled based on matrix.

            # defaulting anchor_tag to LB. It will be reset to original anchor_tag after scaling
            prev_anchor_tag = self.anchor_tag
            if scaleDirection == "CTR":  # scaling in centralized way (both up & down AND both left & right}
                # TODO: future enhancement various scaling   direction,
                # moving anchor_point to new anchor_point after scaling
                if prev_anchor_tag != 'LB':
                    self.anchor_point = self.basis_point('LB')
                    self.anchor_tag = 'LB'

                self.L1, self.L2 = np.dot(transformationMatrix, np.array([self.L1, self.L2]))
                d1 = abs(self.L1 - prev_length1) / 2  # displacement along bv1
                d2 = abs(self.L2 - prev_length2) / 2  # displacement along bv2

                # if scaling is along bv1 (1,0) distance will be 1 =d1
                # if scaling is along bv2 (0,1) distance will be 1 =d2
                # if scaling is along uniform (1,1) distance will be root 2=sqrt(d1**2+d2**2)

                distance = Vector(d1, d2).magnitude()  # OR  ((d1 ** 2) + (d2 ** 2)) ** 0.5

                # additional logic to get dir_vec
                # directionVector = Vector((1 / distance) * d1, (1 / distance) * d2)
                directionVector = directionVector
                directionVector = Vector(d1, d2).normalize()

                # check to see if the scale is >1 or >0
                if 0 < scaleFactor < 1:

                    dir_vec = directionVector

                else:

                    dir_vec = -directionVector

                self.anchor_point = self.anchor_point.point_at_distance(distance=distance, dir_vector=dir_vec)

                # resetting anchor_point value based on original anchor_tag.

                self.anchor_point = self.basis_point(prev_anchor_tag)
                self.anchor_tag = prev_anchor_tag
        else:
            print('The scale_rect  only handles "aligned" Rect2D object')

    def shift(self, directionVector, distance):
        """
        Shifts the current Rect2D object based on directionVector and distance.
        Args:
            directionVector: (vector): The direction of scaling: horizontal (basis_vector1), vertical (basis_vector2), or uniform (normalize of
            basis_vector1 and basis_vector2).
            distance: the amount shift to done in that direction vector

        Returns:
            None, It affects the current object (self)

        """
        self.anchor_point = self.anchor_point.point_at_distance(distance=distance, dir_vector=directionVector)

    def minXCoord(self):

        # The minimum x-coord of a rectangle is it's left bottom corner's x-coordinate.
        return self.basis_point('LB')[0]

    def maxXCoord(self):

        # The maximum x-coord of a rectangle is it's right top corner's x-coordinate.

        return self.basis_point('RT')[0]

    def minYCoord(self):

        # The minimum y-coord of a rectangle is it's left bottom corner's y-coordinate.
        return self.basis_point('LB')[1]

    def maxYCoord(self):

        # The maximum y-coord of a rectangle is it's right top corner's y-coordinate.

        return self.basis_point('RT')[1]

    #################################################################################################################
    #  The methods below are just for testing/debugging purpose.
    #################################################################################################################

    def allBasisPoints(self):
        """This method is used for testing/debugging purpose"""
        # Method that returns all corners of a rectangle in a list
        return {"LB": (self.basis_point("LB")[0], self.basis_point("LB")[1]),
                "LT": (self.basis_point("LT")[0], self.basis_point("LT")[1]),
                "RT": (self.basis_point("RT")[0], self.basis_point("RT")[1]),
                "RB": (self.basis_point("RB")[0], self.basis_point("RB")[1]),
                "CTR": (self.basis_point("CTR")[0], self.basis_point("CTR")[1]),
                "CL": (self.basis_point("CL")[0], self.basis_point("CL")[1]),
                "CR": (self.basis_point("CR")[0], self.basis_point("CR")[1]),
                "CT": (self.basis_point("CT")[0], self.basis_point("CT")[1]),
                "CB": (self.basis_point("CB")[0], self.basis_point("CB")[1])}
        # return [self.basis_point('LB'), self.basis_point('LT'), self.basis_point('RT'), self.basis_point('RB')]

    def mainPoints(self):
        """This method is used for testing/debugging purpose"""
        # Method that returns all corners of a rectangle in a list
        return {"LB": (self.basis_point("LB")[0], self.basis_point("LB")[1]),
                "LT": (self.basis_point("LT")[0], self.basis_point("LT")[1]),
                "RT": (self.basis_point("RT")[0], self.basis_point("RT")[1]),
                "RB": (self.basis_point("RB")[0], self.basis_point("RB")[1]),
                "CTR": (self.basis_point("CTR")[0], self.basis_point("CTR")[1])}

    def corners(self):
        """This method is used for testing/debugging purpose"""
        # Method that returns the all the corners as a dictionary.

        dictCorners = {"LB": self.basis_point('LB'),
                       "LT": self.basis_point('LT'),
                       "RT": self.basis_point('RT'),
                       "RB": self.basis_point('RB'),
                       "CTR": self.basis_point('CTR')}

        return dictCorners


if __name__ == "__main__":
    ...

    # Case 1 (To check overlap b/w rect) : Overlapping each other
    # rect1 = Rect2D(L1=8, L2=5, basis_vector1=Vector(1, 0), basis_vector2=Vector(0, 1), anchor_tag="LB", anchor_point=Vector(3, 2))
    # rect2 = Rect2D(L1=5, L2=5, basis_vector1=Vector(0.7071, 0.7071), basis_vector2=Vector(-0.7071, 0.7071), anchor_tag="LB", anchor_point=Vector(12, 3))

    #Case 2: Rectangles with rotated axes and non-overlapping
    # rect1 = Rect2D(L1=8, L2=5, basis_vector1=Vector(1, 0), basis_vector2=Vector(0, 1), anchor_tag="LB",
    #                anchor_point=Vector(3, 2))
    # rect2 = Rect2D(L1=5, L2=5, basis_vector1=Vector(0.7071, 0.7071), basis_vector2=Vector(-0.7071, 0.7071),
    #                anchor_tag="LB", anchor_point=Vector(17, 3))

    # Case 3: Overlapping
    # rect1 = Rect2D(L1=9, L2=3, basis_vector1=Vector(0, 1), basis_vector2=Vector(-1, 0), anchor_tag="RT",
    #                anchor_point=Vector(15, 10))
    # rect2 = Rect2D(L1=6, L2=6, basis_vector1=Vector(0.9239, 0.3827), basis_vector2=Vector(-0.3827, 0.9239),
    #                anchor_tag="CT", anchor_point=Vector(14, 12))  # Slight rotation but overlapping region

    # Case when two corner points analogy fails
    # rect1 = Rect2D(L1=4, L2=2, basis_vector1=Vector(1, 0), basis_vector2=Vector(0, 1), anchor_tag="LB", anchor_point=Vector(0, 0))
    # rect2 = Rect2D(L1=4, L2=2, basis_vector1=Vector(0.707, 0.707), basis_vector2=Vector(-0.707, 0.707), anchor_tag="LB", anchor_point=Vector(2, 0))

    # print(rect1.is_overlap(rect2))
