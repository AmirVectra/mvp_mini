from collections import deque
from sympy import Point, Segment2D, Polygon, Point2D


class PointWrapper:

    def __init__(self, entity):
        self.point = entity
        self.name = "POINT2D"


# TODO: 28-04-2022 -> Enhancement: Come up with a better name. Eg: VCTPolygon
class PolygonWrapper:

    def __init__(self, entity):
        self.polygon = entity
        self.name = 'POLYGON'

    def enclosesPoint(self, arbitraryPoint):
        """
        Determines if the given arbitrary point lies on or inside the boundary of the polygon
        :param arbitraryPoint: Input point from the user
        :return: Boolean value indicating enclosure.
        """
        # Check if the point is on the boundary of the polygon. If yes, return True
        if self.onBoundary(arbitraryPoint):
            return True

        # Create a Sympy Point object.
        arbitraryPoint2D = Point(arbitraryPoint[0], arbitraryPoint[1])

        # Return true if the provided point is inside the polygon, else false.
        return self.polygon.encloses_point(arbitraryPoint2D)

    def onBoundary(self, arbitraryPoint):
        """
        Determines if the given arbitrary point lies on the boundary of the polygon
        :param arbitraryPoint:
        :return: Boolean value indicating if point lies on the boundary
        """

        # Create a Sympy Point object.
        arbitraryPoint2D = Point(arbitraryPoint[0], arbitraryPoint[0])

        # If the point is outside of the polygon an empty list will be returned.
        if not self.polygon.intersection(arbitraryPoint2D):
            return False

        return True

    def curvature(self):
        """
        Determines the curvature of the polygon
        :return:
        """
        # Return true if the polygon is convex, else false.
        return self.polygon.is_convex()


class Segment2DWrapper:

    def __init__(self, entity):
        self.segment2D = entity
        self.name = 'SEGMENT2D'

    def enclosesPoint(self, arbitraryPoint):
        """
        Determines if the given arbitrary point lies on the line segment
        :param arbitraryPoint: Input point from the user
        :return: Boolean value indicating enclosure
        """
        # Create a Sympy Point object.
        arbitraryPoint2D = Point(arbitraryPoint[0], arbitraryPoint[1])

        # Return true if the provided point is inside the polygon, else false.
        return self.segment2D.contains(arbitraryPoint2D)

    def curvature(self):
        pass

    def onBoundary(self, arbitraryPoint):
        pass


class GeometricalWrapper:

    def __init__(self, listPointsIn3D):

        self.queuePointsIn3D = deque(listPointsIn3D)
        self.geometricalEntity = self.__preProcess()

    def __preProcess(self):
        """
        Returns appropriate geometrical entity based on the given set of point(s).
        :return: One of the geometrical entities viz., Polygon, Point, Segment2D
        """
        listPoints = []

        # Populate listPoints with tuples that contain only the x and y coordinate of the Point3D object.
        for pointIn3D in self.queuePointsIn3D:
            pointTuple = Point(pointIn3D[0], pointIn3D[1])
            listPoints.append(pointTuple)
        if Point.is_collinear(*listPoints):
            sortedPoints = sorted(listPoints, key=lambda coordinates: (coordinates[0], coordinates[1]))
            entity = Segment2D(sortedPoints[0], sortedPoints[-1])
        else:
            # Unpack listPoints and return the polygon created.
            entity = Polygon(*listPoints)

        dictSymPyEntities = {
            Segment2D: Segment2DWrapper(entity),
            Polygon: PolygonWrapper(entity),
            Point2D: PointWrapper(entity)

        }
        return dictSymPyEntities[type(entity)]



