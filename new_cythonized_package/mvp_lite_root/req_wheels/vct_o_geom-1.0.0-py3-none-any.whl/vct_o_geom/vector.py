from typing import Union
import numpy as np

ANGLE_TOLERANCE_1_DEG_PRL = 0.0001523

"""
Revision History

27-FEB-2025 : Added __str__ method
"""


class Vector:

    def __init__(self, *attrs):

        if np.reshape(np.array(attrs), -1).shape[0] == 3:
            self.array = np.reshape(np.array(attrs), (1, 3))
        if np.reshape(np.array(attrs), -1).shape[0] == 2:
            self.array = np.reshape(np.array(attrs), (1, 2))

    def __add__(self, other):

        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector '
                             f'{other.array.shape} ')

        return Vector(self.array + other.array)

    def __sub__(self, other):

        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector'
                             f' {other.array.shape} ')

        return Vector(self.array - other.array)

    def __mul__(self, scalar):
        return Vector(self.array * scalar)

    def __truediv__(self, scalar):
        if scalar == 0:
            raise ZeroDivisionError("Can't divide by zero")
        return Vector(self.array / scalar)

    def __neg__(self):
        # return Vector(*np.negative(self.array))
        return Vector(-self.array)

    def __getitem__(self, idx_pos):
        return self.array[0][idx_pos]

    def __repr__(self):
        return f"{self.array}"

    def __str__(self):
        """
        User-friendly string representation of Vector object.
        """
        return f"Vector({', '.join(map(str, self.array.flatten()))})"

    def __eq__(self, other):
        # TODO: vertex tolerance- VARMA
        # return np.any(np.equal(self.array, other))

        # take absolute value of difference of self.array from other.array
        # return np.all() of difference lesser than 0.1 and axis must be 1

        if not self.validateOtherVector(other):
            raise ValueError(
                f'Shape of first vector is {self.array.shape} is not matching with second vector {other.array.shape} ')

        # TODO: All tolerance values to be kept in a config
        return np.all(np.abs(self.array - other.array) < 0.1, axis=1)[0]

    def validateOtherVector(self, other):
        """
        Determines if both vectors are of same shape
        :param other: Instance of Vector
        :return: Boolean value indicating validity
        """
        return self.array.shape == other.array.shape

    def validateVector(self):
        """
        Determines if vector is of shape (1, 3)
        :return: Boolean value indicating validity of shape
        """
        return np.array(self.array).shape == (1, 3)

    def dot_product(self, other):
        """
        Calculates dot product of two vectors
        :param other: Instance of Vector
        :return: dot product of two vectors
        """

        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector '
                             f'{other.array.shape} ')

        return np.einsum('ij,ij->i', self.array, other.array).item()

    def cross_product(self, other):
        """
        Calculates cross product of two vectors
        :param other: Instance of Vector
        :return: Cross product of two vectors
        """
        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector'
                             f' {other.array.shape}')
        # TODO: Check for shapes, if shape is (1,2) return float value, if (1,3) return Vector object
        return Vector(np.cross(self.array, other.array))

    def scalar_product(self, scalar):
        """
        Computes scalar product of vector
        :param scalar: scalar to multiply with vector
        :return: Vector obtained by the result of scalar product
        """
        return Vector(self.array * scalar)

    def point_at_distance(self, distance: Union[int, float], dir_vector):
        if not self.validateOtherVector(dir_vector):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector'
                             f' {dir_vector.array.shape} ')

        point = self.array + (distance * dir_vector.array)
        return Vector(point)

    def magnitude(self):
        """
        Determines the magnitude of the Vector
        :return: magnitude
        """
        return np.linalg.norm(self.array)

    def is_unit_vector(self):
        """
        Determines if the vector is a unit vector
        :return: Boolean value indicating if the vector is a unit vector
        """
        length_of_vector = self.magnitude()
        # TODO: replace equality with tolerance -> Ask Varma
        return length_of_vector == 1

    def parallel(self, other):
        """
        Determines if two vectors are parallel
        :param other: Instance of Vector
        :return: Boolean value indicating parallelity
        """

        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector '
                             f'{other.array.shape} ')
        dotProd = self.dot_product(other) / (self.magnitude() * other.magnitude())

        parallelBooleans = np.abs(dotProd - 1) < ANGLE_TOLERANCE_1_DEG_PRL

        return parallelBooleans

    def antiParallel(self, other):
        """
        Determines if two vectors are antiparallel
        :param other: Instance of Vector
        :return: Boolean value indicating anti-parallelity
        """

        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector'
                             f' {other.array.shape} ')
        dotProd = self.dot_product(other) / (self.magnitude() * other.magnitude())

        antiParallelBooleans = np.abs(dotProd + 1) < ANGLE_TOLERANCE_1_DEG_PRL
        return antiParallelBooleans

    def aligned(self, other):
        """
        Determines if two vectors are aligned
        :param other: Instance of Vector
        :return: Boolean value indicating alignment
        """
        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector '
                             f'{other.array.shape} ')
        parallel = self.parallel(other)
        antiParallel = self.antiParallel(other)

        alignedBooleans = parallel or antiParallel
        return alignedBooleans

    def orthogonal(self, other):
        """
        Determines if two vectors are orthogonal
        :param other: Instance of vector
        :return: Boolean value indicating orthogonality
        """
        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector'
                             f' {other.array.shape} ')

        dotProd = self.dot_product(other) / (self.magnitude() * other.magnitude())

        orthogonal = np.abs(dotProd) < ANGLE_TOLERANCE_1_DEG_PRL

        return orthogonal

    def normalize(self):
        """
        Returns normalized vector
        return:normalized vector
        """
        length = self.magnitude()
        if length == 0:
            return self
        unitizedVector = self.array / length

        return Vector(unitizedVector)

    def included_angle(self, other):
        """ Calculates the angle between two vectors"""
        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector'
                             f' {other.array.shape} ')

        unitVect1 = self.normalize()
        unitVect2 = other.normalize()
        dotProd = unitVect1.dot_product(unitVect2)

        if dotProd < -1:
            dotProd = -1
        elif dotProd > 1:
            dotProd = 1

        angle = np.arccos(dotProd) * 180 / np.pi

        return angle

    def direction_vector(self, other):
        """
        Computes the direction vector between two vectors
        :param other: Instance of Vector
        :return: Direction vector
        """
        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector'
                             f' {other.array.shape} ')

        return other - self

    def distance_to_vector(self, other):
        """
        Computes the distance between two vectors
        :param other: Instance of Vector
        :return: Distance between two vectors
        """
        if not self.validateOtherVector(other):
            raise ValueError(f'Shape of first vector is {self.array.shape} is not matching with second vector '
                             f'{other.array.shape} ')

        distVect = self.direction_vector(other)

        return distVect.magnitude()

    def isSameDirection(self, other):
        """
        Determines if two vectors are in same direction
        (Both of these vectors should be unit vecs)
        :param other: Instance of Vector
        :return: Boolean value indicating if the vectors are in same direction
        """
        dotProd = self.dot_product(other)

        if abs((abs(dotProd) - 1)) < ANGLE_TOLERANCE_1_DEG_PRL:
            return True
        return False

    # todo: tests to be written for following functions.
