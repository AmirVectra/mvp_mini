import itertools
from vct_o_geom.vector import *
from vct_o_geom.box_3D import Box3D

"""
Revision history

[16-Apr-25][Jagjeet]: Moved <relativeRotationMatrix> out of module, added rotateBoundingBox, getParallelAxisOfView, getAntiParallelAxisOfView, __eq__
[11-Apr-25][Jagjeet]: Corrected  <rotateVector> method  

"""


class RotationMatrix:

    def __init__(self, matrix: np.ndarray):
        self.rotationMatrix = np.reshape(matrix, (3, 3))

    def __mul__(self, other):
        return RotationMatrix(np.matmul(self.rotationMatrix, other.rotationMatrix))

    def __getitem__(self, idx_pos):
        if idx_pos in {0, "h", 'H'}:
            return self.rotationMatrix[0]
        if idx_pos in {1, "v", 'V'}:
            return self.rotationMatrix[1]
        if idx_pos in {2, "n", 'N'}:
            return self.rotationMatrix[2]
        raise ValueError("Invalid idx_pos")

    def __eq__(self, other):
        hAxis_Self = Vector(np.reshape(self.rotationMatrix[0], (1, 3)))
        vAxis_Self = Vector(np.reshape(self.rotationMatrix[1], (1, 3)))
        nAxis_Self = Vector(np.reshape(self.rotationMatrix[2], (1, 3)))

        # Fetch all the three components of other rotationMatrix
        hComp_Other = Vector(np.reshape(other.rotationMatrix[0], (1, 3)))
        vComp_Other = Vector(np.reshape(other.rotationMatrix[1], (1, 3)))
        nComp_Other = Vector(np.reshape(other.rotationMatrix[2], (1, 3)))

        return (hAxis_Self.parallel(hComp_Other) and vAxis_Self.parallel(vComp_Other) and nAxis_Self.parallel(
            nComp_Other))

    def __repr__(self):
        return f"{self.rotationMatrix}"

    def transpose(self):
        return self.rotationMatrix.T

    def inverse(self):
        """
        Computes the inverse of the matrix if applicable.
        The inverse of a square matrix exists only if the determinant is non-zero;
        :return: Inverse matrix
        """
        try:
            inverseMatrix = np.linalg.inv(self.rotationMatrix)
            return RotationMatrix(inverseMatrix)
        except np.linalg.LinAlgError:
            raise ValueError("Inverse does not exist for provided matrix")

    def transformMatrix(self, other):
        """
        Transforms the other matrix
        :param other: Instance of rotation matrix
        :return:
        """
        transformMatrix = other * self
        return transformMatrix

    def unitize(self):
        """
        Unitizes the given rotation matrix
        :return: Unitized rotation matrix
        """
        unitized_matrix = self.rotationMatrix / np.linalg.norm(self.rotationMatrix, axis=1, keepdims=True)
        return unitized_matrix

    def rowMatrix(self):
        """
        Returns the row matrix of given rotation matrix
        :return: row matrix of given rotation matrix
        """
        vector = np.reshape(np.array(self.rotationMatrix).flatten(), (1, 9))
        return vector

    def getUnitMatrix(self):
        """
        Returns the unit/identity matrix
        :return: identity matrix

        """
        return np.eye(self.rotationMatrix.shape[0])

    def getMatrixOfOnes(self):
        """
        Returns matrix filled with ones
        """
        all_ones_matrix = np.ones(self.rotationMatrix.shape)
        return all_ones_matrix

    def isValid(self):
        """
        Determines if the matrix is valid.
        # For a matrix to be a rotation matrix, it must be orthogonal, meaning (A * A^T = I) and,
        # determinant should be equal to +1
        :return: Boolean value indicating validity.
        """

        # Todo : Get tolerance value for np.allclose
        isOrthogonal = np.allclose(np.dot(self.rotationMatrix, self.rotationMatrix.T),
                                   np.identity(self.rotationMatrix.shape[0], float))
        isDeterminant_One = np.allclose(np.linalg.det(self.rotationMatrix), 1)

        return isOrthogonal and isDeterminant_One

    def isAlignedWithViewAxes(self, vector: Vector):
        """
        Determines if vector is aligned with any one of the axes of the view
        :param vector: Vector to check alignment
        :return: Boolean value indicating alignment
        """
        alignedDirections = self.alignedDirectionToView(vector=vector)
        isAligned = np.where(np.isin(np.char.lower(alignedDirections.astype(str)), ['x', 'y', 'z']),
                             True, False)
        return isAligned

    def getAlignedAxisOfView(self, vector: Vector):
        """
        Determines the axis of the view along which the vector is aligned
        :param vector:
        :return: The direction in which vector is aligned to the view
        """
        hComp = Vector(np.reshape(self.rotationMatrix[0], (1, 3)))
        vComp = Vector(np.reshape(self.rotationMatrix[1], (1, 3)))
        zComp = Vector(np.reshape(self.rotationMatrix[2], (1, 3)))
        alignedX = vector.aligned(hComp)
        alignedY = vector.aligned(vComp)
        alignedZ = vector.aligned(zComp)

        conditions = [alignedX, alignedY, alignedZ]
        values = ['x', 'y', 'z']
        alignedDirections = np.select(conditions, values, default=None)
        return alignedDirections

    def getParallelAxisOfView(self, vector: Vector):
        """
        Determines the axis of the view along which the vector is parallel
        :param vector:
        :return: The direction in which vector is aligned to the view
        """
        hComp = Vector(np.reshape(self.rotationMatrix[0], (1, 3)))
        vComp = Vector(np.reshape(self.rotationMatrix[1], (1, 3)))
        zComp = Vector(np.reshape(self.rotationMatrix[2], (1, 3)))
        parallelX = vector.parallel(hComp)
        parallelY = vector.parallel(vComp)
        parallelZ = vector.parallel(zComp)

        conditions = [parallelX, parallelY, parallelZ]
        values = ['x', 'y', 'z']
        parallelDirections = np.select(conditions, values, default=None)
        return parallelDirections

    def getAntiParallelAxisOfView(self, vector: Vector):
        """
        Determines the axis of the view along which the vector is antiparallel
        :param vector:
        :return(str): The direction in which vector is aligned to the view
        """
        hComp = Vector(np.reshape(self.rotationMatrix[0], (1, 3)))
        vComp = Vector(np.reshape(self.rotationMatrix[1], (1, 3)))
        zComp = Vector(np.reshape(self.rotationMatrix[2], (1, 3)))
        antiParallelX = vector.antiParallel(hComp)
        antiParallelY = vector.antiParallel(vComp)
        antiParallelZ = vector.antiParallel(zComp)

        conditions = [antiParallelX, antiParallelY, antiParallelZ]
        values = ['x', 'y', 'z']
        antiParallelDirections = np.select(conditions, values, default=None)
        return antiParallelDirections

    def isorthogonalRotation(self, other):
        """
        Determines if "other" is orthogonally rotated matrix of "self"
        :param other: Instance of rotation matrix
        :return: Boolean value indicating orthogonality
        """
        # Object must be an instance of class ViewMatrix
        if not isinstance(other, RotationMatrix):
            raise ValueError("Object must be an instance of ViewMatrix")

        # Checks if both matrices are valid rotation matrix
        if not self.isValid() or not other.isValid():
            raise ValueError("One or both of the  matrices is an invalid rotation matrix")

        cartesianProduct_M1M2 = itertools.product(self.rotationMatrix, other.rotationMatrix)

        # Check if all pairs of vectors in the Cartesian product have either orthogonal or aligned relationships
        isOrthogonalRotation = np.all([
            np.logical_or(
                Vector(vectors[0]).orthogonal(Vector(vectors[1])),
                Vector(vectors[0]).aligned(Vector(vectors[1]))
            )
            for vectors in cartesianProduct_M1M2
        ])
        return isOrthogonalRotation

    def rotateVector(self, vector: Vector):
        """
        Rotates the given vector with respect to the rotation matrix
        :param vector: Vector to be rotated
        :return: Rotated vector
        """
        if not isinstance(vector, Vector) or not vector.validateVector():
            raise ValueError("Either the vector is not an instance of the Vector class, or its shape is not 1*3")

        rotatedVector = np.matmul(vector.array, self.inverse().rotationMatrix)
        return Vector(rotatedVector)

    def rotateBoundingBox(self, bbox: Box3D):
        """
        Rotates the provided bounding box 

        :param bbox_r1: Box3D object having rotation matrix r1
        :return: New Box3D object

        Process flow -
        1. Compute 8 corner points and center
        2. Find the distance vectors
        3. Rotate the vectors, iterate over them and check if all v.a, v.b and v.c < 0
           means "LBD", if all >0 then "RTF"
        4. Convert back the min point using inverse rotation matrix
        5. Using this data compute the other necessary attributes and create the new bbox
        """

        # Defining the list of eight corner points
        points = ["LBD", "LBF", "LTF", "LTD", "RBD", "RBF", "RTF", "RTD"]
        # Compute the eight corner points value for the first bounding box
        bbox_Points = {point: bbox.basis_point(point) for point in points}

        # Fetch the center point
        center_Bbox = bbox.basis_point("C")

        # Distance vector of each corner points from the center, store in the dict where
        # name of the key is cp name
        distanceVectors = {cp_name: value - center_Bbox for cp_name, value in bbox_Points.items()}

        # Now rotate all the corner points using the other view matrix and store in a list
        list_RotatedVectors = [self.rotateVector(distanceVectors[point]) for point in points]

        minPoint_Vector = maxPoint_Vector = None
        # Iterate over all the rotated vectors and compute the min and the max points
        for rotated_vector in list_RotatedVectors:
            dotProduct_A, dotProduct_B, dotProduct_C = (rotated_vector.dot_product(Vector(1, 0, 0)),
                                                        rotated_vector.dot_product(Vector(0, 1, 0)),
                                                        rotated_vector.dot_product(Vector(0, 0, 1)))

            if dotProduct_A < 0 and dotProduct_B < 0 and dotProduct_C < 0:
                minPoint_Vector = rotated_vector

            if dotProduct_A > 0 and dotProduct_B > 0 and dotProduct_C > 0:
                maxPoint_Vector = rotated_vector

        # Compute the final min and max points
        minPoint = minPoint_Vector + self.rotateVector(center_Bbox)
        maxPoint = maxPoint_Vector + self.rotateVector(center_Bbox)

        # Extents of the new bounding box
        extents_Rotated_Bbox = maxPoint - minPoint

        # Retrieve the array from the extent
        extents_Rotated_Bbox = extents_Rotated_Bbox.array.reshape((3,))

        # Rotate back the min point to mcs
        inverseRotMatrix = self.inverse()
        min_point = inverseRotMatrix.rotateVector(minPoint)

        # Fetch the rotation matrix values
        rotationMatrix = self.rotationMatrix

        # Create the new bounding box object using the computed values
        rotated_Bbox = Box3D(length1=abs(extents_Rotated_Bbox[0]), length2=abs(extents_Rotated_Bbox[1]),
                             length3=abs(extents_Rotated_Bbox[2]),
                             basis_vector1=Vector(rotationMatrix[0]), basis_vector2=Vector(rotationMatrix[1]),
                             basis_vector3=Vector(rotationMatrix[2]),
                             anchor_tag="LBD", anchor_point=min_point)

        return rotated_Bbox


if __name__ == '__main__':
    ...
    # matrix = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
    # rot_obj = RotationMatrix(matrix)
    # print(rot_obj.getAlignedAxisOfView(Vector([0, 1, 0])))

