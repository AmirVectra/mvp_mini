from vct_o_geom.point import *
from typing import Union

"""
Revision History

27-FEB-2025 (Jagjeet): Added intersectionPoint_InfiniteLines function

"""


def coAxial(line1DCs: Vector, line2DCs: Vector, pointOnLine1: Point, pointOnLine2: Point):
    """
    Determines if two lines are co-axial.
    :param line1DCs: Direction cosines of line 1
    :param line2DCs: Direction cosines of line 2
    :param pointOnLine1: Point on line 1
    :param pointOnLine2: Point on line 2
    :return: Boolean value indicating co-axiality of the lines.
    """
    # Check if line1DCs and line2DCs are in the same direction.
    line1_isSameDirection_line2 = line1DCs.isSameDirection(line2DCs)

    if line1_isSameDirection_line2:
        # Compute distance between line1DCs and line2DCs
        distance = distanceBetween_ParallelLines(pointOnLine1, pointOnLine2, line1DCs)
        # Enhancement: upto tolerance 0.1
        if 0 <= distance < 0.1:
            return True

    return False


def distanceBetween_ParallelLines(pointOnLine1: Point, pointOnLine2: Point, line1DCs: Vector):
    """
    Computes the distance between parallel lines
    :param pointOnLine1: point on line 1
    :param pointOnLine2: point on line 2
    :param line1DCs: direction cosines of line 1
    :return: Distance between parallel lines
    """
    # Create distance vector from pointOnLine1 to pointOnLine2
    distanceVector = pointOnLine1.distanceVector(pointOnLine2)

    # Compute cross product (distance vector, line1DCs)
    crossProd = distanceVector.cross_product(line1DCs)

    # Return the length of the cross product vector.
    return crossProd.magnitude()


# todo: tests to be written for following functions.
# todo(Varma): Need some clarity on how this works. -> NC
def projectedPointOfVertex_OnPlane(testPoint: Point, planeEquation: [Vector, Union[int, float]], projectionVector) \
        -> Point:
    """
    Computes the projected co-ordinates of the given point on the given plane
    :param testPoint: point to be projected on the plane
    :param planeEquation: equation of plane
    :param projectionVector: projection vector of the plane
    :return: The co-ordinates of the projected point
    """
    # Check if a None object is sent
    if testPoint is None or projectionVector is None:
        return None
    # Get the normal of the plane
    planeNormal = planeEquation[0]
    # Check if planeNormal is parallel to the projectionVector.
    if planeNormal.orthogonal(projectionVector):
        return None
    # Cast Point3D object to Vector3D
    positionVector_TestPoint = Vector(testPoint[0], testPoint[1], testPoint[2])
    # Calculate the dot-product between planeNormal and projectionVector, testPoint
    dotProd_PlaneNormal_Vector = planeNormal.dot_product(projectionVector)
    dotProd_PlaneNormal_Point = planeNormal.dot_product(positionVector_TestPoint)
    numerator = -(dotProd_PlaneNormal_Point + planeEquation[1])
    scalar = numerator / dotProd_PlaneNormal_Vector
    if scalar >= 0 or abs(scalar) < 0.00001:
        # Get the projected point.
        projectedPoint = testPoint.pointAtDistance(scalar, projectionVector)
        return projectedPoint
    return None


def polygonArea(PolygonVertices: [Vector, ...]):
    """
    Computes the area of the 2D polygon
    Args:
        PolygonVertices: vertices of the polygon(Point objects) in either clockwise or anti-clockwise direction.
    Returns: Area of the given polygon
    Note: Designed to handle only a single set of points at a time.
    """
    # Return none if polygon has less than three vertices (EdgeCase for current implementation.)
    if len(PolygonVertices) < 3:
        return None

    # RefVertex remains the same throughout the function execution.
    refVertex = PolygonVertices[0]
    # Assume that the area of the polygon is zero
    areaVector = Vector(0, 0, 0)
    vertex1_Index = 1
    vertex2_Index = 2

    while vertex2_Index != len(PolygonVertices):
        vertex1 = PolygonVertices[vertex1_Index]
        vertex2 = PolygonVertices[vertex2_Index]

        directionVec_1 = refVertex.distanceVector(vertex1)
        directionVec_2 = refVertex.distanceVector(vertex2)

        # Compute the area for polygon formed by refVertex,vertex1,vertex2 (Triangle)
        Half_crossProduct = directionVec_1.cross_product(directionVec_2) / 2
        areaVector += Half_crossProduct
        # update the indices
        vertex1_Index += 1
        vertex2_Index += 1
    areaOfPolygon = areaVector.magnitude()
    return areaOfPolygon


def intersectionPt_Ray_LineSegment(ray_st_point: Point, rayDirVec: Vector, lineSegment: [Point, Point]):
    """
    Computes the intersection point
    Args:
        ray_st_point: Starting point of the ray direction vector
        rayDirVec:Vector obtained by addition of two adjacent vectors of the polygon
        lineSegment: list of two points that make up a line segment
    Returns: Intersection point
    """

    endPoint1_OfLineSeg = lineSegment[0]
    endPoint2_OfLineSeg = lineSegment[1]
    lineSegVector = endPoint1_OfLineSeg.distanceVector(endPoint2_OfLineSeg)

    rayVector = rayDirVec

    # No intersection between two parallel/anti-parallel lines.
    if lineSegVector.aligned(rayVector):
        return None

    # Left normal vectors of line segment and the ray.
    planeNormal = lineSegVector.cross_product(rayVector)
    leftNormalLinseg = planeNormal.cross_product(lineSegVector)
    leftNormalRay = planeNormal.cross_product(rayVector)

    dotProd_RayLineSeg = rayVector.dot_product(leftNormalLinseg)
    dotProd_LineSegNormalRay = lineSegVector.dot_product(leftNormalRay)

    scalar_Ray = ray_st_point.distanceVector(endPoint1_OfLineSeg).dot_product(leftNormalLinseg) / dotProd_RayLineSeg
    scalar_LS = endPoint1_OfLineSeg.distanceVector(ray_st_point).dot_product(leftNormalRay) / dotProd_LineSegNormalRay

    # Compute intersection point.
    if (0 < scalar_Ray or abs(scalar_Ray) < 1e-5) and ((0 < scalar_LS or abs(scalar_LS) < 1e-5) and
                                                       (scalar_LS < 1 or abs(abs(scalar_LS) - 1) < 1e-5)):
        intersectionPoint = (rayVector * scalar_Ray) + ray_st_point
    else:
        intersectionPoint = None
    return intersectionPoint


def getEquationOfPlane_GivenNormalAnd_PointOnPlane(normal: Vector, pointOnPlane: Point):
    """
    Computes equation of plane given normal and a point on the plane.
    :param normal: Normal vector of the plane of (instance of Vector class)
    :param pointOnPlane: point on the plane of (instance of Point class)
    :return: Equation of the plane in the form of [normal, d].
    """
    d = - (normal[0] * pointOnPlane[0] + normal[1] * pointOnPlane[1] + normal[2] * pointOnPlane[2])
    return [normal, d]


def equationOfPlane_3Points(list_points: [Point]):
    """
    Computes equation of plane given three points.
    :param list_points: List containing three instances of Point class.
    :return: Equation of plane in the form of [normal, constant].
    """
    a1 = list_points[1].distanceVector(list_points[0])
    a2 = list_points[2].distanceVector(list_points[0])
    normal_vector = a1.cross_product(a2)
    equationOfPlane = getEquationOfPlane_GivenNormalAnd_PointOnPlane(normal_vector, list_points[1])
    return equationOfPlane


def pointsBelongsToPlane(equationOfPlane: [Vector, Union[int, float]], point: Point):
    """
     Determines if a given point belongs to a plane.
    :param equationOfPlane: Equation of the plane
    :param point: Point to be checked if exists on the plane.
    :return: Boolean value indicating if the point belongs to the plane.
    """
    normal = equationOfPlane[0]
    a = normal[0]
    b = normal[1]
    c = normal[2]
    d = equationOfPlane[1]

    pointOnPlane = a * point[0] + b * point[1] + c * point[2] + d

    if abs(pointOnPlane) < 0.001:
        return True
    else:
        return False


def coPlanar(list_points: [Point, ...]):
    """
     Determines co planarity of a set of points.
    :param list_points: A list containing points.
    :return: Boolean value indicating co planarity of the points.
    """
    count_points = len(list_points)

    if count_points < 4:
        return True

    equationOfPlane = equationOfPlane_3Points(list_points[:3])

    for point in list_points[3:]:
        if not (pointsBelongsToPlane(equationOfPlane, point)):
            return False

    return True


def computeLineEndPoint(startPoint: Point, lineVector: Vector, distance: Union[int, float]):
    """
     Computes the end point of a line segment.
    :param startPoint: Starting point of the line segment.
    :param lineVector: Vector along the line segment.
    :param distance: Span of line segment
    :return:
    """

    lineEndPoint = startPoint + (lineVector * distance)
    return lineEndPoint


def collinear(line1DCs: Vector, line2DCs: Vector, pointOnLine1: Point, pointOnLine2: Point):
    """
    Determines if given lines are collinear.
    :param line1DCs: Direction cosines of line 1
    :param line2DCs: Direction cosines of line 2
    :param pointOnLine1: Point on line 1
    :param pointOnLine2: Point on line 2
    :return: Boolean value indicating if the lines are collinear.
    """
    # Check if line1DCs and line2DCs are in the same direction.
    line1_IsSameDirection_Line2 = line1DCs.isSameDirection(line2DCs)
    # Compute distance between parallel lines.
    distance = distanceBetween_ParallelLines(pointOnLine1, pointOnLine2, line1DCs)
    # Check if distance is under permissible tolerance.
    toleranceCheck_Distance = distance <= 0 and distance < 0.1

    # Check if all conditions are satisfying to decide upon collinearity.
    isCollinear = line1_IsSameDirection_Line2 and toleranceCheck_Distance
    # return an array indicating whether given lines are collinear.
    return isCollinear


def areasOfVertexLoops(vertexLoops: [[Point], ...]):
    """
    Computes the area of the given polygon(s).
    :param vertexLoops: List of vertex loops. Each vertex loop is a list of vertices of a polygon in either
        Clockwise or Anticlockwise order.
    :return: List of areas corresponding to each vertex loop.
    """
    return list(map(polygonArea, vertexLoops))


def intersectionPoint_InfiniteLines(line1_point1: Vector, line1_point2: Vector, line2_point1: Vector,
                                    line2_point2: Vector):
    """Computes the intersection point between two infinite lines
    :param line1_point1: Vector object of point 1 on line 1
    :param line1_point2: Vector object of point 2 on line 1
    :param line2_point1: Vector object of point 1 on line 2
    :param line2_point2: Vector object of point 2 on line 2
    :return: Intersection point as a Vector object or None if no intersection point exists.


    Test cases-
    # Case 1 : result (0, 0, 0)
    a1 = Vector(0,0,0)
    b1 = Vector(1,0,0)
    a2 = Vector(0,-1,0)
    b2 = Vector(0,-4,0)

    # Case 2 : result (0.5, 0.5, 0)
    # a1 = Vector(0, 0, 0)
    # b1 = Vector(1, 1, 0)
    # a2 = Vector(0, 1, 0)
    # b2 = Vector(1, 0, 0)

    # Case 3: No intersection
    # a1 = Vector(0, 0, 0)
    # b1 = Vector(1, 1, 0)
    # a2 = Vector(0, 2, 0)
    # b2 = Vector(1, 3, 0)
    """

    # Intersection occurs when two parametric equations become equal: a + t(b-a) = c + s(d-c)
    a, b = line1_point1, line1_point2
    c, d = line2_point1, line2_point2
    vec_AB = a.direction_vector(b)
    vec_CD = c.direction_vector(d)

    # aligned line segments do not intersect.
    if vec_AB.aligned(vec_CD):
        return None

    vec_AC = c - a
    orthogonalVec_CD = (vec_AB.cross_product(vec_CD)).cross_product(vec_CD)

    # solve for t & S by apply dot product of orthogonal vectors of self & other on both sides.
    scalar_T = vec_AC.dot_product(orthogonalVec_CD) / vec_AB.dot_product(orthogonalVec_CD)
    intersectionPoint = a.point_at_distance(scalar_T, vec_AB)

    return intersectionPoint


# todo: NDY
def pointInPolygon_RayCasting(polygon: [Point], testPoint: Point):
    """
        Determines whether point is inside polygon.
        Args: polygon:List having vertices(Instances of Point3D class) of a vertex loop in order.
        point: Vertex at epsilon distance to the given vertex of the polygon - Instance of Point class.
        ray:A direction vector obtained by vector addition of two adjacent edges(vectors) of the polygon - Numpy array of
             shape (1, 3)
        Returns:Boolean value indicating whether the given point is inside the polygon
        """
    rayDirection = polygon[1].distanceVector(polygon[0]).normalize()

    intersectionCount = 0
    for index in range(len(polygon)):
        activeIndex = index
        if index == len(polygon) - 1:
            nextIndex = 0
        else:
            nextIndex = index + 1
        # Tuple with two vertices of active edge of the polygon (vertex loop)
        polygonEdge = (polygon[activeIndex], polygon[nextIndex])
        # Compute intersection point
        intersectionPt = intersectionPt_Ray_LineSegment(testPoint, rayDirection, polygonEdge)
        # Count intersection points of ray direction vector with the edges in polygon.
        if intersectionPt is not None:
            intersectionCount += 1
    # True if the number of intersections is odd.
    return intersectionCount % 2 == 1


# todo: NDY
def intersectionPoint_LineSegments(a1: Point, b1: Point, a2: Point, b2: Point):
    """
    Computes the intersection point between two line segments.
    :param a1: Point object of point 1 on line 1
    :param b1: Point object of point 2 on line 1
    :param a2: Point object of point 1 on line 2
    :param b2: Point object of point 2 on line 2
    :return: Intersection point as a Point3D object or None if no intersection point exists.

    """
    return "Not Implemented Yet"
    # Create vectors between (a1, b1) and (a2, b2).
    vector1 = a1.distanceVector(b1)
    vector2 = a2.distanceVector(b2)

    # No intersection point between two parallel lines.
    if vector1.parallel(vector2):
        return None

    # Compute left normal vectors for vector1 and vector2.
    vector3 = vector1.cross_product(vector2)
    leftNormal_1 = vector3.cross_product(vector1)
    leftNormal_2 = vector3.cross_product(vector2)

    # Compute 't' & 's' value.
    a2a1_DistanceVector = a2.distanceVector(a1)
    a1a2_DistanceVector = a1.distanceVector(a2)

    t = a2a1_DistanceVector.dot_product(leftNormal_2) / vector1.dot_product(leftNormal_2)
    s = a1a2_DistanceVector.dot_product(leftNormal_1) / vector2.dot_product(leftNormal_1)

    # Compute intersection point.
    if (0 <= t <= 1) and (0 <= s <= 1):
        intersectionPoint = a1.pointAtDistance(t, vector1)
    else:
        intersectionPoint = None

    return intersectionPoint


# todo: NDY
def intersectionPointBetweenTwoRays(ray1_StartPoint: Point, ray1_VectorDCs: Vector, ray2_StartPoint: Point,
                                    ray2_VectorDCs: Vector):
    """
    Computes the intersection point between two rays.
    :param ray1_StartPoint: Starting point of the first ray
    :param ray1_VectorDCs: Direction cosines of the first ray
    :param ray2_StartPoint: Starting point of the second ray
    :param ray2_VectorDCs: Direction cosines of second ray
    :return: Intersection point if it exists, else None.
    """
    return "Not Implemented Yet"
    if ray1_StartPoint is None or ray1_VectorDCs is None or ray2_StartPoint is None or ray2_VectorDCs is None:
        return None
    aligned = ray1_VectorDCs.aligned(ray2_VectorDCs)
    if not aligned:
        return None

    # compute a vector orthogonal to both ray1 and ray2
    planeNormal = ray1_VectorDCs.cross_product(ray2_StartPoint)

    # compute a vector perpendicular to ray1
    orthogonalVector_Ray1 = planeNormal.cross_product(ray1_VectorDCs)

    # compute scalar quantity that determines the intersection point between two rays.
    dotProduct_StartPoints_OrthogonalRay1 = ray1_StartPoint.distanceVector(
        ray2_StartPoint).dot_product(orthogonalVector_Ray1)
    dotProduct_Ray2_OrthogonalRay1 = ray2_VectorDCs.dot_product(orthogonalVector_Ray1)
    intersectionParameter = dotProduct_StartPoints_OrthogonalRay1 / dotProduct_Ray2_OrthogonalRay1
    if intersectionParameter < 0:
        return None
    intersectionPoint = computeLineEndPoint(ray2_StartPoint, ray2_VectorDCs, intersectionParameter)

    return intersectionPoint