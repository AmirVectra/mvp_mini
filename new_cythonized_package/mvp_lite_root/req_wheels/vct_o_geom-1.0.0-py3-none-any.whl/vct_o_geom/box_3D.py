# from src.shared_libraries.o_geom_root.vector import Vector
from vct_o_geom.vector import Vector


class Box3D:

    def __init__(self, length1, length2, length3, basis_vector1=Vector(1, 0, 0), basis_vector2=Vector(0, 1, 0),
                 basis_vector3=Vector(0, 0, 1), anchor_tag="LBD",
                 anchor_point=Vector(0, 0, 0)):
        self.length1 = length1
        self.length2 = length2
        self.length3 = length3
        self.basis_vector1 = basis_vector1
        self.basis_vector2 = basis_vector2
        self.basis_vector3 = basis_vector3
        self.anchor_tag = anchor_tag
        self.anchor_point = anchor_point

    def basis_point(self, input_anchor_tag):

        if input_anchor_tag == self.anchor_tag:
            return self.anchor_point

        steps_to_ctr = self._steps_from_anchortag_to_ctr(self.anchor_tag, 1)
        steps_from_ctr = self._steps_from_anchortag_to_ctr(input_anchor_tag, -1)

        total_steps_to_basis_point = steps_to_ctr + steps_from_ctr

        basis_point = self.anchor_point
        for step in total_steps_to_basis_point:
            len = step[0]
            dir = step[1]
            basis_point = basis_point.point_at_distance(len, dir)
        return basis_point

    def volume(self):
        return self.length1 * self.length2 * self.length3

    def total_surface_area(self):
        return 2 * (self.length1 * self.length2 + self.length2 * self.length3 + self.length3 * self.length1)

    def _steps_from_anchortag_to_ctr(self, input_anchor_tag, dir_flag=1):

        l1, l2, l3 = self.length1, self.length2, self.length3
        bv1, bv2, bv3 = self.basis_vector1, self.basis_vector2, self.basis_vector3

        dict_steps = {

            'LBF': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag)),
                    (l3 / 2, -bv3.scalar_product(dir_flag))],
            'LBD': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag)),
                    (l3 / 2, bv3.scalar_product(dir_flag))],
            'RBF': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag)),
                    (l3 / 2, -bv3.scalar_product(dir_flag))],
            'RBD': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag)),
                    (l3 / 2, bv3.scalar_product(dir_flag))],
            'LTF': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag)),
                    (l3 / 2, -bv3.scalar_product(dir_flag))],
            'LTD': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag)),
                    (l3 / 2, bv3.scalar_product(dir_flag))],
            'RTF': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag)),
                    (l3 / 2, -bv3.scalar_product(dir_flag))],
            'RTD': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag)),
                    (l3 / 2, bv3.scalar_product(dir_flag))],
            'CBF': [(l2 / 2, bv2.scalar_product(dir_flag)), (l3 / 2, -bv3.scalar_product(dir_flag))],
            'CBD': [(l2 / 2, bv2.scalar_product(dir_flag)), (l3 / 2, bv3.scalar_product(dir_flag))],
            'CTF': [(l2 / 2, -bv2.scalar_product(dir_flag)), (l3 / 2, -bv3.scalar_product(dir_flag))],
            'CTD': [(l2 / 2, -bv2.scalar_product(dir_flag)), (l3 / 2, bv3.scalar_product(dir_flag))],
            'CLF': [(l1 / 2, bv1.scalar_product(dir_flag)), (l3 / 2, -bv3.scalar_product(dir_flag))],
            'CLD': [(l1 / 2, bv1.scalar_product(dir_flag)), (l3 / 2, bv3.scalar_product(dir_flag))],
            'CRF': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l3 / 2, -bv3.scalar_product(dir_flag))],
            'CRD': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l3 / 2, bv3.scalar_product(dir_flag))],
            'CLB': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag))],
            'CRB': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, bv2.scalar_product(dir_flag))],
            'CLT': [(l1 / 2, bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag))],
            'CRT': [(l1 / 2, -bv1.scalar_product(dir_flag)), (l2 / 2, -bv2.scalar_product(dir_flag))],
            'CF': [(l3 / 2, -bv3.scalar_product(dir_flag))],
            'CD': [(l3 / 2, bv3.scalar_product(dir_flag))],
            'CL': [(l1 / 2, bv1.scalar_product(dir_flag))],
            'CR': [(l1 / 2, -bv1.scalar_product(dir_flag))],
            'CT': [(l2 / 2, -bv2.scalar_product(dir_flag))],
            'CB': [(l2 / 2, bv2.scalar_product(dir_flag))],
            'C': []
        }
        return dict_steps[input_anchor_tag]

    @classmethod
    def createBox3D(cls, length1, length2, length3, basis_vector1=Vector(1, 0, 0), basis_vector2=Vector(0, 1, 0),
                    basis_vector3=Vector(0, 0, 1), anchor_point=Vector(0, 0, 0)):

        objBox3D = Box3D(length1, length2, length3, basis_vector1, basis_vector2, basis_vector3, anchor_tag="LBD",
                         anchor_point=anchor_point)

        return objBox3D

