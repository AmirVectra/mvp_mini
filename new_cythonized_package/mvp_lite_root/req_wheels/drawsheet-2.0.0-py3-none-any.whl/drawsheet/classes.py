from vct_o_geom.vector import  Vector
from vct_o_geom.rect_2D import Rect2D

class FixedBlock(Rect2D):
    """A class representing a fixed block within a drawing sheet.

    Fixed blocks are rectangular areas with specific positions and dimensions that
    cannot be moved. They may represent title blocks, revision tables, or other
    standard Fixed sheet elements.

    Attributes:
        FBName (str): Name identifier for the fixed block

    """

    def __init__(self, L1, L2, anchor_tag, anchor_point: Vector, fixedBlockName):
        """Initialize a new FixedBlock instance.

        Args:
            L1 (float): Width of the fixed block
            L2 (float): Height of the fixed block
            anchor_tag (str): Reference point for positioning ('LB', 'RT', etc.)
            anchor_point (Vector): Position vector for the anchor point
            fixedBlockName (str): Identifier name for the fixed block
        """
        super().__init__(L1=L1, L2=L2, anchor_tag=anchor_tag, anchor_point=anchor_point)
        self.FBName = fixedBlockName

class MarginExtension(Rect2D):
    """A class representing an extended margin area of a drawing sheet.

    Extended margins are additional rectangular areas beyond the standard margins
    that may be used for special annotations or overflow content.

    Attributes:
        extentName (str): Identifier for the margin extension ('extended_left', etc.)
    """

    def __init__(self, L1, L2, anchor_point, anchor_tag, extentName):
        """Initialize a new MarginExtension instance.

        Args:
            L1 (float): Width of the extension area
            L2 (float): Height of the extension area
            anchor_point (Vector): Position vector for the anchor point
            anchor_tag (str): Reference point for positioning ('LB', 'RT', etc.)
            extentName (str): Identifier for the margin extension
        """
        super().__init__(L1=L1, L2=L2, anchor_tag=anchor_tag, anchor_point=anchor_point)
        self.extentName = extentName

class DrawSheet(Rect2D):
    """
        Represents a sheet with specified dimensions, margins and fixed blocks(FBs)
        Attributes:
        - id (int): Identifier for the sheet.
        - name (str): Name of the sheet.
        - units (str): Units used for dimensions.
        - margins (shape.Rectangle): Rectangle representing margins on the sheet where fixed blocks are present inside.

        - fixedBlocks (dict): Dictionary of fixed blocks (rectangle objects) on the sheet.
    """

    def __init__(self, sheet_id, sheet_name, units, L1, L2, marginsDict, fixedBlocksDict):

        """
            Initializes a DrawSheet object with the specified parameters.

            Args:
                - sheet_id (int): Identifier for the sheet.
                - sheet_name (str): Name of the sheet.
                - units (str): Units used for dimensions (e.g., 'mm', 'inch').
                - L1 (float): Width of the sheet.
                - L2 (float): Height of the sheet.

                - marginsDict (dict): Dictionary specifying left, right, top, and bottom margins, with optional extended margins.
                - fixedBlocksDict (dict): Dictionary specifying fixed blocks on the sheet.
        """

        # call the constructor of the base class (shape.Rectangle)
        # super().__init__(L1=L1, L2=L2, anchor_tag="LB", anchor_point=entity.Point2D(0, 0), rectangleID=sheet_id) #Rectangle Old Class
        super().__init__(L1=L1, L2=L2, anchor_tag="LB", anchor_point=Vector(0, 0))  # Rect2D

        self.marginsDict = self.__getMargins(marginsDict)
        self.marginsDict|=self.__extendedMargins(marginsDict)


        # calculate the L1 and L2 of the margin from the given marginsDict
        marginsWidth = self.L1 - (self.marginsDict['left'] + self.marginsDict['right'])
        marginsHeight = self.L2 - (self.marginsDict['top'] + self.marginsDict['bottom'])

        # create a Point2D object representing the bottom_left (LB) corner of the margin
        marginLB = Vector(self.marginsDict['left'], self.marginsDict['bottom'])
        # create a Rectangle object for the margins.
        self.marginRect = Rect2D(L1=marginsWidth, L2=marginsHeight, anchor_tag='LB', anchor_point=marginLB)

        # fixedBlocks will have all configurations of each fixedBlocks
        self.fixedBlocks = self.__fixedBlockRectangles(fixedBlocksDict)
        self.marginExtendedBlocks=self.marginExtendedBlocks()
        self.sheet_id = sheet_id
        self.sheet_name = sheet_name
        self.units = units



    def __getMargins(self, marginsDict=None):
        """
        Private method to hold the values of sheet margins.

        Returns:
            A dictionary containing the sheet margins.
        """
        # Initialize the extended margins dictionary

        marginExtents = {
            'left': 0, 'bottom': 0, 'right': 0, 'top': 0
        }

        # Iterate over the keys of the extended margins dictionary
        for eachExtentName in marginExtents.keys():
            # If the extended margin is specified in the margins dictionary, update the extended margins dictionary
            if marginsDict.get(eachExtentName):
                marginExtents[eachExtentName] = marginsDict[eachExtentName]

        # Return the normal margins dictionary
        return marginExtents

    def __extendedMargins(self, marginsDict=None):
        """
        Private method to hold the values of extended margins.

        Returns:
            A dictionary containing the extended margins.
        """
        # Initialize the extended margins dictionary

        extendedMarginExtents = {
            'extended_left': 0, 'extended_bottom': 0, 'extended_right': 0, 'extended_top': 0
        }

        # Iterate over the keys of the extended margins dictionary
        for eachExtentName in extendedMarginExtents.keys():
            # If the extended margin is specified in the margins dictionary, update the extended margins dictionary
            if marginsDict.get(eachExtentName):
                extendedMarginExtents[eachExtentName] = marginsDict[eachExtentName]

        # Return the extended margins dictionary
        return extendedMarginExtents

    def marginExtendedBlocks(self):
        """
        Private method that returns a dictionary where the keys are the names of the extended margins and the values are the
        Rect2D objects representing the extended margins.

        Returns:
            A dictionary where the keys are the names of the extended margins and the values are the Rect2D objects representing the
            extended margins. The Rect2D objects are None if the extended margin is not specified in the margins dictionary.
        """
        # Initialize the dictionary to hold the extended margin blocks
        marginExtensionBlocks = {}

        # Get the sheet margin and the extended margins
        sheetMargin = self.marginRect
        extent = self.marginsDict

        # Define the configuration dictionary for the extended margin blocks
        # for left and extended_left, take the one with max offset width
        leftMarginMaximumExtent = max(extent['extended_left'], extent['left'])
        # for right and extended_right, take the one with max offset width
        rightMarginMaximumExtent = max(extent['extended_right'], extent['right'])
        # for top and extended_top, take the one with max offset height
        topMarginMaximumExtent = max(extent['extended_top'], extent['top'])
        # for bottom and extended_bottom, take the one with max offset height
        bottomMarginMaximumExtent = max(extent['extended_bottom'],extent['bottom'])

        marginExtentRectConfigDict = {
            'extended_left': {'L1': leftMarginMaximumExtent, 'L2': sheetMargin.L2, 'anchor_tag': 'LB',
                              'anchor_point': sheetMargin.basis_point('LB')},
            'extended_right': {'L1': rightMarginMaximumExtent, 'L2': sheetMargin.L2, 'anchor_tag': 'LB',
                               'anchor_point': Vector(sheetMargin.basis_point('RB')[0] - extent['extended_right'],
                                                      sheetMargin.basis_point('RB')[1])},
            'extended_top': {'L1': sheetMargin.L1, 'L2': topMarginMaximumExtent, 'anchor_tag': 'LB',
                             'anchor_point': Vector(sheetMargin.basis_point('LT')[0],
                                                    sheetMargin.basis_point('LT')[1] - extent['extended_top'])},
            'extended_bottom': {'L1': sheetMargin.L1, 'L2': bottomMarginMaximumExtent, 'anchor_tag': 'LB',
                                'anchor_point': sheetMargin.basis_point('LB')}
        }

        # Iterate over the keys of the extended margins dictionary
        for marginExtentName, marginExtentConfig in marginExtentRectConfigDict.items():
            # print(f'{marginExtentName}: {marginExtentConfig}')
            L1,L2=marginExtentConfig['L1'], marginExtentConfig['L2']


            # If the extended margin is specified in the margins dictionary, create a Rect2D object for the extended margin
            if extent[marginExtentName] and L1>0 and L2>0:
                marginExtensionBlocks[marginExtentName] = MarginExtension(L1=marginExtentConfig['L1'],
                                                                          L2=marginExtentConfig['L2'],
                                                                          anchor_tag=marginExtentConfig['anchor_tag'],
                                                                          anchor_point=marginExtentConfig[
                                                                              'anchor_point'],
                                                                          extentName=marginExtentName)

            # else:
            #     # Otherwise, set the value to None
            #     marginExtensionBlocks[marginExtentName] = None

        # Return the dictionary of extended margin blocks
        return marginExtensionBlocks

    def __fixedBlockRectangles(self, fixedBlocksDict):
        """
            Private method that takes in dictionary containing info on fixed blocks and converts them into Rectangle class objects
            and then stores them in the self.fixedBlocks attribute which is a dictionary.

            Args:
                fixedBlocksDict(dict): a dictionary of fixedBlocks where  name is the Key and configuration is the value for each fixedBlock.
            Returns:
                dict: a dictionary of fixedBlocks where each fixedBlock is an object of Rectangle Class.
            NOTE:
                This method takes a dictionary containing information about fixed blocks and  creates corresponding Rectangle objects.
                The input dictionary should have block names as keys, and each key should map to a dictionary
                containing H (L1-horizontal extent) , V (L2-vertical extent),anchor_point and anchor_tag  values
                representing the configuration(dimension)  of the fixed block. This method is intended for internal use within the DrawSheet class

        """
        dictRectangles = {}
        # Iterate through each fixed block in the fixedBlocksDict
        for fixedBlockName, fixedBlockConfig in fixedBlocksDict.items():
            # Extract L1 and L2 from the fixedBlockConfig
            L1 = fixedBlockConfig['H']
            L2 = fixedBlockConfig['V']
            # Extract anchor tag from the fixedBlockConfig
            anchor_tag = fixedBlockConfig['ANCHOR_TAG']

            # Extract anchor point coordinates from the fixedBlockConfig
            # anchor_point = entity.Point2D(fixedBlockConfig['ANCHOR_POINT']['X'], fixedBlockConfig['ANCHOR_POINT']['Y'])
            anchor_point = (fixedBlockConfig['ANCHOR_POINT']['X'], fixedBlockConfig['ANCHOR_POINT']['Y'])  # Rect2D

            # Create a FixedBlock object using the extracted values
            # blockRectangle = FixedBlock(L1=L1, L2=L2, anchor_tag=anchor_tag, anchor_point=anchor_point, fixedBlockName=fixedBlockName)
            blockRectangle = FixedBlock(L1=L1, L2=L2, anchor_tag=anchor_tag, anchor_point=Vector(anchor_point),
                                        fixedBlockName=fixedBlockName)

            # Add the created FixedBlock object to the dictionary of rectangles
            dictRectangles[fixedBlockName] = blockRectangle
        # Return the dictionary of fixed block rectangles
        return dictRectangles



    def getFixedBlocksDict(self):
        """
        Retrieves the dictionary of fixed blocks.

        This method provides access to the `fixedBlocks` attribute, which contains
        a dictionary of fixed blocks. A fixed block refers to a specific collection
        or group of items that remain constant or immutable within a given context.
        The content and structure of the dictionary depend on the implementation and
        usage of this attribute.

        Returns
        -------
        dict
            A dictionary containing the fixed blocks.

        """
        return self.fixedBlocks.items()

    def getMarginExtendedBlocksDict(self):
        return self.marginExtendedBlocks


