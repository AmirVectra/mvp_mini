import json
from pathlib import Path


def _createJSONFile(file_path, data=None):
    """Creates a JSON file and writes the provided data to it.

    Internal helper to safely serialize a dictionary and write it to a .json file,
    ensuring the directory structure exists.

    Args:
        file_path (str or Path): The full path where the JSON file
            will be created.
        data (dict, optional): The Python dictionary to be serialized.
            Defaults to an empty dictionary if None.

    Returns:
        bool: True if the file was successfully created, False otherwise.
    """
    # Use pathlib for robust and cross-platform path manipulation.
    path = Path(file_path)

    # Validate that the file path includes a '.json' extension.
    if path.suffix.lower() != ".json":
        print(f"Error: Invalid file extension for '{file_path}'. Please use a .json extension.")
        return False

    # Ensure the parent directory exists, creating it if necessary.
    path.parent.mkdir(parents=True, exist_ok=True)

    # Use an empty dictionary as default data if none is provided.
    if data is None:
        data = {}

    # Write the data to the file in JSON format.
    try:
        # Use write_text for concise file writing.
        # indent=4 makes the JSON file human-readable.
        path.write_text(json.dumps(data, indent=4), encoding="utf-8")
        print(f"JSON file created successfully: {path}")
        return True
    except TypeError as e:
        # Catch non-serializable objects (e.g., sets, custom classes).
        print(f"Error serializing data to JSON: {e}")
        return False
    except Exception as e:
        # Catch other potential file I/O errors (e.g., permissions).
        print(f"Error creating JSON file: {e}")
        return False


class _DrawSheetsSerialize:
    """Internal class to convert DrawSheet objects into a JSON-serializable dict.

    This class is a "translator," turning a dictionary of Python-land
    DrawSheet objects into a specific dictionary structure matching the
    required JSON output format.
    """

    def __init__(self, sheetsIdObjectDict: dict):
        """Initializes the converter.

        Args:
            sheetsIdObjectDict (dict): A dictionary mapping sheet IDs (keys) to
                their corresponding DrawSheet objects (values).
        """
        self.sheetsIdObjectDict = sheetsIdObjectDict

    def _createJSONStruct(self):
        """Builds the JSON-compatible dictionary from the DrawSheet objects.

        Iterates through each DrawSheet and maps its attributes to the
        target JSON structure.

        Returns:
            dict: A dictionary representing the complete sheets configuration,
                  ready for JSON serialization. The root key is "SHEETS".
        """
        # The root of the JSON structure.
        sheetsConfig = {"SHEETS": []}

        # Iterate through each sheet object provided during initialization.
        for sheetId, sheetObject in self.sheetsIdObjectDict.items():
            # Define the structure for a single sheet.
            sheetConfig = {
                "SHT_ID": sheetObject.sheet_id,
                "SHT_NAME": sheetObject.sheet_name,
                "UNITS": "mm",  # NOTE: Hardcoded unit. Assuming 'mm' is standard.
                "H": sheetObject.L1,
                "V": sheetObject.L2,
                "MARGIN": {
                    # Use .get() to provide default values (0) if a margin is not set.
                    "top": sheetObject.marginsDict.get('top', 0),
                    "right": sheetObject.marginsDict.get('right', 0),
                    "bottom": sheetObject.marginsDict.get('bottom', 0),
                    "left": sheetObject.marginsDict.get('left', 0),
                    "extended_top": sheetObject.marginsDict.get('extended_top', 0),
                    "extended_right": sheetObject.marginsDict.get('extended_right', 0),
                    "extended_bottom": sheetObject.marginsDict.get('extended_bottom', 0),
                    "extended_left": sheetObject.marginsDict.get('extended_left', 0),
                },
                "FIXED_BLOCKS": {}
            }

            # Process fixed blocks only if they exist on the sheet.
            if sheetObject.fixedBlocks:
                for FB_Name, FB_Object in sheetObject.fixedBlocks.items():
                    # Get the coordinates of the 'Left-Bottom' basis point.
                    LBx, LBy = FB_Object.basis_point('LB')
                    # Ensure coordinates are floats for JSON compatibility.
                    LBx, LBy = float(LBx), float(LBy)

                    # Define the structure for a single fixed block.
                    FB_Config = {
                        "H": FB_Object.L1,
                        "V": FB_Object.L2,
                        "ANCHOR_TAG": "LB",  # NOTE: Hardcoded anchor tag.
                        "ANCHOR_POINT": {
                            "X": LBx, "Y": LBy,
                        }
                    }
                    # Add the fixed block configuration to the sheet.
                    sheetConfig['FIXED_BLOCKS'][FB_Name] = FB_Config

            # Append the fully configured sheet to the main list.
            sheetsConfig['SHEETS'].append(sheetConfig)

        return sheetsConfig

    def getData(self):
        """Public method to get the serialized data.

        Returns:
            dict: The JSON-compatible dictionary created by _createJSONStruct.
        """
        return self._createJSONStruct()


def convertDrawSheetsToJSONData(sheetsIdObjectDict: dict):
    """Converts a dictionary of DrawSheet objects to a JSON-compatible dict.

    This is the public-facing wrapper for _DrawSheetsSerialize. It's the
    "easy button" for just getting the data without instantiating the
    internal class directly.

    Args:
        sheetsIdObjectDict (dict): A dictionary mapping sheet IDs to
            DrawSheet objects.

    Returns:
        dict: A dictionary representing the JSON structure of the
              sheets configuration.
    """
    drawSheetConverter = _DrawSheetsSerialize(sheetsIdObjectDict=sheetsIdObjectDict)
    return drawSheetConverter.getData()


def convertDrawSheetsToJSONFile(sheetsIdObjectDict: dict, outputJSONFilePath: str):
    """Converts DrawSheet objects and saves them directly to a JSON file.

    This function is a one-stop-shop: it handles both the data conversion
    (using convertDrawSheetsToJSONData) and the file creation.

    Args:
        sheetsIdObjectDict (dict): A dictionary of sheet IDs to
            DrawSheet objects.
        outputJSONFilePath (str): The full path to the output JSON file.
    """
    # 1. Convert the Python objects to a serializable dictionary.
    jsonData = convertDrawSheetsToJSONData(sheetsIdObjectDict)

    # 2. Write that dictionary to the specified file.
    _createJSONFile(file_path=outputJSONFilePath, data=jsonData)