import json
from .classes import DrawSheet


# -------------------- Utility -------------------- #
def loadJSON(jsonFilePath):
    """
    Loads and parses JSON data from a specified file path.

    Args:
        jsonFilePath (str): The full path to the JSON file.

    Returns:
        dict or list: The JSON data loaded from the file.

    Raises:
        ValueError: If the file is not found at the specified path or
                    if the file contains invalid JSON (e.im., malformed).
    """
    try:
        with open(jsonFilePath, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        # Re-raise FileNotFoundError as a ValueError for consistent API error handling.
        raise ValueError(f"File not found: {jsonFilePath}")
    except json.JSONDecodeError:
        # Re-raise JSONDecodeError as a ValueError to signal bad file content.
        raise ValueError(f"Invalid JSON in file: {jsonFilePath}")


# -------------------- Sheet Deserialization -------------------- #
class _DrawSheetsDeserialize:
    """
    Internal helper class to deserialize JSON data into DrawSheet objects.

    This class "rehydrates" the raw JSON data (from a file or dict)
    back into a structured collection of DrawSheet Python objects.
    """

    def __init__(self, jsonPathOrData):
        """
        Initializes the deserializer.

        This will immediately load and process the input data.

        Args:
            jsonPathOrData (str or dict): Either a file path (str)
                                          to a JSON file or a pre-loaded dictionary
                                          containing the sheet data.
        """
        # This will hold the final, rehydrated objects.
        self.sheetsIdObjectDict = {}

        # If the input is a string, assume it's a file path and load it.
        # Otherwise, assume it's already a loaded dictionary.
        sheetJSONData = (
            loadJSON(jsonPathOrData) if isinstance(jsonPathOrData, str) else jsonPathOrData
        )

        # Iterate over each sheet's data in the 'SHEETS' list from the JSON.
        for sheet in sheetJSONData['SHEETS']:
            # Create a new DrawSheet instance, mapping JSON keys to
            # the class's __init__ parameters.
            sheetInstance = DrawSheet(
                sheet_id=sheet['SHT_ID'],
                sheet_name=sheet['SHT_NAME'],
                units=sheet['UNITS'],
                L1=sheet['H'],
                L2=sheet['V'],
                marginsDict=sheet['MARGIN'],
                fixedBlocksDict=sheet['FIXED_BLOCKS'],
            )
            # Store the new sheet instance in our dictionary, keyed by its ID.
            self.sheetsIdObjectDict[sheetInstance.sheet_id] = sheetInstance

    def getSheetDict(self):
        """
        Returns the dictionary of created DrawSheet objects.

        Returns:
            dict: A dictionary where keys are sheet IDs and values are
                  the corresponding DrawSheet objects.
        """
        return self.sheetsIdObjectDict

    def getSheetList(self):
        """
        Returns a list of all created DrawSheet objects.

        Returns:
            list: A list containing all the created DrawSheet objects.
        """
        return list(self.sheetsIdObjectDict.values())


def convertJSONToDrawSheetsDict(jsonPathOrData):
    """
    Converts JSON data into a dictionary of DrawSheet objects, keyed by sheet ID.

    This is the main public function for getting sheets in a dictionary format.
    It's a convenience wrapper around the _DrawSheetsDeserialize class.

    Args:
        jsonPathOrData (str or dict): A file path to a JSON file or a
                                      pre-loaded dictionary with sheet data.

    Returns:
        dict: A dictionary mapping sheet IDs to their respective DrawSheet objects.
    """
    return _DrawSheetsDeserialize(jsonPathOrData).getSheetDict()


def convertJSONToDrawSheetsList(jsonPathOrData):
    """
    Converts JSON data into a list of DrawSheet objects.

    This function provides a simple way to get all deserialized sheets as a
    flat list, useful for when you just need to iterate over them.

    Args:
        jsonPathOrData (str or dict): A file path to a JSON file or a
                                      pre-loaded dictionary with sheet data.

    Returns:
        list: A list of all created DrawSheet objects.
    """
    return _DrawSheetsDeserialize(jsonPathOrData).getSheetList()