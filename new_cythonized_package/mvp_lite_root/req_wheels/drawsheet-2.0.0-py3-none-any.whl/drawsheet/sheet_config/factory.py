from drawsheet.classes import DrawSheet

### for a packaging
from ..sheet_config.quartile_merge.algorithm import QuartileMergeAlgorithm
from ..sheet_config.rect_working_area.algorithm import WorkingAreaRectangle

### for a developer
# from drawsheet.sheet_config.quartile_merge.algorithm import QuartileMergeAlgorithm
# from drawsheet.sheet_config.rect_working_area.algorithm import WorkingAreaRectangle

ALGORITHM_REGISTRY = {
    "QMA": QuartileMergeAlgorithm,
    "WAR":WorkingAreaRectangle


}

def runSheetConfigAlgorithm(
    algorithmName: str,
    drawSheet:DrawSheet,
    config: dict
):
    if algorithmName not in ALGORITHM_REGISTRY:
        raise ValueError(f"Unknown algorithm: {algorithmName}")

    algo_cls = ALGORITHM_REGISTRY[algorithmName]
    return algo_cls(drawSheet, config)


def run_main1():
    qmaConfig = {
        "edgesQuartileRatios": {
            'L': {'x': [0.25] * 4, 'y': [0.25] * 4},
            'R': {'x': [0.25] * 4, 'y': [0.25] * 4},
            'T': {'x': [0.25] * 4, 'y': [0.25] * 4},
            'B': {'x': [0.25] * 4, 'y': [0.25] * 4},
        },
        "allowMergeBlocks": True,
        "marginOrder": ['L', 'R', 'T', 'B'],
        "pickleDirPath": r"C:\Users\vectra\Desktop\sheet_stack_datas\Sample files"
    }
    drawsheetJSON = {
        "SHT_ID": 1,
        "SHT_NAME": "Sheet.1",
        "UNITS": "mm",
        "H": 4495.8,
        "V": 889.0,
        "MARGIN": {
            "top": 12.7,
            "right": 25.4,
            "bottom": 12.7,
            "left": 25.4,
            "extended_top": 0.0,
            "extended_right": 0.0,
            "extended_bottom": 0.0,
            "extended_left": 0.0
        },
        "FIXED_BLOCKS": {
            "Block1": {
                "H": 800.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 400.55,
                    "Y": 50.4
                }
            } ,
            "Block2": {
                "H": 500.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 2500.55,
                    "Y": 25.4
                }
            },
            "Block3": {
                "H": 600.7,
                "V": 200.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3500.55,
                    "Y": 25.4
                }
            },
            "Block4": {
                "H": 300.7,
                "V": 600.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 4100.55,
                    "Y": 100.4
                }
            },
            "Block5": {
                "H": 220.7,
                "V": 600.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 25.55,
                    "Y": 100.4
                }
            },
            "Block6": {
                "H": 500.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3900.55,
                    "Y": 750.4
                }
            },



        }}

    drawsheetObject = DrawSheet(sheet_id=drawsheetJSON['SHT_ID'], sheet_name=drawsheetJSON['SHT_NAME'],
                                L1=drawsheetJSON['H'],
                                L2=drawsheetJSON['V'],
                                marginsDict=drawsheetJSON['MARGIN'],
                                fixedBlocksDict=drawsheetJSON['FIXED_BLOCKS'], units=drawsheetJSON['UNITS'],

                                )

    algo = runSheetConfigAlgorithm(algorithmName="QMA", drawSheet=drawsheetObject, config=qmaConfig)

    updatedSheet = algo.getUpdatedDrawSheet()
    workingArea = algo.getWorkingArea()
    print(f'{updatedSheet=} {workingArea=}')

def run_main2():

    workingAreaConfig = {'displayWorkingArea': True}

    drawsheetJSON = {
        "SHT_ID": 1,
        "SHT_NAME": "Sheet.1",
        "UNITS": "mm",
        "H": 4495.8,
        "V": 889.0,
        "MARGIN": {
            "top": 12.7,
            "right": 25.4,
            "bottom": 12.7,
            "left": 25.4,
            "extended_top": 0.0,
            "extended_right": 0.0,
            "extended_bottom": 0.0,
            "extended_left": 0.0
        },
        "FIXED_BLOCKS": {
            "Block1": {
                "H": 800.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 400.55,
                    "Y": 50.4
                }
            },
            "Block2": {
                "H": 500.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 2500.55,
                    "Y": 25.4
                }
            },
            "Block3": {
                "H": 600.7,
                "V": 200.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3500.55,
                    "Y": 25.4
                }
            },
            "Block4": {
                "H": 300.7,
                "V": 600.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 4100.55,
                    "Y": 100.4
                }
            },
            "Block5": {
                "H": 220.7,
                "V": 600.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 25.55,
                    "Y": 100.4
                }
            },
            "Block6": {
                "H": 500.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3900.55,
                    "Y": 750.4
                }
            },

        }}

    drawsheetObject = DrawSheet(sheet_id=drawsheetJSON['SHT_ID'], sheet_name=drawsheetJSON['SHT_NAME'],
                                L1=drawsheetJSON['H'],
                                L2=drawsheetJSON['V'],
                                marginsDict=drawsheetJSON['MARGIN'],
                                fixedBlocksDict=drawsheetJSON['FIXED_BLOCKS'], units=drawsheetJSON['UNITS'],

                                )

    algo = runSheetConfigAlgorithm(algorithmName="WAR", drawSheet=drawsheetObject, config=workingAreaConfig)


    updatedSheet = algo.getUpdatedDrawSheet()
    workingArea = algo.getWorkingArea()
    print(f'{updatedSheet=} {workingArea=}')


if __name__ == '__main__':
    # run_main2() # for working area rectangle
    # run_main1() # for quartile merge algorithm
    pass