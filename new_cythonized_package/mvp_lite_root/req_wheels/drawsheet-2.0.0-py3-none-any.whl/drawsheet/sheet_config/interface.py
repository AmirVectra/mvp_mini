from abc import ABC, abstractmethod
from typing import Dict

from drawsheet.classes import DrawSheet


class SheetConfigAlgorithm(ABC):

    def __init__(self, drawsheet:DrawSheet, config: Dict|None):
        self.drawsheet = drawsheet
        self.config = config

    @abstractmethod
    def getWorkingArea(self):
        pass

    @abstractmethod
    def getUpdatedDrawSheet(self):
        pass
