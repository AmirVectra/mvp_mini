import matplotlib.pyplot as plt
from shapely.geometry import box


def displayWorkingArea(
       containerLBx: float,
        containerLBy: float,
        containerWidth: float,
        containerHeight: float,
        fixedBins: list,
        workingArea: object
):
    """
    Visualizes the container, fixed obstacles, and the calculated working area.

    :paramcontainerLBx: X-coordinate of the container's left-bottom corner.
    :param containerLBy: Y-coordinate of the container's left-bottom corner.
    :param containerWidth: Width of the container.
    :param containerHeight: Height of the container.
    :param fixedBins: List of fixed bin objects.
    :param workingArea: Object representing the computed working area.
    """
    fig, ax = plt.subplots(figsize=(10, 6))

    # 1. Plot the main Container boundary
    containerRect = box(
       containerLBx,
        containerLBy,
       containerLBx + containerWidth,
        containerLBy + containerHeight
    )
    cX, cY = containerRect.exterior.xy
    ax.plot(cX, cY, color='black', linestyle='--', label="Container")

    # 2. Plot all Fixed Obstacle Bins
    for binObj in fixedBins:
        lbX, lbY = binObj.basis_point("LB")[:]
        binWidth, binHeight = binObj.L1, binObj.L2

        binRect = box(lbX, lbY, lbX + binWidth, lbY + binHeight)
        bX, bY = binRect.exterior.xy
        ax.fill(bX, bY, color='red', alpha=0.3, label="Fixed Bin")

    # 3. Plot the Working Area (Shaded region)
    waLbX, waLbY = workingArea.basis_point("LB")[:]
    waW, waH = workingArea.L1, workingArea.L2
    workRect = box(waLbX, waLbY, waLbX + waW, waLbY + waH)
    wX, wY = workRect.exterior.xy

    ax.plot(wX, wY, color='blue', linewidth=2, label="Working Area")
    ax.fill(wX, wY, color='blue', alpha=0.2)

    # Styling and Layout
    ax.set_aspect("equal")
    ax.set_title("Working Area Visualization")
    ax.set_xlabel("X Coordinate")
    ax.set_ylabel("Y Coordinate")

    # Place legend outside the plot area
    ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1), borderaxespad=0)

    plt.tight_layout()
    plt.show()