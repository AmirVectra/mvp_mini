from vct_o_geom.rect_2D import Rect2D
from vct_o_geom.vector import Vector
from drawsheet.classes import DrawSheet
from typing import List, Tuple, Optional
from shapely.geometry import box, Polygon
from shapely.ops import unary_union


### for a packaging
# from ..interface import SheetConfigAlgorithm
# from .visualize import displayWorkingArea

### for a developer
from drawsheet.sheet_config.interface import SheetConfigAlgorithm
from drawsheet.sheet_config.rect_working_area.visualize import displayWorkingArea

class WorkingAreaApproximator:
    """
    Approximates the largest usable rectangular area within a container by
    subtracting fixed obstacles.

    :param containerLBx: X-coordinate of the left-bottom point of the container.
    :param containerLBy: Y-coordinate of the left-bottom point of the container.
    :param containerWidth: Total width of the container.
    :param containerHeight: Total height of the container.
    :param fixedBins: List of objects representing fixed obstacles,
                      each having a basis_point("LB") and dimensions L1, L2.
    """

    def __init__(
        self,
        containerLBx: float,
        containerLBy: float,
        containerWidth: float,
        containerHeight: float,
        fixedBins: List[object],
    ):
        # Initialize container as a shapely Polygon
        lbx, lby = containerLBx, containerLBy
        self.container: Polygon = box(
            lbx,
            lby,
            lbx + containerWidth,
            lby + containerHeight,
        )

        # Convert input objects to a list of obstacle Polygons
        self.obstacles: List[Polygon] = []
        for fixedBinRect in fixedBins:
            LBx, LBy = fixedBinRect.basis_point("LB")[:]
            width, height = fixedBinRect.L1, fixedBinRect.L2
            self.obstacles.append(box(LBx, LBy, LBx + width, LBy + height))

        # Perform geometric subtraction: Area = Container - Union(Obstacles)
        unionObs = unary_union(self.obstacles)
        self.remaining: Polygon = self.container.difference(unionObs)

    def getWorkingArea(self) -> 'Rect2D':
        """
        Calculates the maximum inner rectangle and returns it as a Rect2D object.

        :return: The calculated working area.
        :rtype: Rect2D
        """
        rect = self._MaxInnerRectangle()
        if rect is None:
            # Handle edge case where no area is available
            return Rect2D(anchor_point=(0, 0), anchor_tag="LB", L1=0, L2=0)

        minx, miny, maxx, maxy = rect.bounds
        return Rect2D(
            anchor_point=Vector(minx, miny),
            anchor_tag="LB",
            L1=(maxx - minx),
            L2=(maxy - miny)
        )

    def _MaxInnerRectangle(self) -> Optional[Polygon]:
        """
        Identifies the largest empty rectangle by checking all combinations
        of edge-aligned coordinates.

        :return: The largest rectangular Polygon found, or None.
        """
        poly = self.remaining

        # Aggregate coordinate grid from container and all obstacles
        xs = set()
        ys = set()

        minx, miny, maxx, maxy = self.container.bounds
        xs.update([minx, maxx])
        ys.update([miny, maxy])

        for obs in self.obstacles:
            ox1, oy1, ox2, oy2 = obs.bounds
            xs.update([ox1, ox2])
            ys.update([oy1, oy2])

        xs = sorted(xs)
        ys = sorted(ys)

        bestRect = None
        bestArea = 0.0

        # Iterate through all possible sub-rectangles defined by the grid
        for i in range(len(xs)):
            for j in range(i + 1, len(xs)):
                for k in range(len(ys)):
                    for l in range(k + 1, len(ys)):
                        rect = box(xs[i], ys[k], xs[j], ys[l])

                        # Validate if the rectangle is fully contained in free space
                        if poly.covers(rect):
                            area = rect.area
                            if area > bestArea:
                                bestArea = area
                                bestRect = rect

        return bestRect


class WorkingAreaRectangle(SheetConfigAlgorithm):
    """
    Algorithm to calculate and optionally display the available working area within a sheet
    by accounting for fixed blocks (obstacles) within a container rectangle.

    :param drawsheet: The drawing sheet object containing margin and block information.
    :type drawsheet: object
    :param config: Configuration dictionary, defaults to None.
    :type config: dict, optional
    """

    def __init__(self, drawsheet, config=None):
        """
        Initializes the algorithm, sets configurations, and triggers the logic flow.
        """
        super().__init__(drawsheet=drawsheet, config=config)
        self.showOutput = self.config.get("displayWorkingArea", False)
        self.fixedBins = None
        self.container = None
        self.workingArea = None
        self.runLogic()

    def __getContainer(self):
        """
        Retrieves the main margin rectangle from the drawsheet to act as the container.
        """
        self.container = self.drawsheet.marginRect

    def __getFixedBins(self):
        """
        Extracts fixed block rectangles from the drawsheet to define exclusion zones.
        """
        fixedBins = []
        for fixedBlockName, FixedBlockRect in self.drawsheet.getFixedBlocksDict():
            fixedBins.append(FixedBlockRect)
        self.fixedBins = fixedBins

    def __getWorkingArea(self):
        """
        Calculates the available working area using the WorkingAreaApproximator
        based on the container dimensions and identified fixed bins.
        """
        containerLBx, containerLBy = self.container.basis_point("LB")[:]
        approximater = WorkingAreaApproximator(
            containerLBx=containerLBx,
            containerLBy=containerLBy,
            containerWidth=self.container.L1,
            containerHeight=self.container.L2,
            fixedBins=self.fixedBins
        )
        self.workingArea = approximater.getWorkingArea()

    def runLogic(self):
        """
        Executes the internal calculation pipeline and triggers visualization if enabled.
        """
        self.__getFixedBins()
        self.__getContainer()
        self.__getWorkingArea()
        if self.showOutput:
            self.displayWorkingArea()

    def getWorkingArea(self):
        """
        Returns the calculated working area.

        :return: The computed working area object.
        :rtype: object
        """
        return self.workingArea

    def getUpdatedDrawSheet(self):
        """
        Returns the drawsheet instance associated with this algorithm.

        :return: The current drawsheet.
        :rtype: object
        """
        return self.drawsheet

    def displayWorkingArea(self):
        """
        Visualizes the container, fixed bins, and the resulting calculated working area.
        """
        containerLBx, containerLBy = self.container.basis_point("LB")[:]
        displayWorkingArea(
            containerLBy=containerLBy,
            containerLBx=containerLBx,
            containerWidth=self.container.L1,
            containerHeight=self.container.L2,
            fixedBins=self.fixedBins,
            workingArea=self.workingArea
        )


def main1():
    containerLBx,containerLBy = (0, 0)
    containerWidth, containerHeight = 1000, 600

    fixedBins = [
        (0, 550, 200, 50),
        (400, 550, 250, 50),
        (0, 0, 150, 60),
        (900, 0, 100, 120),
        (0, 200, 80, 200),
        (920, 250, 80, 200),
    ]
    wa = WorkingAreaApproximator(
        containerLBx=containerLBx,
        containerLBy=containerLBy,
        containerWidth=containerWidth,
        containerHeight=containerHeight,
        fixedBins=fixedBins,

    )

    workingArea = wa.getWorkingArea()

    displayWorkingArea(
        containerLBx,
        containerLBy,
        containerWidth,
        containerHeight,
        fixedBins,
        workingArea,
    )


def main2():
    drawsheetJSON = {
        "SHT_ID": 1,
        "SHT_NAME": "Sheet.1",
        "UNITS": "mm",
        "H": 4495.8,
        "V": 889.0,
        "MARGIN": {
            "top": 12.7,
            "right": 25.4,
            "bottom": 12.7,
            "left": 25.4,
            "extended_top": 0.0,
            "extended_right": 0.0,
            "extended_bottom": 0.0,
            "extended_left": 0.0
        },
        "FIXED_BLOCKS": {
            "Block1": {
                "H": 800.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 400.55,
                    "Y": 50.4
                }
            } ,
            "Block2": {
                "H": 500.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 2500.55,
                    "Y": 25.4
                }
            },
            "Block3": {
                "H": 600.7,
                "V": 200.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3500.55,
                    "Y": 25.4
                }
            },
            "Block4": {
                "H": 300.7,
                "V": 600.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 4100.55,
                    "Y": 100.4
                }
            },
            "Block5": {
                "H": 220.7,
                "V": 600.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 25.55,
                    "Y": 100.4
                }
            },
            "Block6": {
                "H": 500.7,
                "V": 100.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3900.55,
                    "Y": 750.4
                }
            },



        }}

    drawsheetObject = DrawSheet(sheet_id=drawsheetJSON['SHT_ID'], sheet_name=drawsheetJSON['SHT_NAME'],
                                L1=drawsheetJSON['H'],
                                L2=drawsheetJSON['V'],
                                marginsDict=drawsheetJSON['MARGIN'],
                                fixedBlocksDict=drawsheetJSON['FIXED_BLOCKS'], units=drawsheetJSON['UNITS'],

                                )


    waf=WorkingAreaRectangle(drawsheetObject,config={'displayWorkingArea': True})
    print(f"{waf.getWorkingArea()=}")
    # waf.displayWorkingArea()


if __name__ == '__main__':
    # main1() # for WorkingAreaApproximator base logic
    main2()  # for WorkingAreaRectangle for drawsheet
    pass
