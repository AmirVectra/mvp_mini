from dataclasses import dataclass, field
from typing import Dict, List
from typing import Optional, Literal


@dataclass
class EdgeQuartile:
    """
    Computes quartile boundary coordinates (Q0–Q4) along both X and Y axes
    for a given rectangular region edge.

    Quartile values are calculated lazily using ratio-based segmentation
    of the rectangle's width and height.

    Coordinate conventions:
    - Q0 represents the lower/starting boundary (LBx / LBy)
    - Q4 represents the upper/ending boundary (LBx + width / LBy + height)
    - Q1–Q3 are intermediate quartile boundaries

    Typical use cases:
    - Edge-based spatial partitioning
    - Layout segmentation
    - Image or geometry processing

    Attributes
    ----------
    edge_type : Literal["L", "R", "T", "B"]
        Identifies the edge (Left, Right, Top, Bottom).

    x_ratios : List[float]
        Ratios defining quartile divisions along the X-axis.
        Expected length ≥ 4; values typically sum to 1.0.

    y_ratios : List[float]
        Ratios defining quartile divisions along the Y-axis.
        Expected length ≥ 4; values typically sum to 1.0.

    LBx : float
        X-coordinate of the lower-left corner of the region.

    LBy : float
        Y-coordinate of the lower-left corner of the region.

    width : float
        Total width of the region along the X-axis.

    height : float
        Total height of the region along the Y-axis.
    """

    edge_type: Literal["L", "R", "T", "B"]
    x_ratios: List[float]
    y_ratios: List[float]
    LBx: float
    LBy: float
    width: float
    height: float

    # ---------- X AXIS QUARTILE BOUNDARIES ----------

    @property
    def Q0x(self) -> float:
        """Starting X boundary (left-most coordinate)."""
        return self.LBx

    @property
    def Q1x(self) -> float:
        """First quartile boundary along the X-axis."""
        return self.LBx + self.width * self.x_ratios[0]

    @property
    def Q2x(self) -> float:
        """Second quartile (median) boundary along the X-axis."""
        return self.LBx + self.width * (self.x_ratios[0] + self.x_ratios[1])

    @property
    def Q3x(self) -> float:
        """Third quartile boundary along the X-axis."""
        return self.LBx + self.width * (
                self.x_ratios[0] + self.x_ratios[1] + self.x_ratios[2]
        )

    @property
    def Q4x(self) -> float:
        """Final X boundary (right-most coordinate)."""
        return self.LBx + self.width * sum(self.x_ratios)

    # ---------- Y AXIS QUARTILE BOUNDARIES ----------

    @property
    def Q0y(self) -> float:
        """Starting Y boundary (bottom-most coordinate)."""
        return self.LBy

    @property
    def Q1y(self) -> float:
        """First quartile boundary along the Y-axis."""
        return self.LBy + self.height * self.y_ratios[0]

    @property
    def Q2y(self) -> float:
        """Second quartile (median) boundary along the Y-axis."""
        return self.LBy + self.height * (self.y_ratios[0] + self.y_ratios[1])

    @property
    def Q3y(self) -> float:
        """Third quartile boundary along the Y-axis."""
        return self.LBy + self.height * (
                self.y_ratios[0] + self.y_ratios[1] + self.y_ratios[2]
        )

    @property
    def Q4y(self) -> float:
        """Final Y boundary (top-most coordinate)."""
        return self.LBy + self.height * sum(self.y_ratios)


@dataclass
class SheetEdgeQuartiles:
    """
    Factory and configuration holder for EdgeQuartile objects
    corresponding to the four edges of a sheet or rectangular region.

    This class:
    - Stores geometry (width, height, origin)
    - Stores per-edge, per-axis quartile ratio definitions
    - Produces EdgeQuartile instances lazily via properties

    Coordinate system:
    - LBx, LBy define the lower-left origin of the sheet
    - Width extends along +X, height extends along +Y

    Quartile ratios:
    - Defined per edge ("L", "R", "T", "B") and axis ("x", "y")
    - Each ratio list should sum to 1.0
    - Falls back to equal quartiles if invalid or missing
    """

    width: float
    height: float
    LBx: float = 0.0
    LBy: float = 0.0

    # Structure:
    # {
    #   "L": {"x": [...], "y": [...]},
    #   "R": {"x": [...], "y": [...]},
    #   "T": {"x": [...], "y": [...]},
    #   "B": {"x": [...], "y": [...]},
    # }
    edgesQuartileRatios: Dict[str, Dict[str, List[float]]] = field(default_factory=dict)

    def _ratios(self, edge: str, axis: str) -> List[float]:
        """
        Returns validated quartile ratios for a given edge and axis.

        - Retrieves configured ratios if present
        - Ensures ratios sum to 1.0 (within tolerance)
        - Falls back to equal quartiles otherwise

        Parameters
        ----------
        edge : str
            One of "L", "R", "T", "B"
        axis : str
            Either "x" or "y"

        Returns
        -------
        List[float]
            A list of quartile ratios summing to 1.0
        """
        default = [0.25, 0.25, 0.25, 0.25]

        # Fetch configured ratios if available
        r = self.edgesQuartileRatios.get(edge, {}).get(axis, default)

        # Validate numerical correctness (floating-point safe)
        final_ratios = r if abs(sum(r) - 1.0) < 1e-9 else default

        return final_ratios

    # ---------- EDGE QUARTILE FACTORIES ----------

    @property
    def L(self) -> EdgeQuartile:
        """Quartile boundaries for the Left edge."""
        return EdgeQuartile(
            "L",
            self._ratios("L", "x"),
            self._ratios("L", "y"),
            self.LBx,
            self.LBy,
            self.width,
            self.height,
        )

    @property
    def R(self) -> EdgeQuartile:
        """Quartile boundaries for the Right edge."""
        return EdgeQuartile(
            "R",
            self._ratios("R", "x"),
            self._ratios("R", "y"),
            self.LBx,
            self.LBy,
            self.width,
            self.height,
        )

    @property
    def T(self) -> EdgeQuartile:
        """Quartile boundaries for the Top edge."""
        return EdgeQuartile(
            "T",
            self._ratios("T", "x"),
            self._ratios("T", "y"),
            self.LBx,
            self.LBy,
            self.width,
            self.height,
        )

    @property
    def B(self) -> EdgeQuartile:
        """Quartile boundaries for the Bottom edge."""
        return EdgeQuartile(
            "B",
            self._ratios("B", "x"),
            self._ratios("B", "y"),
            self.LBx,
            self.LBy,
            self.width,
            self.height,
        )
