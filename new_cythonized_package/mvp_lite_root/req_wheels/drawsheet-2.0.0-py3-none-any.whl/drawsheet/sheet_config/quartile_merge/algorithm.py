import copy
import pickle
from pathlib import Path



## for developer
from drawsheet.classes import DrawSheet, FixedBlock
from drawsheet.sheet_config.interface import SheetConfigAlgorithm
from vct_o_geom.vector import Vector
from drawsheet.sheet_config.quartile_merge.models import SheetEdgeQuartiles


class QuartileMergeAlgorithm(SheetConfigAlgorithm):
    """
    Implements a quartile-based algorithm for merging and managing fixed blocks on a sheet.

    This class is designed to process a given drawing sheet and implement quartile-based
    calculations for managing fixed blocks. It provides mechanisms for calculating geometry,
    evaluating spatial rules, and filtering fixed blocks based on various constraints.
    The outputs can be used for further processing and rendering on the drawing sheet.

    """

    def __init__(self, drawsheet: DrawSheet, config: dict):
        super().__init__(drawsheet=drawsheet, config=config)

        edgesQuartileRatios = config.get("edgesQuartileRatios")
        allowMergeBlocks = config.get("allowMergeBlocks", False)
        marginOrder = config.get("marginOrder", ['L', 'R', 'T', 'B'])
        pickleDirPath = config.get("pickleDirPath")

        self.marginOrder = marginOrder
        self.marginWise_WithBlockTagsResolved = {}
        self.allowMergeBlocks = allowMergeBlocks


        if pickleDirPath is not None:
            p = Path(pickleDirPath)
            self.pickleDirPath = p if p.exists() and p.is_dir() else None
        else:
            self.pickleDirPath = None

        # ---- Sheet geometry ----
        sheet_bounds = drawsheet.boundingRectangle()
        LB = sheet_bounds.basis_point("LB")
        RT = sheet_bounds.basis_point("RT")

        self.LBx, self.LBy = LB
        self.width = RT[0] - LB[0]
        self.height = RT[1] - LB[1]

        # ---- Quartile model ----
        self.quartiles = SheetEdgeQuartiles(
            width=self.width,
            height=self.height,
            LBx=self.LBx,
            LBy=self.LBy,
            edgesQuartileRatios=edgesQuartileRatios or {}
        )

        self.marginWise_WithBlockTags = {"L": [], "R": [], "T": [], "B": []}
        self.MergedBlockCount = 0

        self.FBNameWithObject = self.drawsheet.fixedBlocks

        # output of quartile merge algorithm
        self.extendLeftMarginOffset = 0
        self.extendRightMarginOffset = 0
        self.extendTopMarginOffset = 0
        self.extendBottomMarginOffset = 0
        self.mergedFixedBlocks = {}

        self.resultantDrawSheet = copy.deepcopy(self.drawsheet)
        self.runLogic()

    def FBNamesBasedOnMarginRules(self, marginName):
        """
        Filters and retrieves a list of fixed block names based on specific consolidation rules for a given margin.
        The function evaluates each fixed block configuration against predetermined conditions for one of
        the following margins: left ('L'), right ('R'), bottom ('B'), or top ('T'). The quartiles and spatial
        coordinates of each fixed block are analyzed to determine eligible blocks that comply with the rules.

        :param marginName: The margin for which the fixed blocks need to be evaluated ('L', 'R', 'B', or 'T')
        :type marginName: str

        :return: List of names of fixed blocks that satisfy the rules for the specified margin
        :rtype: list
        """

        FBNamesList = []

        # Check each fixed block against consolidation rules for the specified margin
        for fixedBlockName, fixedBlockConfigs in self.drawsheet.fixedBlocks.items():
            # Check conditions based on the specified marginName
            if marginName == 'L':

                bottomQuartiles = self.quartiles.B
                # Consider FBs whose x_min = [0, Q1_x] range & x_max < Q2_x
                condition1 = bottomQuartiles.Q0x <= fixedBlockConfigs.minXCoord() <= bottomQuartiles.Q1x
                condition2 = fixedBlockConfigs.maxXCoord() <= bottomQuartiles.Q2x
                if condition1 and condition2:
                    # Add the fixed block name to the list if it meets the condition
                    FBNamesList.append(fixedBlockName)

            if marginName == 'R':

                topQuartiles = self.quartiles.T
                # Consider FBs whose x_min > Q2_X and x_max is in [Q3_X, Q4_X] range
                condition1 = fixedBlockConfigs.minXCoord() >= topQuartiles.Q2x
                condition2 = topQuartiles.Q3x <= fixedBlockConfigs.maxXCoord() <= topQuartiles.Q4x
                if condition1 and condition2:
                    # Add the fixed block name to the list if it meets the condition
                    FBNamesList.append(fixedBlockName)

            if marginName == 'B':
                leftQuartiles = self.quartiles.L
                # Consider FBs whose y_min = [0, Q1_Y] range and y_max <= Q2_Y
                condition1 = leftQuartiles.Q0y <= fixedBlockConfigs.minYCoord() <= leftQuartiles.Q1y
                condition2 = fixedBlockConfigs.maxYCoord() <= leftQuartiles.Q2y
                if condition1 and condition2:
                    # Add the fixed block name to the list if it meets the condition
                    FBNamesList.append(fixedBlockName)

            if marginName == 'T':
                rightQuartiles = self.quartiles.R
                # Consider FBs whose y_min > Q2_Y and y_max is in [Q3_Y, Q4_Y] range
                condition1 = fixedBlockConfigs.minYCoord() >= rightQuartiles.Q2y
                condition2 = rightQuartiles.Q3y <= fixedBlockConfigs.maxYCoord() <= rightQuartiles.Q4y
                if condition1 and condition2:
                    # Add the fixed block name to the list if it meets the condition
                    FBNamesList.append(fixedBlockName)
        # Return the list of fixed block names that meet the consolidation rules based on specified marginName

        return FBNamesList

    def FB_withMaxX(self, FBNameList):
        """
        Returns the FBName whose maxXCoord is the highest.
        Returns None if list is empty or invalid.
        """
        best_fb_name = None
        best_max_x = None

        for fb_name in FBNameList:
            fb = self.drawsheet.fixedBlocks.get(fb_name)
            if not fb:
                continue

            max_x = fb.maxXCoord()

            if best_max_x is None or max_x > best_max_x:
                best_max_x = max_x
                best_fb_name = fb_name

        return best_fb_name

    def FB_withMaxY(self, FBNameList):
        """
        Returns the FBName whose maxYCoord is the highest.
        """
        best_name = None
        best_value = None

        for fb_name in FBNameList:
            fb = self.drawsheet.fixedBlocks.get(fb_name)
            if not fb:
                continue

            value = fb.maxYCoord()

            if best_value is None or value > best_value:
                best_value = value
                best_name = fb_name

        return best_name

    def FB_withMinX(self, FBNameList):
        """
        Returns the FBName whose minXCoord is the lowest.
        """
        best_name = None
        best_value = None

        for fb_name in FBNameList:
            fb = self.drawsheet.fixedBlocks.get(fb_name)
            if not fb:
                continue

            value = fb.minXCoord()

            if best_value is None or value < best_value:
                best_value = value
                best_name = fb_name

        return best_name

    def FB_withMinY(self, FBNameList):
        """
        Returns the FBName whose minYCoord is the lowest.
        """
        best_name = None
        best_value = None

        for fb_name in FBNameList:
            fb = self.drawsheet.fixedBlocks.get(fb_name)
            if not fb:
                continue

            value = fb.minYCoord()

            if best_value is None or value < best_value:
                best_value = value
                best_name = fb_name

        return best_name

    def filterFBsByMarginQuartile(self, FBNamesList, marginName, quartile):
        """
        Filters a list of fixed blocks (FBs) by their position relative to a specified
        margin and quartile. This method helps in categorizing FBs that fall within a
        quartile range along the specified margin axis.

        :param FBNamesList: List of string identifiers for fixed blocks to filter.
        :param marginName: Specifies the margin axis to evaluate. Valid values are:
                           'L', 'R', 'T', 'B' for Left, Right, Top, Bottom margins.
        :param quartile: Specifies which quartile range to use for filtering along the
                         margin. Valid values are:
                         - 1: Q0y (or Q0x) to Q1y (or Q1x)
                         - 2: Q1y (or Q1x) to Q2y (or Q2x)
                         - 3: Q2y (or Q2x) to Q3y (or Q3x)
                         - 4: Q3y (or Q3x) to Q4y (or Q4x)
        quartile can be:
                1 -> Q0y to Q1y
                2 -> Q1y to Q2y
                3 -> Q2y to Q3y
                4 -> Q3y to Q4y
        :return: A list of fixed block names from `FBNamesList` that fall within the
                 specified quartile range and margin axis.
        :rtype: list of str

        :raises ValueError: If an invalid `quartile` is provided (not in 1, 2, 3, 4).
        """

        if quartile not in (1, 2, 3, 4):
            raise ValueError("quartile must be 1, 2, 3, or 4")

        margin_map = {
            'L': self.quartiles.L,
            'R': self.quartiles.R,
            'T': self.quartiles.T,
            'B': self.quartiles.B,
        }

        q = margin_map[marginName]

        # Decide axis based on margin
        if marginName in ('L', 'R'):
            bounds = [q.Q0y, q.Q1y, q.Q2y, q.Q3y, q.Q4y]
        else:  # 'T', 'B'
            bounds = [q.Q0x, q.Q1x, q.Q2x, q.Q3x, q.Q4x]

        low = bounds[quartile - 1]
        high = bounds[quartile]

        result = []
        for fb_name in FBNamesList:
            fb = self.drawsheet.fixedBlocks.get(fb_name)
            if not fb:
                continue
            if marginName in ['L', "R"]:
                if low <= fb.minYCoord() <= high:
                    result.append(fb_name)
            elif marginName in ['T', "B"]:
                if low <= fb.minXCoord() <= high:
                    result.append(fb_name)

        return result

    def analyzeLeftMarginForQuartiles(self, FbNamesListForLeftMargin):
        """
        Analyzes the position of fixed blocks (FBs) along the left margin based on the given quartile ranges and tags
        the fixed blocks accordingly. Quartiles define boundaries on the Y-axis. The function processes fixed blocks
        grouped into quartiles to assign tags such as 'MB' or 'ME' based on their properties such as maximum X and Y
        coordinates and their occurrences in specific quartile ranges.

        This method uses the following logic:
        1. FBs are grouped into quartiles based on their Y-axis position.
        2. For each quartile, specific conditions are checked:
           - The maximum Y-coordinate (`y_max`) of a block is compared to boundaries for quartiles.
           - Comparisons of the maximum X-coordinate (`x_max`) among blocks in neighboring quartiles.
           - Overlapping checks involving blocks from other quartiles.
        3. Tags are assigned as 'MB' or 'ME' based on these rules.

        :param FbNamesListForLeftMargin: List of fixed block names, where each block represents data to be analyzed.
        :type FbNamesListForLeftMargin: list
        :return: None
        """
        firstQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForLeftMargin,
                                                          quartile=1, marginName='L')
        secondQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForLeftMargin, quartile=2,
                                                           marginName='L')
        thirdQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForLeftMargin, quartile=3,
                                                          marginName='L')
        fourthQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForLeftMargin, quartile=4,
                                                           marginName='L')

        # For FBs in 1st quartile (0 < y_min < Y/4)
        for FBName in firstQuartileFBs:
            FBObject = self.FBNameWithObject[FBName]

            # If y_max <= Y/4, tag it as MB
            if FBObject.maxYCoord() <= self.quartiles.L.Q1y:
                self.marginWise_WithBlockTags['L'].append({FBName: 'MB'})
            # If Y/4 <= y_max < Y/2
            # If any blocks present in 3rd or 4th quartiles, tag as ME
            # Else, tag as MB

            if self.quartiles.L.Q1y <= FBObject.maxYCoord() < self.quartiles.L.Q2y:
                if (FBName in thirdQuartileFBs) or (FBName in fourthQuartileFBs):
                    self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})
                else:
                    self.marginWise_WithBlockTags['L'].append({FBName: 'MB'})
            # If y_max >= Y/2, tag as ME
            if FBObject.maxYCoord() >= self.quartiles.L.Q2y:
                self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})

        FBNameForQ1WithHighestMaxX = self.FB_withMaxX(FBNameList=firstQuartileFBs)
        # For FBs in 2nd quartile (Y/4 < y_min < Y/2)
        for FBName in secondQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            # If Y/4 < y_max < Y/2
            if self.quartiles.L.Q1y <= activeFBObject.maxYCoord() <= self.quartiles.L.Q2y:
                # Identify blocks in 1st quartile with highest x_max
                if FBNameForQ1WithHighestMaxX:
                    FBObject = self.FBNameWithObject[FBName]
                    highest_xMax = FBObject.maxXCoord()
                    # Identify blocks in 1st quartile with highest x_max
                    # If active block is smaller, tag it as ME
                    if activeFBObject.maxXCoord() < highest_xMax:
                        self.marginWise_WithBlockTags['L'].append({FBNameForQ1WithHighestMaxX: 'ME'})
                    # If active block is larger (xmax>=highest_xmax)
                    elif activeFBObject.maxXCoord() >= highest_xMax:
                        # If any blocks present in 3rd or 4th quartiles, tag it as ME
                        if thirdQuartileFBs and fourthQuartileFBs:
                            self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})
                        else:
                            self.marginWise_WithBlockTags['L'].append({FBName: 'MB'})
            # If y_max >= Y/2
            if activeFBObject.maxYCoord() >= self.quartiles.L.Q2y:
                self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})

        FBNameForQ4WithHighestMaxX = self.FB_withMaxX(FBNameList=fourthQuartileFBs)

        for FBName in thirdQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            #    If Y/2 <= y_max < 3Y/4)
            if self.quartiles.L.Q2y <= activeFBObject.maxYCoord() <= self.quartiles.L.Q3y:
                # Identify blocks in 4th quartile with highest x_max
                highest_xMax = self.FBNameWithObject[FBNameForQ4WithHighestMaxX].maxXCoord()
                #  If active block is smaller, tag it as ME (xmax<highest_xmax)
                if activeFBObject.maxXCoord() < highest_xMax:
                    self.marginWise_WithBlockTags['L'].append({FBNameForQ1WithHighestMaxX: 'ME'})
                # If active block is larger (xmax>=highest_xmax)
                elif activeFBObject.maxXCoord() >= highest_xMax:
                    # If any blocks present in 3rd or 4th quartiles, tag it as ME
                    if thirdQuartileFBs and fourthQuartileFBs:
                        self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})
                    else:
                        self.marginWise_WithBlockTags['L'].append({FBName: 'MB'})
            # If y_max >= 3Y/4, tag the block as ME
            if activeFBObject.maxYCoord() >= self.quartiles.L.Q3y:
                self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})

        # For FBs in 4th quartile (3Y/4 <= y_min <= Y)
        for FBName in fourthQuartileFBs:
            # Tag as MB
            self.marginWise_WithBlockTags['L'].append({FBName: 'MB'})

    def analyzeLeftMarginForLargeBlock(self):
        """
        Analyzes and tags fixed blocks based on their placement relative to the left
        margin and predefined quartile boundaries. The method ensures blocks are
        classified as either 'ME' (Margin Edge) or 'MB' (Margin Beyond) based on their
        proximity to the left margin and their maximum y-coordinate. Additional blocks
        are tagged based on the classification of the highest X-coordinate block
        within the left margin analysis.

        :return: True if other blocks were tagged as 'MB', otherwise False
        :rtype: bool
        """
        tagOthersAsME = False
        tagOthersAsMB = False
        FBNamesListForLeftMargin = self.FBNamesBasedOnMarginRules('L')
        FBWithHighestMaxX = self.FB_withMaxX(FBNamesListForLeftMargin)
        if FBWithHighestMaxX:
            FBObject = self.FBNameWithObject[FBWithHighestMaxX]
            if self.quartiles.L.Q1y <= FBObject.maxYCoord() <= self.quartiles.L.Q3y:
                self.marginWise_WithBlockTags['L'].append({FBWithHighestMaxX: 'ME'})
                tagOthersAsME = True
            else:
                self.marginWise_WithBlockTags['L'].append({FBWithHighestMaxX: 'MB'})
                tagOthersAsMB = True
        if tagOthersAsME:
            for FBName in FBNamesListForLeftMargin:
                if FBName != FBWithHighestMaxX:
                    self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})
        if tagOthersAsMB:
            for FBName in FBNamesListForLeftMargin:
                if FBName != FBWithHighestMaxX:
                    self.marginWise_WithBlockTags['L'].append({FBName: 'MB'})
            return True
        return False

    def analyzeRightMarginForQuartiles(self, FbNamesListForRightMargin):
        """
        Analyzes the right margin of a set of fixed blocks (FBs) and assigns tags based on their positions within
        quartiles. Each FB is evaluated and tagged as either 'ME' (Margin Edge) or 'MB' (Margin Block) based
        on its attributes and positional relationships with other blocks in corresponding quartiles.

        :param FbNamesListForRightMargin: List of FB names to analyze within the right margin.
        :type FbNamesListForRightMargin: list[str]
        :return: None
        """
        firstQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForRightMargin,
                                                          quartile=1, marginName='R')
        secondQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForRightMargin, quartile=2,
                                                           marginName='R')
        thirdQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForRightMargin, quartile=3,
                                                          marginName='R')
        fourthQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForRightMargin, quartile=4,
                                                           marginName='R')

        # For FBs in 1st quartile (0 < y_min < Y/4)
        for FBName in firstQuartileFBs:
            FBObject = self.FBNameWithObject[FBName]

            # If y_max <= Y/4, tag it as MB
            if FBObject.maxYCoord() <= self.quartiles.R.Q1y:
                self.marginWise_WithBlockTags['R'].append({FBName: 'MB'})
            # If Y/4 <= y_max < Y/2
            # If any blocks present in 3rd or 4th quartiles, tag as ME
            # Else, tag as MB

            if self.quartiles.R.Q1y <= FBObject.maxYCoord() < self.quartiles.R.Q2y:
                if (FBName in thirdQuartileFBs) or (FBName in fourthQuartileFBs):
                    self.marginWise_WithBlockTags['R'].append({FBName: 'ME'})
                else:
                    self.marginWise_WithBlockTags['R'].append({FBName: 'MB'})
            # If y_max >= Y/2, tag as ME
            if FBObject.maxYCoord() >= self.quartiles.R.Q2y:
                self.marginWise_WithBlockTags['R'].append({FBName: 'ME'})

        FBNameForQ1WithLowestMinX = self.FB_withMinX(FBNameList=firstQuartileFBs)
        # For FBs in 2nd quartile (Y/4 < y_min < Y/2)
        for FBName in secondQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            # If Y/4 < y_max < Y/2
            if self.quartiles.R.Q1y <= activeFBObject.maxYCoord() <= self.quartiles.R.Q2y:
                # Identify blocks in 1st quartile with Lowest x_min
                if FBNameForQ1WithLowestMinX:
                    FBObject = self.FBNameWithObject[FBName]
                    lowest_xMin = FBObject.minXCoord()
                    # Identify blocks in 1st quartile with lowest x_min
                    # If active block is smaller, tag it as ME
                    if activeFBObject.minXCoord() > lowest_xMin:
                        self.marginWise_WithBlockTags['R'].append({FBNameForQ1WithLowestMinX: 'ME'})
                    # If active block is larger (xmin<=lowest_xmin)
                    elif activeFBObject.minXCoord() <= lowest_xMin:
                        # If any blocks present in 3rd or 4th quartiles, tag it as ME
                        if thirdQuartileFBs and fourthQuartileFBs:
                            self.marginWise_WithBlockTags['R'].append({FBName: 'ME'})
                        else:
                            self.marginWise_WithBlockTags['R'].append({FBName: 'MB'})
            # If y_max >= Y/2
            if activeFBObject.minYCoord() >= self.quartiles.R.Q2y:
                self.marginWise_WithBlockTags['R'].append({FBName: 'ME'})

        FBNameForQ4WithLowestMinX = self.FB_withMinX(FBNameList=fourthQuartileFBs)

        for FBName in thirdQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            #    If Y/2 <= y_max < 3Y/4)
            if self.quartiles.R.Q2y <= activeFBObject.maxYCoord() <= self.quartiles.R.Q3y:
                # Identify blocks in 4th quartile with highest x_max
                lowest_xMin = self.FBNameWithObject[FBNameForQ4WithLowestMinX].minXCoord()
                #  If active block is smaller, tag it as ME(xmin>lowest_xmin)
                if activeFBObject.minXCoord() > lowest_xMin:
                    self.marginWise_WithBlockTags['R'].append({FBNameForQ4WithLowestMinX: 'ME'})
                # If active block is larger (xmin<=lowest_xmin)
                elif activeFBObject.minXCoord() <= lowest_xMin:
                    # If any blocks present in 3rd or 4th quartiles, tag it as ME
                    if thirdQuartileFBs and fourthQuartileFBs:
                        self.marginWise_WithBlockTags['R'].append({FBName: 'ME'})
                    else:
                        self.marginWise_WithBlockTags['R'].append({FBName: 'MB'})
            # If y_max >= 3Y/4, tag the block as ME
            if activeFBObject.maxYCoord() >= self.quartiles.R.Q3y:
                self.marginWise_WithBlockTags['R'].append({FBName: 'ME'})

        # For FBs in 4th quartile (3Y/4 <= y_min <= Y)
        for FBName in fourthQuartileFBs:
            # Tag as MB
            self.marginWise_WithBlockTags['R'].append({FBName: 'MB'})

    def analyzeRightMarginForLargeBlock(self):
        """
        Analyzes the right margin for large blocks in the context of fixed-block arrangement
        rules. This method determines and assigns tags ('ME' or 'MB') to blocks based
        on their position relative to the right margin quartiles and the block with
        the highest maximum X-coordinate.

        :return: Boolean indicating whether any block was tagged as 'MB'
        :rtype: bool
        """
        tagOthersAsME = False
        tagOthersAsMB = False
        FBNamesListForRightMargin = self.FBNamesBasedOnMarginRules('R')
        FBWithHighestMaxX = self.FB_withMaxX(FBNamesListForRightMargin)
        if FBWithHighestMaxX:
            FBObject = self.FBNameWithObject[FBWithHighestMaxX]
            if self.quartiles.R.Q1y <= FBObject.maxYCoord() <= self.quartiles.R.Q3y:
                self.marginWise_WithBlockTags['R'].append({FBWithHighestMaxX: 'ME'})
                tagOthersAsME = True
            else:
                self.marginWise_WithBlockTags['R'].append({FBWithHighestMaxX: 'MB'})
                tagOthersAsMB = True
        if tagOthersAsME:
            for FBName in FBNamesListForRightMargin:
                if FBName != FBWithHighestMaxX:
                    self.marginWise_WithBlockTags['R'].append({FBName: 'ME'})
        if tagOthersAsMB:
            for FBName in FBNamesListForRightMargin:
                if FBName != FBWithHighestMaxX:
                    self.marginWise_WithBlockTags['R'].append({FBName: 'MB'})
            return True
        return False

    def analyzeBottomMarginForQuartiles(self, FbNamesListForBottomMargin):
        """
        Analyzes the bottom margin of fixed blocks (FBs) across specified quartiles
        and classifies them into different categories based on their positioning
        and relationships with other blocks. The function processes the list
        of FBs, determines their quartiles, and assigns margin classification
        tags, such as 'MB' (medium bottom) or 'ME' (medium edge).

        :param FbNamesListForBottomMargin: List of fixed block names for bottom margin analysis.
        :type FbNamesListForBottomMargin: list of str
        :return: None
        """
        firstQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForBottomMargin,
                                                          quartile=1, marginName='B')
        secondQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForBottomMargin, quartile=2,
                                                           marginName='B')
        thirdQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForBottomMargin, quartile=3,
                                                          marginName='B')
        fourthQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForBottomMargin, quartile=4,
                                                           marginName='B')

        # For FBs in 1st quartile (0 < x_min < Y/4)

        for FBName in firstQuartileFBs:
            FBObject = self.FBNameWithObject[FBName]

            # If x_max <= X/4, tag it as MB
            if FBObject.maxXCoord() <= self.quartiles.B.Q1x:
                self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})
            # If X/4 <= x_max < X/2
            # If any blocks present in 3rd or 4th quartiles, tag as ME
            # Else, tag as MB

            if self.quartiles.B.Q1x <= FBObject.maxXCoord() < self.quartiles.B.Q2x:
                if (FBName in thirdQuartileFBs) or (FBName in fourthQuartileFBs):

                    self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})
                else:
                    self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})
            # If x_max >= X/2, tag as ME
            if FBObject.maxXCoord() >= self.quartiles.B.Q2x:
                self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})

        FBNameForQ1WithHighestMaxY = self.FB_withMaxY(FBNameList=firstQuartileFBs)

        # For FBs in 2nd quartile (X/4 < x_min < X/2)
        for FBName in secondQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            # If X/4 < x_max < X/2
            if self.quartiles.B.Q1x <= activeFBObject.maxXCoord() <= self.quartiles.B.Q2x:
                # Identify blocks in 1st quartile with highest x_max
                if FBNameForQ1WithHighestMaxY:
                    FBObject = self.FBNameWithObject[FBName]
                    highest_yMax = FBObject.maxYCoord()
                    # Identify blocks in 1st quartile with highest x_max
                    # If active block is smaller, tag it as ME
                    if activeFBObject.maxYCoord() < highest_yMax:
                        self.marginWise_WithBlockTags['B'].append({FBNameForQ1WithHighestMaxY: 'ME'})
                    # If active block is larger (yMax>=highest_yMax)
                    elif activeFBObject.maxXCoord() >= highest_yMax:
                        # If any blocks present in 3rd or 4th quartiles, tag it as ME
                        if thirdQuartileFBs and fourthQuartileFBs:
                            self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})
                        else:
                            self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})
            # If x_max >= X/2
            if activeFBObject.maxXCoord() >= self.quartiles.B.Q2x:
                self.marginWise_WithBlockTags['L'].append({FBName: 'ME'})

        FBNameForQ4WithHighestMaxY = self.FB_withMaxY(FBNameList=fourthQuartileFBs)
        for FBName in thirdQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            #    If X/2 <= x_max < 3X/4)
            if self.quartiles.B.Q2x <= activeFBObject.maxXCoord() <= self.quartiles.B.Q3x:
                # Identify blocks in 4th quartile with highest y_max
                highest_yMax = self.FBNameWithObject[FBNameForQ4WithHighestMaxY].maxXCoord()
                #  If active block is smaller, tag it as ME (ymax<highest_ymax)
                if activeFBObject.maxYCoord() < highest_yMax:
                    self.marginWise_WithBlockTags['B'].append({FBNameForQ4WithHighestMaxY: 'ME'})
                # If active block is larger (ymax>=highest_ymax)
                elif activeFBObject.maxYCoord() >= highest_yMax:
                    # If any blocks present in 3rd or 4th quartiles, tag it as ME
                    if thirdQuartileFBs and fourthQuartileFBs:
                        self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})
                    else:
                        self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})
            # If x_max >= 3Y/4, tag the block as ME
            if activeFBObject.maxXCoord() >= self.quartiles.B.Q3x:
                self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})
        # For FBs in 4th quartile (3X/4 <= x_min <= X)
        for FBName in fourthQuartileFBs:
            # Tag as MB
            self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})

    def analyzeBottomMarginForLargeBlock(self):
        """
        Analyzes the bottom margin of a large block for tagging based on predefined
        criteria such as maximum Y-coordinate position and quartile ranges. The
        function determines and tags fixed blocks either as "ME" (Middle Edge) or
        "MB" (Margin Block) depending on their alignment within the bottom margin
        of the layout and their respective relationship to the block with the
        highest maximum Y-coordinate. Subsequent tagging is applied to other fixed
        blocks in the region accordingly.

        :param self: Instance of the class which invokes this method. Provides
            access to necessary methods such as `FBNamesBasedOnMarginRules`,
            `FB_withMaxY`, and attributes including `FBNameWithObject`,
            `quartiles`, and `marginWise_WithBlockTags`.
        :return: Boolean value indicating whether the tagging was concluded with
            other blocks in the respective region tagged as "MB". Returns True if
            "MB" tagging was performed, otherwise False.
        :rtype: bool
        """
        tagOthersAsME = False
        tagOthersAsMB = False
        FBNamesListForBottomMargin = self.FBNamesBasedOnMarginRules('B')
        FBWithHighestMaxY = self.FB_withMaxY(FBNamesListForBottomMargin)
        if FBWithHighestMaxY:
            FBObject = self.FBNameWithObject[FBWithHighestMaxY]
            if self.quartiles.B.Q1y <= FBObject.maxYCoord() <= self.quartiles.B.Q3y:
                self.marginWise_WithBlockTags['B'].append({FBWithHighestMaxY: 'ME'})
                # If X/4 < x_max < 3X/4, flag the block as ME.
                # Tag all others in this region as ME. (EXIT: Go to the next margin)
                tagOthersAsME = True
            else:
                #  If MB, tag all other blocks in the respective region as MB
                self.marginWise_WithBlockTags['B'].append({FBWithHighestMaxY: 'MB'})
                tagOthersAsMB = True
        if tagOthersAsME:
            for FBName in FBNamesListForBottomMargin:
                if FBName != FBWithHighestMaxY:
                    self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})
        if tagOthersAsMB:
            for FBName in FBNamesListForBottomMargin:
                if FBName != FBWithHighestMaxY:
                    self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})
            return True
        return False

    def analyzeTopMarginForQuartiles(self, FbNamesListForTopMargin):
        """
        Analyzes and assigns edge tags to fixed blocks (FBs) based on their positions
        within different quartiles for the top margin.

        This method processes the FBs provided in the top margin list and categorizes
        them by quartiles. Based on their spatial attributes such as `x_min`, `x_max`,
        `y_min`, and `y_max`, each FB is tagged as either "MB" (Middle Block) or "ME"
        (Margin Edge). The tagging process accounts for FBs that have relative spatial
        relationships with others within and across quartiles, ensuring proper identification
        of edge characteristics.

        :param FbNamesListForTopMargin: A list of fixed block (FB) names to be analyzed for the top margin.
        :type FbNamesListForTopMargin: list[str]
        :return: None. The method updates the `marginWise_WithBlockTags` attribute with the edge tags
            for the analyzed FBs.
        :rtype: None
        """
        firstQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForTopMargin,
                                                          quartile=1, marginName='T')
        secondQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForTopMargin, quartile=2,
                                                           marginName='T')
        thirdQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForTopMargin, quartile=3,
                                                          marginName='T')
        fourthQuartileFBs = self.filterFBsByMarginQuartile(FBNamesList=FbNamesListForTopMargin, quartile=4,
                                                           marginName='T')

        # For FBs in 1st quartile (0 < x_min < X/4)
        for FBName in firstQuartileFBs:
            FBObject = self.FBNameWithObject[FBName]

            # If x_min <= X/4, tag it as MB
            if FBObject.maxXCoord() <= self.quartiles.T.Q1x:
                self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})
            # If X/4 <= x_max < X/2
            # If any blocks present in 3rd or 4th quartiles, tag as ME
            # Else, tag as MB

            if self.quartiles.T.Q1x <= FBObject.maxXCoord() < self.quartiles.T.Q2x:
                if (FBName in thirdQuartileFBs) or (FBName in fourthQuartileFBs):
                    self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})
                else:
                    self.marginWise_WithBlockTags['B'].append({FBName: 'MB'})
            # If x_max >= X/2, tag as ME
            if FBObject.maxXCoord() >= self.quartiles.T.Q2x:
                self.marginWise_WithBlockTags['B'].append({FBName: 'ME'})

        FBNameForQ1WithLowestMinY = self.FB_withMinY(FBNameList=firstQuartileFBs)
        # For FBs in 2nd quartile (X/4 < x_min < X/2)
        for FBName in secondQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            # If X/4 < x_max < X/2
            if self.quartiles.T.Q1y <= activeFBObject.maxYCoord() <= self.quartiles.T.Q2y:
                # Identify blocks in 1st quartile with highest x_max
                if FBNameForQ1WithLowestMinY:
                    FBObject = self.FBNameWithObject[FBName]
                    lowest_yMin = FBObject.minYCoord()
                    # Identify blocks in 1st quartile with lowest y_min
                    # If active block is smaller, tag it as ME
                    if activeFBObject.maxYCoord() > lowest_yMin:
                        self.marginWise_WithBlockTags['B'].append({FBNameForQ1WithLowestMinY: 'ME'})
                    # If active block is larger (yMin>=lowest_yMin)
                    elif activeFBObject.maxXCoord() <= lowest_yMin:
                        # If any blocks present in 3rd or 4th quartiles, tag it as ME
                        if thirdQuartileFBs and fourthQuartileFBs:
                            self.marginWise_WithBlockTags['T'].append({FBName: 'ME'})
                        else:
                            self.marginWise_WithBlockTags['T'].append({FBName: 'MB'})
            # If x_max >= X/2
            if activeFBObject.maxXCoord() >= self.quartiles.T.Q2x:
                self.marginWise_WithBlockTags['T'].append({FBName: 'ME'})

        FBNameForQ4WithLowestMinY = self.FB_withMinY(FBNameList=fourthQuartileFBs)

        for FBName in thirdQuartileFBs:
            activeFBObject = self.FBNameWithObject[FBName]
            #    If X/2 <= x_max < 3X/4)
            if self.quartiles.T.Q2x <= activeFBObject.maxXCoord() <= self.quartiles.T.Q3x:
                # Identify blocks in 4th quartile with highest y_max
                lowest_yMin = self.FBNameWithObject[FBNameForQ4WithLowestMinY].maxXCoord()
                #  If active block is smaller, tag it as ME ((ymin>lowest_ymin)
                if activeFBObject.minYCoord() > lowest_yMin:
                    self.marginWise_WithBlockTags['T'].append({FBNameForQ4WithLowestMinY: 'ME'})
                # If active block is larger (ymin<=lowest_y_min)
                elif activeFBObject.minYCoord() <= lowest_yMin:
                    # If any blocks present in 3rd or 4th quartiles, tag it as ME
                    if thirdQuartileFBs and fourthQuartileFBs:
                        self.marginWise_WithBlockTags['T'].append({FBName: 'ME'})
                    else:
                        self.marginWise_WithBlockTags['T'].append({FBName: 'MB'})
            # If x_max >= 3X/4, tag the block as ME
            if activeFBObject.maxXCoord() >= self.quartiles.T.Q3x:
                self.marginWise_WithBlockTags['T'].append({FBName: 'ME'})

        # For FBs in 4th quartile (3X/4 <= x_min <= X)
        for FBName in fourthQuartileFBs:
            # Tag as MB
            self.marginWise_WithBlockTags['T'].append({FBName: 'MB'})

    def analyzeTopMarginForLargeBlock(self):
        """
        Analyzes the top margin for a large block and determines how to tag fixed blocks
        based on their positions in the margin. The function uses fixed block names and
        their associated edges to classify them as 'ME' (Margin Edge) or 'MB' (Margin Block).
        The classification is based on whether the maximum y-coordinate of the block lies
        within specific quartile ranges. Blocks within the range of the lowest minimum
        y-coordinate are tagged accordingly, and all other blocks in the same top margin
        box are tagged either as 'ME' or 'MB' based on the conditions.

        :return: A boolean value indicating whether some blocks were tagged as 'MB':
                 True if blocks were tagged as 'MB', False otherwise.
        :rtype: bool
        """
        tagOthersAsME = False
        tagOthersAsMB = False
        FBNamesListForTopMargin = self.FBNamesBasedOnMarginRules('T')
        FBWithLowestMinY = self.FB_withMinY(FBNamesListForTopMargin)
        if FBWithLowestMinY:
            FBObject = self.FBNameWithObject[FBWithLowestMinY]
            if self.quartiles.T.Q1y <= FBObject.maxYCoord() <= self.quartiles.T.Q3y:
                self.marginWise_WithBlockTags['T'].append({FBWithLowestMinY: 'ME'})
                # If X/4 < x_max < 3X/4, flag the block as ME.
                # Tag all others in this region as ME. (EXIT: Go to the next margin)
                tagOthersAsME = True
            else:
                #  If MB, tag all other blocks in the respective region as MB
                self.marginWise_WithBlockTags['T'].append({FBWithLowestMinY: 'MB'})
                tagOthersAsMB = True
        if tagOthersAsME:
            for FBName in FBNamesListForTopMargin:
                if FBName != FBWithLowestMinY:
                    self.marginWise_WithBlockTags['T'].append({FBName: 'ME'})
        if tagOthersAsMB:
            for FBName in FBNamesListForTopMargin:
                if FBName != FBWithLowestMinY:
                    self.marginWise_WithBlockTags['T'].append({FBName: 'MB'})
            return True
        return False

    def removeMarginWise_WithUniqueBlockTags(self):
        """
        Remove exact duplicate block-tag mappings within each margin edge.

        The structure of `self.marginWise_WithBlockTags` is:
            {
                'L': [ {'Block3': 'MB'}, {'Block3': 'MB'}, ... ],
                'R': [ {'Block1': 'MB'}, {'Block6': 'ME'}, ... ],
                ...
            }

        This function:
        - Keeps only unique (block, tag) pairs per edge.
        - DOES NOT merge MB/ME conflicts.
        - Preserves both tags if the same block appears with different tags.
        - Only removes exact duplicate dict entries.

        Result is written back to `self.marginWise_WithBlockTags`.
        """

        cleaned = {}

        # Iterate over each margin edge (L, R, T, B)
        for edge, block_list in self.marginWise_WithBlockTags.items():

            seen = set()  # Tracks (block, tag) already added
            unique_list = []  # Final deduplicated list for this edge

            for item in block_list:
                # Each item is a single-entry dict: {'BlockX': 'MB'}
                block, tag = next(iter(item.items()))

                key = (block, tag)

                # Add only if this exact block-tag pair hasn't been seen before
                if key not in seen:
                    seen.add(key)
                    unique_list.append(item)

            cleaned[edge] = unique_list

    def firstIterationLogicFlow(self):
        """
        Executes the first iteration logic flow for analyzing margins and dividing them into quartiles
        based on predefined rules. This method processes left, right, top, and bottom margins in order
        and identifies relevant quartiles if certain conditions are met. The results are utilized for
        further internal operations or debugging purposes.

        :return: None
        """
        margin_order = self.marginOrder if self.marginOrder else ['L', 'R', 'T', 'B']

        for margin in margin_order:

            if margin == "L":
                if self.analyzeLeftMarginForLargeBlock():
                    self.analyzeLeftMarginForQuartiles(
                        FbNamesListForLeftMargin=self.FBNamesBasedOnMarginRules("L"))

            elif margin == "R":
                if self.analyzeRightMarginForLargeBlock():
                    self.analyzeRightMarginForQuartiles(
                        FbNamesListForRightMargin=self.FBNamesBasedOnMarginRules("R"))

            elif margin == "T":
                if self.analyzeTopMarginForLargeBlock():
                    self.analyzeTopMarginForQuartiles(
                        FbNamesListForTopMargin=self.FBNamesBasedOnMarginRules("T"))

            elif margin == "B":
                if self.analyzeBottomMarginForLargeBlock():
                    self.analyzeBottomMarginForQuartiles(
                        FbNamesListForBottomMargin=self.FBNamesBasedOnMarginRules("B"))

    def normalizeFixedBlockEdgesTags(self, marginWise_WithBlockTags):
        """
        Normalize margin-wise block-tag structure into grouped sets per tag.

        Input format:
            {
                'L': [{'Block3': 'MB'}, {'Block1': 'ME'}],
                'R': [{'Block5': 'MB'}],
                ...
            }

        Output format:
            {
                'L': {'MB': {'Block3'}, 'ME': {'Block1'}},
                'R': {'MB': {'Block5'}, 'ME': set()},
                ...
            }

        Purpose:
        - Group blocks under each margin by their tag type (MB / ME).
        - Convert list-of-dicts representation into a cleaner tag-based mapping.
        - Makes downstream margin analysis easier and faster.
        """

        result = {}

        # Iterate through each margin edge (L, R, T, B)
        for margin, entries in marginWise_WithBlockTags.items():

            # Initialize tag buckets for the margin
            result[margin] = {
                'MB': set(),
                'ME': set()
            }

            # entries is a list like: [{'Block3': 'MB'}, {'Block4': 'ME'}]
            for entry in entries:
                for block_name, tag in entry.items():
                    # Add block name under its corresponding tag set
                    result[margin][tag].add(block_name)

        return result

    # def mergeOperationOnLeftMargin(self):
    #     normalizedMarginTags=self.normalizeFixedBlockEdgesTags(self.marginWise_WithBlockTags)
    #     FBNamesForFirstHalf=[]
    #     FBNamesForSecondHalf=[]
    #     for FbName, FBObject in self.FBNameWithObject.items():
    #         if FBObject.minXCoord()<=self.quartiles.L.Q1x:
    #             if self.quartiles.L.Q0y<=FBObject.minYCoord()<=self.quartiles.L.Q2y:
    #                 FBNamesForFirstHalf.append(FbName)
    #             if self.quartiles.L.Q3y<=FBObject.minYCoord()<=self.quartiles.L.Q4y:
    #                 FBNamesForSecondHalf.append(FbName)
    #     firstHalfMaxX_MergedBlocks=[]
    #     firstHalfMinX_MergedBlocks=[]
    #
    #     firstHalfMaxX_ExtendMargin=[]
    #     firstHalfMinX_ExtendMargin=[]
    #     firstHalfMaxY_MergedBlocks=[]
    #     firstHalfMinY_MergedBlocks=[]
    #
    #
    #
    #
    #     secondHalfMaxX_MergedBlocks=[]
    #     secondHalfMaxY_MergedBlocks=[]
    #     secondHalfMinY_MergedBlocks=[]
    #     secondHalfMinX_MergedBlocks=[]
    #
    #     secondHalfMaxX_ExtendMargin=[]
    #     secondHalfMinX_ExtendMargin=[]
    #
    #     for FBName in FBNamesForFirstHalf:
    #         FBObject=self.FBNameWithObject[FBName]
    #         # get x_max and y_max of the block
    #         xmax,ymax=FBObject.maxXCoord(),FBObject.maxYCoord()
    #         xmin,ymin=FBObject.minXCoord(),FBObject.minYCoord()
    #         if FBName in normalizedMarginTags['L']['MB']:
    #
    #             firstHalfMaxX_MergedBlocks.append(xmax)
    #             firstHalfMaxY_MergedBlocks.append(ymax)
    #             firstHalfMinX_MergedBlocks.append(xmin)
    #             firstHalfMinY_MergedBlocks.append(ymin)
    #         elif FBName in normalizedMarginTags['L']['ME']:
    #             firstHalfMaxX_ExtendMargin.append(xmax)
    #             firstHalfMinX_ExtendMargin.append(xmin)
    #
    #     for FBName in FBNamesForSecondHalf:
    #         FBObject=self.FBNameWithObject[FBName]
    #         xmax,ymax=FBObject.maxXCoord(),FBObject.maxYCoord()
    #         xmin,ymin=FBObject.minXCoord(),FBObject.minYCoord()
    #         if FBName in normalizedMarginTags['L']['MB']:
    #             secondHalfMaxX_MergedBlocks.append(xmax)
    #             secondHalfMaxY_MergedBlocks.append(ymax)
    #             secondHalfMinY_MergedBlocks.append(ymin)
    #             secondHalfMinX_MergedBlocks.append(xmin)
    #         elif FBName in normalizedMarginTags['L']['ME']:
    #             secondHalfMaxX_ExtendMargin.append(xmax)
    #             secondHalfMinX_ExtendMargin.append(xmin)
    #
    #
    #     firstHalfMinX=min(firstHalfMinX_MergedBlocks)
    #     firstHalfMaxX=max(firstHalfMaxX_MergedBlocks)
    #     firstHalfMaxY=max(firstHalfMaxY_MergedBlocks)
    #     firstHalfMinY=min(firstHalfMinY_MergedBlocks)
    #
    #
    #     secondHalfMinX=min(secondHalfMinX_MergedBlocks)
    #     secondHalfMaxX=max(secondHalfMaxX_MergedBlocks)
    #     secondHalfMaxY=max(secondHalfMaxY_MergedBlocks)
    #     secondHalfMinY=min(secondHalfMinY_MergedBlocks)
    #     mergeBlockfirstHalf=None
    #     if firstHalfMinX and firstHalfMaxX and firstHalfMaxY and firstHalfMinY:
    #         mergeBlockfirstHalf={f"MergedBlock{self.MergedBlockCount+1}": {
    #                 "H": abs(firstHalfMaxX-firstHalfMinX),
    #                 "V": abs(firstHalfMaxY-firstHalfMinY),
    #                 "ANCHOR_TAG": "LB",
    #                 "ANCHOR_POINT": {
    #                     "X": firstHalfMinX,
    #                     "Y": firstHalfMinY
    #                 }
    #             }}
    #
    #     mergeBlocksecondHalf=None
    #     if secondHalfMinX and secondHalfMaxX and secondHalfMaxY and secondHalfMinY:
    #         mergeBlocksecondHalf={f"MergedBlock{self.MergedBlockCount+2}": {
    #                 "H": abs(secondHalfMaxX-secondHalfMinX),
    #                 "V": abs(secondHalfMaxY-secondHalfMinY),
    #                 "ANCHOR_TAG": "LB",
    #                 "ANCHOR_POINT": {
    #                     "X": secondHalfMinX,
    #                     "Y": secondHalfMinY
    #                 }
    #             }}
    #
    #
    #
    #     leftExtendMarginMinX=min(firstHalfMinX_ExtendMargin+secondHalfMinX_ExtendMargin)
    #     leftExtendMarginMaxX=max(firstHalfMaxX_ExtendMargin+secondHalfMaxX_ExtendMargin)
    #     extendedLeftMargin=leftExtendMarginMaxX-leftExtendMarginMinX or 0
    #
    #     return mergeBlockfirstHalf,mergeBlocksecondHalf,extendedLeftMargin

    def _init_bounds(self):
        """
        Initialize an empty bounding box structure used for merging blocks.

        Returns a dict that tracks min/max X/Y values and whether
        any valid geometry has been added yet.
        """
        return {
            "minX": float("inf"),  # smallest X encountered
            "maxX": float("-inf"),  # largest X encountered
            "minY": float("inf"),  # smallest Y encountered
            "maxY": float("-inf"),  # largest Y encountered
            "has_data": False  # becomes True once at least one block contributes
        }

    def _update_bounds(self, bounds, xmin, xmax, ymin=None, ymax=None):
        """
        Expand the bounding box using new block coordinates.

        Parameters:
            bounds (dict): bounding structure from _init_bounds
            xmin, xmax: horizontal limits of the block
            ymin, ymax: vertical limits (optional for edge-based merges)
        """

        # Update X range
        bounds["minX"] = min(bounds["minX"], xmin)
        bounds["maxX"] = max(bounds["maxX"], xmax)

        # Update Y only if provided
        if ymin is not None:
            bounds["minY"] = min(bounds["minY"], ymin)
        if ymax is not None:
            bounds["maxY"] = max(bounds["maxY"], ymax)

        # Mark bounds as containing valid data
        bounds["has_data"] = True

    def build_merge_block(self, bounds, idx):
        """
        Construct a new FixedBlock from accumulated bounding limits.

        Parameters:
            bounds (dict): merged bounding box
            idx (int): index used for naming the merged block

        Returns:
            FixedBlock or None if no valid bounds exist.
        """

        # If no geometry was merged, skip block creation
        if not bounds["has_data"]:
            return None

        # Width and height from bounding box
        width = bounds["maxX"] - bounds["minX"]
        height = bounds["maxY"] - bounds["minY"]

        # Anchor at bottom-left of merged region
        FBObject = FixedBlock(
            L1=width,
            L2=height,
            anchor_tag="LB",
            anchor_point=Vector(bounds["minX"], bounds["minY"]),
            fixedBlockName=f"MergedBlock{idx}"
        )

        return FBObject

    def mergeOperationOnLeftMargin(self):
        """
        Perform a merge operation on the left margin based on predefined conditions and tags.

        This method processes fixed blocks (FBs) to identify and merge regions of interest
        based on their spatial attributes and associated tags (MB, ME). It divides the region
        into two halves along the vertical axis and performs operations on FBs in each half.
        Merged blocks are created for valid sets of FBs meeting the specified criteria. A new
        extended left margin is calculated by determining the maximum distance between
        corresponding block attributes tagged as ME.

        :param self: The instance of the class invoking the method.

        :return:
            A tuple containing:
                - The first merged block object, if any.
                - The second merged block object, if any.
                - The extended left margin as an integer distance.
        :rtype: Tuple[Optional[object], Optional[object], int]

        :raises:
            None
        """

        normalized = self.normalizeFixedBlockEdgesTags(self.marginWise_WithBlockTagsResolved)
        MB = set(normalized.get("L", {}).get("MB", []))
        ME = set(normalized.get("L", {}).get("ME", []))

        mergeBlockFirst, mergeBlockSecond = None, None
        firstHalfMB = self._init_bounds()
        secondHalfMB = self._init_bounds()

        extendMinX = []
        extendMaxX = []

        fbCountinFirstHalf = 0
        fbCountinSecondHalf = 0
        for fb_name, fb in self.FBNameWithObject.items():
            xmin, xmax = fb.minXCoord(), fb.maxXCoord()
            ymin, ymax = fb.minYCoord(), fb.maxYCoord()
            # Consider FBs whose x_min = [0, X/4] range
            condition1 = xmin > self.quartiles.T.Q1x
            if condition1:
                # Merge blocks with tag MB appropriately
                # Compute x_max and y_max from the blocks
                # Extend sheet margin using blocks whose tag is ME suitably.
                # Compute x_max from the blocks
                ###------- for both first and second half -----------

                # First half
                # Identify FBs whose 0 < y_min <= Y/2
                if self.quartiles.L.Q0y <= ymin <= self.quartiles.L.Q2y:
                    if fb_name in ME:
                        extendMinX.append(xmin)
                        extendMaxX.append(xmax)

                    elif fb_name in MB:
                        self._update_bounds(firstHalfMB, xmin, xmax, ymin, ymax)
                        fbCountinFirstHalf += 1
                # Second half
                # Identify FBs whose Y/2 < y_min <= Y
                elif self.quartiles.L.Q2y <= ymin <= self.quartiles.L.Q4y:

                    # elif fb_name in ME:
                    if fb_name in ME:

                        extendMinX.append(xmin)
                        extendMaxX.append(xmax)
                    elif fb_name in MB:
                        self._update_bounds(secondHalfMB, xmin, xmax, ymin, ymax)
                        fbCountinSecondHalf += 1

        if firstHalfMB["has_data"]:
            self.MergedBlockCount += 1
            mergeBlockFirst = self.build_merge_block(firstHalfMB, self.MergedBlockCount)
        if secondHalfMB["has_data"] and fbCountinFirstHalf > 1 and fbCountinSecondHalf > 1:
            self.MergedBlockCount += 1
            mergeBlockSecond = self.build_merge_block(secondHalfMB, self.MergedBlockCount)

        if extendMinX and extendMaxX:
            # if ME for two halves are not equal, consider max of them.
            extendedLeftMargin = abs(max(extendMaxX) - min(extendMinX))
        else:
            extendedLeftMargin = 0

        return mergeBlockFirst, mergeBlockSecond, extendedLeftMargin

    def mergeOperationOnRightMargin(self):
        """
        Performs a merge operation on the right margin by analyzing fixed block edges
        and their tags. The function processes first and second halves of the margin
        based on the specified conditions, builds merged blocks if data exists in
        either half, and computes the extended right margin.

        :raises KeyError: Raised if a required key is missing during normalization.

        :returns: A tuple containing:
            - mergeBlockFirst (Optional): The first merged block if identified; otherwise None.
            - mergeBlockSecond (Optional): The second merged block if identified; otherwise None.
            - extendedRightMargin (int): The width of the extended right margin if applicable,
              or 0.
        """

        normalized = self.normalizeFixedBlockEdgesTags(self.marginWise_WithBlockTagsResolved)

        MB = set(normalized.get("R", {}).get("MB", []))
        ME = set(normalized.get("R", {}).get("ME", []))

        mergeBlockFirst, mergeBlockSecond = None, None
        firstHalfMB = self._init_bounds()
        secondHalfMB = self._init_bounds()

        extendMinX = []
        extendMaxX = []

        for fb_name, fb in self.FBNameWithObject.items():

            xmin, xmax = fb.minXCoord(), fb.maxXCoord()
            ymin, ymax = fb.minYCoord(), fb.maxYCoord()
            # Consider FBs whose x_min > X/2 and x_max is in [3X/4, X] range
            condition1 = xmin > self.quartiles.B.Q2x
            condition2 = self.quartiles.B.Q3x <= xmax <= self.quartiles.B.Q4x
            # if xmin > self.quartiles.B.Q2x and self.quartiles.B.Q3x <=xmax <= self.quartiles.B.Q4x:

            if condition1 and condition2:
                # First half
                # Identify FBs whose 0 < y_min <= Y/2
                if self.quartiles.R.Q0y <= ymin <= self.quartiles.R.Q2y:

                    if fb_name in ME:
                        extendMinX.append(xmin)
                        extendMaxX.append(xmax)
                    elif fb_name in MB:
                        self._update_bounds(firstHalfMB, xmin, xmax, ymin, ymax)

                # Second half
                elif self.quartiles.R.Q2y < ymin <= self.quartiles.R.Q4y:
                    # elif fb_name in ME:
                    if fb_name in ME:
                        extendMinX.append(xmin)
                        extendMaxX.append(xmax)
                    elif fb_name in MB:
                        self._update_bounds(secondHalfMB, xmin, xmax, ymin, ymax)

        if firstHalfMB["has_data"]:
            self.MergedBlockCount += 1
            mergeBlockFirst = self.build_merge_block(firstHalfMB, self.MergedBlockCount)
        if secondHalfMB["has_data"]:
            self.MergedBlockCount += 1
            mergeBlockSecond = self.build_merge_block(secondHalfMB, self.MergedBlockCount)

        if extendMinX and extendMaxX:

            extendedRightMargin = abs(max(extendMaxX) - min(extendMinX))
        else:
            extendedRightMargin = 0

        return mergeBlockFirst, mergeBlockSecond, extendedRightMargin

    def mergeOperationOnBottomMargin(self):
        """
        Processes and merges operation results on the "bottom margin" of fixed blocks, identifying
        specific conditions within block bounds and quartile constraints.

        This function first normalizes the block edges and extracts margin tags (`MB` and `ME`).
        Two sets of fixed blocks are processed based on quartile ranges, while filtering blocks
        using specific x and y coordinate constraints. Blocks are categorized into two halves
        to determine merging conditions. Extended margins are calculated based on the
        minimum and maximum y-coordinates of qualifying blocks.

        :param self: Instance of the class housing the method, enabling access to
            attributes such as quartiles and fixed block data.
        :return: A tuple containing two merged block objects resulting from the operation
            (`mergeBlockFirst` and `mergeBlockSecond`) and the extended bottom margin.
        :rtype: tuple
        """
        normalized = self.normalizeFixedBlockEdgesTags(self.marginWise_WithBlockTagsResolved)
        MB = set(normalized.get("B", {}).get("MB", []))
        ME = set(normalized.get("B", {}).get("ME", []))

        mergeBlockFirst, mergeBlockSecond = None, None
        firstHalfMB = self._init_bounds()
        secondHalfMB = self._init_bounds()

        extendMinY = []
        extendMaxY = []

        for fb_name, fb in self.FBNameWithObject.items():
            xmin, xmax = fb.minXCoord(), fb.maxXCoord()
            ymin, ymax = fb.minYCoord(), fb.maxYCoord()
            # Consider FBs whose y_min = [0, Y/4] range
            condition1 = ymin >= self.quartiles.L.Q0y
            condition2 = ymin <= self.quartiles.L.Q1y
            if condition1 and condition2:
                # First half
                # Identify FBs whose 0 < x_min <= X/2
                if self.quartiles.B.Q0x <= xmin <= self.quartiles.B.Q2x:

                    # elif fb_name in ME:
                    if fb_name in ME:
                        extendMinY.append(ymin)
                        extendMaxY.append(ymax)
                    elif fb_name in MB:
                        self._update_bounds(firstHalfMB, xmin, xmax, ymin, ymax)

                # Second half
                # Identify FBs whose X/2 < x_min <= X
                elif self.quartiles.B.Q2x < xmin <= self.quartiles.B.Q4x:

                    # elif fb_name in ME:
                    if fb_name in ME:
                        extendMinY.append(ymin)
                        extendMaxY.append(ymax)
                    elif fb_name in MB:
                        self._update_bounds(secondHalfMB, xmin, xmax, ymin, ymax)

        if firstHalfMB["has_data"]:
            self.MergedBlockCount += 1
            mergeBlockFirst = self.build_merge_block(firstHalfMB, self.MergedBlockCount)
        if secondHalfMB["has_data"]:
            self.MergedBlockCount += 1
            mergeBlockSecond = self.build_merge_block(secondHalfMB, self.MergedBlockCount)

        if extendMinY and extendMaxY:
            extendedBottomMargin = abs(max(extendMaxY) - min(extendMinY))
        else:
            extendedBottomMargin = 0

        return mergeBlockFirst, mergeBlockSecond, extendedBottomMargin

    def mergeOperationOnTopMargin(self):
        """
        Performs a merge operation on top margins of fixed blocks, analyzing spatial
        relationships in terms of their coordinates to consolidate data and produce
        new merged blocks when conditions are met.

        :return: A tuple containing:
            - The first merged block (if created)
            - The second merged block (if created)
            - The extended bottom margin height calculated based on block expansion
        :rtype: tuple
        :raises ValueError: If any inconsistency in block attributes or bounds occurs
        """
        normalized = self.normalizeFixedBlockEdgesTags(self.marginWise_WithBlockTagsResolved)
        MB = set(normalized.get("T", {}).get("MB", []))
        ME = set(normalized.get("T", {}).get("ME", []))

        mergeBlockFirst, mergeBlockSecond = None, None
        firstHalfMB = self._init_bounds()
        secondHalfMB = self._init_bounds()

        extendMinY = []
        extendMaxY = []

        for fb_name, fb in self.FBNameWithObject.items():
            xmin, xmax = fb.minXCoord(), fb.maxXCoord()
            ymin, ymax = fb.minYCoord(), fb.maxYCoord()
            # Consider FBs whose y_min = [0, Y/4] range
            condition1 = ymin > self.quartiles.R.Q2y
            condition2 = self.quartiles.R.Q3y <= ymax <= self.quartiles.R.Q4y
            if condition1 and condition2:
                # First half
                # Identify FBs whose 0 < x_min <= X/2
                if self.quartiles.T.Q0x <= xmin <= self.quartiles.T.Q2x:
                    # elif fb_name in ME:
                    if fb_name in ME:
                        extendMinY.append(ymin)
                        extendMaxY.append(ymax)
                    elif fb_name in MB:
                        self._update_bounds(firstHalfMB, xmin, xmax, ymin, ymax)

                # Second half
                # Identify FBs whose X/2 < x_min <= X
                elif self.quartiles.T.Q2x < xmin <= self.quartiles.T.Q4x:
                    # elif fb_name in ME :
                    if fb_name in ME:
                        extendMinY.append(ymin)
                        extendMaxY.append(ymax)
                    elif fb_name in MB:
                        self._update_bounds(secondHalfMB, xmin, xmax, ymin, ymax)

        if firstHalfMB["has_data"]:
            self.MergedBlockCount += 1
            mergeBlockFirst = self.build_merge_block(firstHalfMB, self.MergedBlockCount)
        if secondHalfMB["has_data"]:
            self.MergedBlockCount += 1
            mergeBlockSecond = self.build_merge_block(secondHalfMB, self.MergedBlockCount)

        if extendMinY and extendMaxY:
            extendedBottomMargin = abs(max(extendMaxY) - min(extendMinY))
        else:
            extendedBottomMargin = 0

        return mergeBlockFirst, mergeBlockSecond, extendedBottomMargin

    def buildBlockWise_MarginTags(self, marginWise_WithBlockTags):
        """
        Convert margin-wise block-tag structure into block-wise edge-tag mapping.

        Input format:
            {
                'L': [{'Block3': 'MB'}, {'Block1': 'ME'}],
                'R': [{'Block5': 'MB'}],
                ...
            }

        Output format:
            {
                'Block3': [('L', 'MB')],
                'Block1': [('L', 'ME')],
                'Block5': [('R', 'MB')],
                ...
            }

        Purpose:
        - Reorganize data to make it easier to process per block.
        - Each block collects all margin edges where it appears along with its tag.
        """

        block_map = {}

        # Iterate over each margin edge
        for edge, entries in marginWise_WithBlockTags.items():

            # Each entry is a dict like {'BlockX': 'MB'}
            for item in entries:
                for block, tag in item.items():

                    # Initialize list for new block if first occurrence
                    if block not in block_map:
                        block_map[block] = []

                    # Store (edge, tag) pair under that block
                    block_map[block].append((edge, tag))

        return block_map

    def resolve_margin_conflicts(self, preferred_tag="ME"):
        """
        Resolve MB/ME conflicts for each block per margin edge.

        Workflow:
        1. Convert margin-wise structure → block-wise edge-tag pairs.
        2. For each block, group tags by edge.
        3. If an edge contains both MB and ME → keep `preferred_tag`.
        4. Otherwise keep the existing single tag.
        5. Rebuild the resolved structure back into margin-wise format.

        Parameters:
            preferred_tag (str): Which tag should win when MB & ME conflict occurs.
                                 Allowed values: "MB" or "ME"
        """

        # Convert edge → block structure into block → edge pairs
        FB_Name_WithMarginTags = self.buildBlockWise_MarginTags(self.marginWise_WithBlockTags)

        # Reset resolved structure
        self.marginWise_WithBlockTagsResolved = {}

        # Process each block independently
        for block, pairs in FB_Name_WithMarginTags.items():

            by_edge = {}

            # Group tags per edge for this block
            for edge, tag in pairs:
                by_edge.setdefault(edge, []).append(tag)

            # Resolve tag conflicts edge-wise
            for edge, tags in by_edge.items():

                # Case 1: Only one tag → keep it
                if len(tags) == 1:
                    final_tag = tags[0]

                # Case 2: Multiple tags on same edge
                else:
                    # MB + ME conflict → choose preferred
                    if "MB" in tags and "ME" in tags:
                        final_tag = preferred_tag
                    else:
                        # Same tag repeated → keep one
                        final_tag = tags[0]

                # Store resolved tag back margin-wise
                self.marginWise_WithBlockTagsResolved.setdefault(edge, []).append({block: final_tag})

    def secondIterationLogicFlow(self):
        """
        Perform second-pass merging of fixed blocks along margins in a controlled order.

        Workflow:
        1. Determine merge order (user-defined or default L → R → T → B).
        2. Execute margin-specific merge operations sequentially.
        3. Collect merged FixedBlock objects.
        4. Attach merged blocks to resultant sheet if merging is enabled.
        5. Update sheet margins based on extension offsets from each merge.

        Uses:
            self.marginOrder (optional priority override)
            self.allowMergeBlocks (controls whether merged blocks are added to sheet)
        """

        # Use configured margin order if provided, otherwise default
        merge_order = self.marginOrder if self.marginOrder else ['L', 'R', 'T', 'B']

        # Map margin → (merge_function, offset_attribute_name)
        merge_map = {
            "L": (self.mergeOperationOnLeftMargin, "extendLeftMarginOffset"),
            "R": (self.mergeOperationOnRightMargin, "extendRightMarginOffset"),
            "T": (self.mergeOperationOnTopMargin, "extendTopMarginOffset"),
            "B": (self.mergeOperationOnBottomMargin, "extendBottomMarginOffset"),
        }

        # Execute merge operations in strict priority order
        for margin in merge_order:
            merge_fn, offset_attr = merge_map[margin]

            # Perform merge and capture margin extension
            mergeBlockFirst, mergeBlockSecond, offset = merge_fn()

            # Store extension for final margin update
            setattr(self, offset_attr, offset)

            # Add merged blocks (if any) to collection
            if mergeBlockFirst:
                self.mergedFixedBlocks |= {mergeBlockFirst.FBName: mergeBlockFirst}
            if mergeBlockSecond:
                self.mergedFixedBlocks |= {mergeBlockSecond.FBName: mergeBlockSecond}

        # Attach merged blocks to resultant sheet if allowed
        if self.allowMergeBlocks:
            self.resultantDrawSheet.fixedBlocks |= self.mergedFixedBlocks

        # Update sheet margin extensions after merge pass
        self.resultantDrawSheet.marginsDict['extended_left'] = float(self.extendLeftMarginOffset)
        self.resultantDrawSheet.marginsDict['extended_right'] = float(self.extendRightMarginOffset)
        self.resultantDrawSheet.marginsDict['extended_top'] = float(self.extendTopMarginOffset)
        self.resultantDrawSheet.marginsDict['extended_bottom'] = float(self.extendBottomMarginOffset)

    def getUpdatedDrawSheet(self):
        """
        Retrieves the updated draw sheet.

        This method returns the updated draw sheet that represents
        the final state of the draw sheet after any updates or modifications.

        :return: The updated draw sheet object.

        """
        return self.resultantDrawSheet

    def getWorkingArea(self):
        """
        Calculates the working area of the drawing sheet by adjusting the basis points with
        the given margins and extended margins.

        This method computes the effective area available on a drawing sheet after applying
        both the regular and extended margins. It uses the bottom-left (LB) and top-right (RT)
        basis points as reference points and then adjusts these points based on the margin offsets.
        The working area's width, height, and adjusted basis points are then calculated and returned.

        :return: A tuple containing the width, height, Vector( bottom-left x-coordinate,
             bottom-left y-coordinate) of the working area.

        """
        # Retrieve all standard and extended margin values from the resultant draw sheet.
        # The .get() method is used to safely fetch each value, defaulting to 0 if a specific margin is not defined.
        extended_right = self.resultantDrawSheet.marginsDict.get('extended_right', 0)
        extended_left = self.resultantDrawSheet.marginsDict.get('extended_left', 0)
        extended_top = self.resultantDrawSheet.marginsDict.get('extended_top', 0)
        extended_bottom = self.resultantDrawSheet.marginsDict.get('extended_bottom', 0)
        right_margin = self.resultantDrawSheet.marginsDict.get('right', 0)
        left_margin = self.resultantDrawSheet.marginsDict.get('left', 0)
        bottom_margin = self.resultantDrawSheet.marginsDict.get('bottom', 0)
        top_margin = self.resultantDrawSheet.marginsDict.get('top', 0)

        # Determine the effective offsets for the working area's boundaries.
        # For the left and bottom edges, the offset is the larger of the standard and extended margins.
        leftOffset = left_margin+ extended_left
        bottomOffset =bottom_margin+ extended_bottom
        # For the right and top edges, the offset is the smaller of the two margins.
        # This implies a different rule for how 'extended' margins affect the top/right vs. bottom/left boundaries.
        rightOffset = right_margin+ extended_right
        topOffset = top_margin+ extended_top

        # Get the absolute coordinates of the draw sheet's corners.
        # 'LB' is the Left-Bottom corner, and 'RT' is the Right-Top corner.
        LBx, LBy = self.resultantDrawSheet.basis_point('LB')[:]
        RTx, RTy = self.resultantDrawSheet.basis_point('RT')[:]

        # Calculate the new coordinates for the working area by applying the offsets.
        # The left and bottom boundaries are pushed inwards by adding the offsets.
        updatedLBx, updatedLBy = float(LBx + leftOffset), float(LBy + bottomOffset)
        # The right and top boundaries are pulled inwards by subtracting the offsets.
        updatedRTx, updatedRTy = float(RTx - rightOffset), float(RTy - topOffset)

        # Calculate the final width and height of the working area based on the new corner coordinates.
        # Using abs() ensures the dimensions are always positive.
        width = float(abs(updatedRTx - updatedLBx))
        height = float(abs(updatedRTy - updatedLBy))
        # Return the calculated dimensions and the new origin point (Left-Bottom) of the working area.
        return width, height, Vector(updatedLBx, updatedLBy)

    def generatePickleData(self, marginWise_WithBlockTags, iterationName="primary"):
        """
        Generates pickle data by processing margin-wise block tags, updates fixed block names with
        corresponding margin tags, and saves the updated `DrawSheet` object as a pickle file.

        This function modifies fixed block names by appending margin tags to their identifiers.
        The process includes creating a deep copy of the draw sheet, updating the fixed blocks with the
        newly constructed block names, and serializing the updated draw sheet into a pickle file located
        at a specified directory.

        :param marginWise_WithBlockTags: A dictionary containing block names as keys and their
            corresponding margin tags as a list of values. Used to generate updated block names
            by appending the margin tags.
        :type marginWise_WithBlockTags: dict
        :param iterationName: The identifier for the current iteration, used to determine the
            file name for the pickle file. Accepts "primary" or "secondary" as valid
            inputs. Defaults to "primary".
        :type iterationName: str
        :return: None
        """
        # A dictionary to hold placeholder names for pickle files, distinguishing between iterations.
        fileNamesPlaceholder = {"primary": "drawsheet_Qtags.pkl", "secondary": "drawsheet_Qtags_final.pkl"}

        # Build a dictionary mapping Fixed Block (FB) names to their associated margin tags.
        # This helps in identifying how each block is positioned relative to the margins.
        FBName_WithMarginTags = self.buildBlockWise_MarginTags(marginWise_WithBlockTags)
        # Create a new dictionary to store fixed blocks with their names updated to include margin tags.
        updatedFixedBlocksIdObject = {}
        # Iterate over each fixed block in the original draw sheet.
        for FB_Name, FB_Object in self.drawsheet.fixedBlocks.items():
            # Retrieve the margin tags for the current fixed block. Default to an empty list if none are found.
            MarginTags = FBName_WithMarginTags.get(FB_Name, [])
            # Construct a new, more descriptive name for the fixed block by appending its margin tags.
            # This makes the block's name reflect its position, like 'BlockName["Left", "Top"]'.
            newFbName = f'{FB_Name}' + f'{MarginTags}'
            # Update the name of the fixed block object itself.
            FB_Object.FBName = newFbName
            # Add the updated fixed block object to the new dictionary with the new name as the key.
            updatedFixedBlocksIdObject[newFbName] = FB_Object

        # Create a deep copy of the original draw sheet to avoid modifying it directly.
        # This is crucial for preserving the original state if needed.
        copiedDrawSheet = copy.deepcopy(self.drawsheet)
        # Replace the fixed blocks in the copied draw sheet with the updated ones.
        copiedDrawSheet.fixedBlocks = updatedFixedBlocksIdObject

        # Check if a directory path for saving pickle files has been specified.
        if self.pickleDirPath:
            # Construct the full file path for the pickle file using the specified directory
            # and the placeholder name for the current iteration.
            file_path = self.pickleDirPath / fileNamesPlaceholder[iterationName]

            # Open the file in binary write mode ("wb") to save the pickled data.
            with open(file_path, "wb") as f:
                # Serialize the copied draw sheet object and write it to the file.
                # This saves the state of the draw sheet for later use or debugging.
                pickle.dump(copiedDrawSheet, f)

    def runLogic(self):
        """
        Orchestrates the entire quartile merge algorithm by executing the main logic flows in sequence.

        This method acts as the master controller for the merging process. It follows a two-pass
        approach:
        1.  **First Iteration**: Performs an initial analysis to tag fixed blocks based on their
            proximity to the sheet's margins (Top, Bottom, Left, Right). It then saves this
            intermediate state to a "primary" pickle file for debugging or analysis.
        2.  **Conflict Resolution**: After the first pass, it identifies and resolves any
            conflicts where a block might be tagged to multiple margins. It prioritizes
            merging with existing blocks ("ME" tag). The resolved state is saved to a
            "secondary" pickle file.
        3.  **Second Iteration**: Executes the final merging logic based on the resolved tags,
            combining adjacent blocks into larger, merged blocks.
        """
        # Execute the first pass of the algorithm: analyze margins and tag blocks.
        self.firstIterationLogicFlow()

        # Save the state of the drawsheet after the initial analysis.
        # This creates a "primary" snapshot before any conflicts are resolved.
        self.generatePickleData(self.marginWise_WithBlockTags, iterationName="primary")
        # Clean up the tagged blocks, likely removing blocks that are uniquely tagged and don't need merging.
        self.removeMarginWise_WithUniqueBlockTags()

        # Address situations where a block is a candidate for merging into multiple margins.
        # The 'preferred_tag="ME"' suggests a preference for merging with existing blocks.
        self.resolve_margin_conflicts(preferred_tag="ME")
        # Save the state again after resolving conflicts, creating a "secondary" or final snapshot.
        self.generatePickleData(self.marginWise_WithBlockTagsResolved, iterationName="secondary")
        # Execute the second pass of the algorithm: perform the actual block merging operations.
        self.secondIterationLogicFlow()

def runMain1():
    drawsheetJSON = {
        "SHT_ID": 1,
        "SHT_NAME": "Sheet.1",
        "UNITS": "mm",
        "H": 4495.8,
        "V": 889.0,
        "MARGIN": {
            "top": 12.7,
            "right": 25.4,
            "bottom": 12.7,
            "left": 25.4,
            "extended_top": 0.0,
            "extended_right": 0.0,
            "extended_bottom": 0.0,
            "extended_left": 0.0
        },
        "FIXED_BLOCKS": {
            "Block1": {
                "H": 438.15,
                "V": 110.744,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 4019.55,
                    "Y": 25.4
                }
            },
            "Block2": {
                "H": 167.72,
                "V": 73.492,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 2981.758,
                    "Y": 31.768
                }
            },
            "Block3": {
                "H": 168.478,
                "V": 73.492,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 745.95,
                    "Y": 31.768
                }
            },
            "Block4": {
                "H": 167.566,
                "V": 73.492,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 1864.299,
                    "Y": 31.768
                }
            },
            "Block5": {
                "H": 167.719,
                "V": 41.787,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3902.651,
                    "Y": 815.479
                }
            },
            "Block6": {
                "H": 812.8,
                "V": 736.6,
                "ANCHOR_TAG": "LB",
                "ANCHOR_POINT": {
                    "X": 3644.9,
                    "Y": 76.2
                }
            }
        }}

    drawsheetObject = DrawSheet(sheet_id=drawsheetJSON['SHT_ID'], sheet_name=drawsheetJSON['SHT_NAME'],
                                L1=drawsheetJSON['H'],
                                L2=drawsheetJSON['V'],
                                marginsDict=drawsheetJSON['MARGIN'],
                                fixedBlocksDict=drawsheetJSON['FIXED_BLOCKS'], units=drawsheetJSON['UNITS']

                                )

    quartileMergeConfig = {
        "edgesQuartileRatios": {
            'L': {'x': [0.25, 0.25, 0.25, 0.25], 'y': [0.25, 0.25, 0.25, 0.25]},
            'T': {'x': [0.25, 0.25, 0.25, 0.25], 'y': [0.25, 0.25, 0.25, 0.25]},
            'B': {'x': [0.25, 0.25, 0.25, 0.25], 'y': [0.25, 0.25, 0.25, 0.25]},
            'R': {'x': [0.25, 0.25, 0.25, 0.25], 'y': [0.25, 0.25, 0.25, 0.25]},
        },
        "allowMergeBlocks": True, "marginOrder": ['L', 'R', 'T', 'B'],
        "pickleDirPath": None
    }
    qma = QuartileMergeAlgorithm(
        drawsheet=drawsheetObject,
        config=quartileMergeConfig
    )
    print(f'{type(qma.getUpdatedDrawSheet())=}')
    print(f'{qma.getWorkingArea()}')

if __name__ == '__main__':
    # runMain1()
    pass




