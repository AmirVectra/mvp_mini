import copy

from vct_o_geom.vector import Vector
from ..deserialize import convertJSONToDrawViewsDict


## only for developer
# from drawview_root.src.drawview.views_cluster.cluster import ViewCluster
# from drawview_root.src.drawview.views_cluster.cluster_visualizer import displayViewsCluster


VALID_RELATIVE_ORDERS=['R','L','T','B','LB','LT','RB','RT']
CENTER_VIEW_ABBR='CTR'

class OrthographicProjectionSetV1:
    def __init__(self, viewsIdObjectDict: dict, MVP_Config: dict = None):

        self.viewsIdObjectDict=viewsIdObjectDict


        if MVP_Config is None:
            MVP_Config = {'ctrViewMargin': 0}

        self.ctrViewMargin = MVP_Config.get('ctrViewMargin', 0)
        viewsIdRelativeOrderDict={view_id:view.rel_order for view_id,view in self.viewsIdObjectDict.items()}
        self.viewsIdRelativeOrderDict = viewsIdRelativeOrderDict
        self.viewsRelativeOrder_IdDict={rel_order:view_id for view_id,rel_order in self.viewsIdRelativeOrderDict.items()}

        self._arrangeMVP()


    def _getViewsRelativeOrder_ObjectDict(self):


        if 'CTR' not in self.viewsRelativeOrder_IdDict:
           raise KeyError('CTR not found')

        viewsRelativeOrderObjectDict={}
        for view_id,rel_order in self.viewsIdRelativeOrderDict.items():
            viewObject=self.viewsIdObjectDict[view_id]
            viewsRelativeOrderObjectDict[rel_order]=viewObject


        return viewsRelativeOrderObjectDict




    def zoneOffset(self,viewObject,zone):

        viewBRect = viewObject.boundingRectangle()
        zoneOffset = 0

        basis_map = {
            'L': 'CL',
            'R': 'CR',
            'T': 'CT',
            'B': 'CB'
        }

        if zone in basis_map:
            basis = basis_map[zone]

            # Rect and object basis points
            viewBRect_pt = viewBRect.basis_point(basis)
            viewObject_pt = viewObject.basis_point(basis)

            # For horizontal zones
            if zone in ['L', 'R']:
                offsetX = abs(viewBRect_pt[0] - viewObject_pt[0])
                zoneOffset = offsetX

            # For vertical zones
            elif zone in ['T', 'B']:
                offsetY = abs(viewBRect_pt[1] - viewObject_pt[1])
                zoneOffset = offsetY


        return zoneOffset





    def _arrangeMVP_old(self):
        viewsRelativeOrder_ObjectDict = self._getViewsRelativeOrder_ObjectDict()
        ctrProjection = viewsRelativeOrder_ObjectDict['CTR']
        ctrProjectionCTRx,ctrProjectionCTRy = ctrProjection.basis_point("CTR")[:]


        relProjections = {rel_order: view for rel_order, view in viewsRelativeOrder_ObjectDict.items() if
                          rel_order != 'CTR'}
        viewsIdObjectDictInMVP = {ctrProjection.view_id: ctrProjection}



        for relOrder, relProjection in relProjections.items():


            if relOrder == 'R':
                rightViewLeftOffsetX=self.zoneOffset(relProjection,'L')+relProjection.L1
                rightView_CTRx=ctrProjectionCTRx+ctrProjection.L1+self.zoneOffset(ctrProjection,'R')+self.ctrViewMargin+rightViewLeftOffsetX
                rightView_CTRy=ctrProjectionCTRy

                relProjection.anchor_tag="CTR"
                relProjection.anchor_point=Vector(rightView_CTRx,rightView_CTRy)



            if relOrder == 'L':
                rightViewRightOffsetX = self.zoneOffset(relProjection, 'R') + relProjection.L1
                rightView_CTRx = ctrProjectionCTRx -ctrProjection.L1 - self.zoneOffset(
                    ctrProjection, 'L') - self.ctrViewMargin - rightViewRightOffsetX
                rightView_CTRy = ctrProjectionCTRy

                relProjection.anchor_tag = "CTR"
                relProjection.anchor_point = Vector(rightView_CTRx, rightView_CTRy)

            if relOrder == 'T':
                topViewBottomOffsetY = self.zoneOffset(relProjection, 'B') + relProjection.L2
                topView_CTRx = ctrProjectionCTRx
                topView_CTRy = ctrProjectionCTRy + ctrProjection.L2 - self.zoneOffset(
                    ctrProjection, 'T') + self.ctrViewMargin + topViewBottomOffsetY
                relProjection.anchor_tag = "CTR"
                relProjection.anchor_point = Vector(topView_CTRx, topView_CTRy)

            if relOrder == 'B':
                topViewTopOffsetY = self.zoneOffset(relProjection, 'T') + relProjection.L2
                topView_CTRx = ctrProjectionCTRx
                topView_CTRy = ctrProjectionCTRy - ctrProjection.L2 - self.zoneOffset(
                    ctrProjection, 'B') - self.ctrViewMargin - topViewTopOffsetY
                relProjection.anchor_tag = "CTR"
                relProjection.anchor_point = Vector(topView_CTRx, topView_CTRy)


            viewsIdObjectDictInMVP[relProjection.view_id] = relProjection

        # print('arrangeMVP',viewsIdObjectDictInMVP)
        self.viewsIdObjectDict = viewsIdObjectDictInMVP


    def _arrangeMVP(self):
        viewsRelativeOrder_ObjectDict = self._getViewsRelativeOrder_ObjectDict()
        centerView = viewsRelativeOrder_ObjectDict['CTR']
        # CTR Coords of view and BRect might vary so , we use view's CTR Coord
        ctrView_CTRCoords=centerView.basis_point("CTR")
        ctrView_CTRCoordX,ctrView_CTRCoordY = ctrView_CTRCoords[:]
        ctrViewHalfWidth=centerView.L1/2
        ctrViewHalfHeight=centerView.L2/2


        relProjections = {rel_order: view for rel_order, view in viewsRelativeOrder_ObjectDict.items() if
                          rel_order != 'CTR'}
        viewsIdObjectDictInMVP = {centerView.view_id: centerView}


        ctrViewCRx,ctrViewCRy=centerView.basis_point("CR")[:]
        ctrViewCTx,ctrViewCTy=centerView.basis_point("CT")[:]
        ctrViewCBx,ctrViewCBy=centerView.basis_point("CB")[:]
        ctrViewCLx,ctrViewCLy=centerView.basis_point("CL")[:]


        ctrViewBRectCL = centerView.boundingRectangle().basis_point("CL")
        ctrViewBRectCR = centerView.boundingRectangle().basis_point("CR")
        ctrViewBRectCT = centerView.boundingRectangle().basis_point("CT")
        ctrViewBRectCB = centerView.boundingRectangle().basis_point("CB")

        ctrViewBRectCRx,ctrViewBRectCRy=ctrViewBRectCR[:]
        ctrViewBRectCTx,ctrViewBRectCTy=ctrViewBRectCT[:]
        ctrViewBRectCBx,ctrViewBRectCBy=ctrViewBRectCB[:]
        ctrViewBRectCLx,ctrViewBRectCLy=ctrViewBRectCL[:]


        ctrViewRightCenterOffset=abs(ctrViewCRx-ctrViewBRectCRx)
        ctrViewLeftCenterOffset=abs(ctrViewCLx-ctrViewBRectCLx)
        ctrViewTopCenterOffset=abs(ctrViewCTy-ctrViewBRectCTy)
        ctrViewBottomCenterOffset=abs(ctrViewCBy-ctrViewBRectCBy)

        for relOrder, relativeView in relProjections.items():

            relViewCRx, relViewCRy = relativeView.basis_point("CR")[:]
            relViewCTx, relViewCTy = relativeView.basis_point("CT")[:]
            relViewCBx, relViewCBy = relativeView.basis_point("CB")[:]
            relViewCLx, relViewCLy = relativeView.basis_point("CL")[:]

            relViewBRectCL = relativeView.boundingRectangle().basis_point("CL")
            relViewBRectCR = relativeView.boundingRectangle().basis_point("CR")
            relViewBRectCT = relativeView.boundingRectangle().basis_point("CT")
            relViewBRectCB = relativeView.boundingRectangle().basis_point("CB")

            relViewBRectCRx, relViewBRectCRy = relViewBRectCR[:]
            relViewBRectCTx, relViewBRectCTy = relViewBRectCT[:]
            relViewBRectCBx, relViewBRectCBy = relViewBRectCB[:]
            relViewBRectCLx, relViewBRectCLy = relViewBRectCL[:]

            relViewRightCenterOffset = abs(relViewCRx - relViewBRectCRx)
            relViewLeftCenterOffset = abs(relViewCLx - relViewBRectCLx)
            relViewTopCenterOffset = abs(relViewCTy - relViewBRectCTy)
            relViewBottomCenterOffset = abs(relViewCBy - relViewBRectCBy)

            relViewHalfWidth=relativeView.L1/2
            relViewHalfHeight=relativeView.L2/2

            if relOrder == 'R':

                rightViewTargetCTRx= ctrView_CTRCoordX+(ctrViewHalfWidth+ctrViewRightCenterOffset+self.ctrViewMargin+relViewLeftCenterOffset+relViewHalfWidth)
                rightView_TargetCTRy=ctrView_CTRCoordY
                relativeView.anchor_tag = "CTR"
                relativeView.anchor_point = Vector(rightViewTargetCTRx, rightView_TargetCTRy)

            if relOrder == 'L':
                leftViewTargetCTRx =  ctrView_CTRCoordX-(ctrViewHalfWidth+ctrViewLeftCenterOffset+self.ctrViewMargin+relViewRightCenterOffset+relViewHalfWidth)
                leftView_TargetCTRy=ctrView_CTRCoordY
                relativeView.anchor_tag = "CTR"
                relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

            if relOrder == 'T':
                topView_TargetCTRx = ctrView_CTRCoordX
                topView_TargetCTRy = ctrView_CTRCoordY+(ctrViewHalfHeight+ctrViewTopCenterOffset+self.ctrViewMargin+relViewBottomCenterOffset+relViewHalfHeight)
                relativeView.anchor_tag = "CTR"
                relativeView.anchor_point = Vector(topView_TargetCTRx, topView_TargetCTRy)

            if relOrder == 'B':
                bottomView_TargetCTRx = ctrView_CTRCoordX
                bottomView_TargetCTRy = ctrView_CTRCoordY - (
                            ctrViewHalfHeight + ctrViewBottomCenterOffset + self.ctrViewMargin + relViewTopCenterOffset + relViewHalfHeight)
                relativeView.anchor_tag = "CTR"
                relativeView.anchor_point = Vector(bottomView_TargetCTRx, bottomView_TargetCTRy)


            viewsIdObjectDictInMVP[relativeView.view_id] = relativeView

        # print('arrangeMVP',viewsIdObjectDictInMVP)
        self.viewsIdObjectDict = viewsIdObjectDictInMVP

def OPS_ViewIdRelativeOrderPairs(viewIdObjectsDict):
    """

    Args:
        viewIdObjectsDict:

    Returns:
        Returns a list of dictionary(s), where each dictionary represents a MVP with keys as view ids and values as relative order
        Example: [{1: 'CTR', 2: 'B', 3: 'T', 4: 'R', 5: 'L'}, {6: 'CTR', 7: 'T', 8: 'B'}, {11: 'CTR', 12: 'B', 13: 'T', 14: 'R', 15: 'L'}]


    """
    ctrViewIdNameDict = {view_id: view.view_name for view_id, view in viewIdObjectsDict.items()}
    ctrViews = {view_id: view.view_name for view_id, view in viewIdObjectsDict.items() if view.rel_order == 'CTR'}

    if len(ctrViews) == 0:
        raise ValueError('THis MVP stack only works Center Views')
    MVPs_ViewIdRelOrderDict = []
    if len(ctrViews) >= 1:
        # consider only those relative views with that single central View
        # get the name of the single central view



        for centralViewId in ctrViews.keys():

            ctrViewName = ctrViewIdNameDict[centralViewId]
            commonSheetId = viewIdObjectsDict[centralViewId].sheet_id

            relativeIds = {view_id for view_id, view in viewIdObjectsDict.items() if
                           view.ctr_view == ctrViewName and view.sheet_id == commonSheetId}
            viewsIdRelativeDict = {centralViewId: "CTR"}
            relativeOrderCheckList = []
            for viewId, viewObject in viewIdObjectsDict.items():
                if viewId in relativeIds:
                    if viewObject.rel_order not in relativeOrderCheckList:
                        if viewObject.sheet_id == commonSheetId:
                            viewsIdRelativeDict[viewId] = viewObject.rel_order
                            relativeOrderCheckList.append(viewObject.rel_order)
                    elif viewObject.rel_order in relativeOrderCheckList:
                        if viewObject.sheet_id == commonSheetId:
                            raise ValueError(f"Multiple Views with same rel_order {viewObject.rel_order=} for the common ctrView={centralViewId}"
                                             f":{ctrViewName}")

            MVPs_ViewIdRelOrderDict.append(viewsIdRelativeDict)

    return MVPs_ViewIdRelOrderDict


######################### helper functions for OPS ###############################################


def filterViewsWith_CenterView_NoRelativeOrder(viewsIdObjectDict):

    viewNames=[viewObject.view_name for viewObject in viewsIdObjectDict.values()]

    viewsIdObjectDictWithParentViewOnly = {view_id:view for view_id, view in viewsIdObjectDict.items() if
                                     ( view.rel_order in [None,""] )and (view.rel_order not in VALID_RELATIVE_ORDERS ) and (view.ctr_view  in viewNames)}
    return viewsIdObjectDictWithParentViewOnly


def filterViewsWith_RelativeOrder_NoCenterView(viewsIdObjectDict):
    viewNames = [viewObject.view_name for viewObject in viewsIdObjectDict.values()]
    viewsIdObjectDictWithRelativeOrderOnly= {view_id:view for view_id, view in viewsIdObjectDict.items()
                                           if  (view.rel_order  in VALID_RELATIVE_ORDERS) and ( (view.ctr_view  in [None,""])or (view.ctr_view not in viewNames) )}
    return viewsIdObjectDictWithRelativeOrderOnly


def filterViewsWith_NoRelativeOrder_NoCenterView(viewsIdObjectDict):
    viewNames = [viewObject.view_name for viewObject in viewsIdObjectDict.values()]
    viewsIdObjectDictWithRelativeOrderOnly= {view_id:view for view_id, view in viewsIdObjectDict.items()
                                           if  (view.rel_order not in VALID_RELATIVE_ORDERS) and ( (view.ctr_view  in [None,""])or (view.ctr_view not in viewNames) )}
    return viewsIdObjectDictWithRelativeOrderOnly


def filterStandAloneViews(viewsIdObjectDict):
    return filterViewsWith_NoRelativeOrder_NoCenterView(viewsIdObjectDict)

def filterPartialStandAloneViews(viewsIdObjectDict):
    partialViewsIdObjectDict={}

    result1= filterViewsWith_RelativeOrder_NoCenterView(viewsIdObjectDict)

    result2= filterViewsWith_CenterView_NoRelativeOrder(viewsIdObjectDict)

    result3= filterViewsWith_NoRelativeOrder_NoCenterView(viewsIdObjectDict)


    partialViewsIdObjectDict|=result1
    partialViewsIdObjectDict|=result2
    partialViewsIdObjectDict|=result3

    return partialViewsIdObjectDict

def filterRelatedViews(viewsIdObjectDict):
    originalViewsIdObjectDict=viewsIdObjectDict.copy()
    partialViewsIdObjectDict=filterPartialStandAloneViews(viewsIdObjectDict)
    relatedViewsIdObjectDict = {k: originalViewsIdObjectDict[k] for k,v in originalViewsIdObjectDict.items() if k not in partialViewsIdObjectDict.keys()}
    return relatedViewsIdObjectDict


########################## extraction of views with relative ordered views and center view ##########################
def filterRelativeViewsBasedOnCenterViewName(viewsIdObjectDict,CTRViewName):
    viewNames = [viewObject.view_name for viewObject in viewsIdObjectDict.values()]
    relativeViewsIdObjectDict={}
    if CTRViewName in viewNames:
        relativeViewsIdObjectDict={view_id:viewObject for view_id,viewObject in viewsIdObjectDict.items()
                                   if (viewObject.ctr_view == CTRViewName) and (viewObject.rel_order in VALID_RELATIVE_ORDERS)}
    return relativeViewsIdObjectDict

def filterCenterViews(viewsIdObjectDict):
    centerViewsIdObjectDict={}
    if viewsIdObjectDict:
        centerViewsIdObjectDict={view_id:viewObject for view_id,viewObject in viewsIdObjectDict.items()
                                   if (viewObject.ctr_view == viewObject.view_name) and (viewObject.rel_order == CENTER_VIEW_ABBR)}
    return centerViewsIdObjectDict



class OrthographicProjectionSet:
    def __init__(self, viewsIdObjectDict: dict, MVP_Config: dict = None):

        self.viewsIdObjectDict=viewsIdObjectDict
        self.OPS_Pairs = []



        if MVP_Config is None:
            MVP_Config = {'ctrViewMargin': 0}
        else:
            MVP_Config = dict(MVP_Config)  # protect from external mutation

        self.ctrViewMargin = MVP_Config.get('ctrViewMargin', 0)
        self._arrangeMVP()

    def zoneOffset(self,viewObject,zone):

        viewBRect = viewObject.boundingRectangle()
        zoneOffset = 0

        basis_map = {
            'L': 'CL',
            'R': 'CR',
            'T': 'CT',
            'B': 'CB'
        }

        if zone in basis_map:
            basis = basis_map[zone]

            # Rect and object basis points
            viewBRect_pt = viewBRect.basis_point(basis)
            viewObject_pt = viewObject.basis_point(basis)

            # For horizontal zones
            if zone in ['L', 'R']:
                offsetX = abs(viewBRect_pt[0] - viewObject_pt[0])
                zoneOffset = offsetX

            # For vertical zones
            elif zone in ['T', 'B']:
                offsetY = abs(viewBRect_pt[1] - viewObject_pt[1])
                zoneOffset = offsetY


        return zoneOffset


    def getTopVExtentFromCenter(self,viewObject):
        # viewBRect = viewObject.boundingRectangle()
        # _,viewObjectBRectCTy = viewBRect.basis_point("CT")[:]
        # _,viewObjectCTy = viewObject.basis_point("CT")[:]

        # offsetY = abs(viewObjectBRectCTy - viewObjectCTy)+viewObject.L2/2
        offsetY = self.zoneOffset(viewObject=viewObject,zone='T')+viewObject.L2/2

        return offsetY

    def getBottomVExtentFromCenter(self,viewObject):
        # viewBRect = viewObject.boundingRectangle()
        # _,viewObjectBRectCBy = viewBRect.basis_point("CB")[:]
        # _,viewObjectCBy = viewObject.basis_point("CB")[:]
        # offsetY = abs(viewObjectBRectCBy - viewObjectCBy)+viewObject.L2/2
        offsetY = self.zoneOffset(viewObject=viewObject, zone='B') + viewObject.L2 / 2
        return offsetY

    def getRightHExtentFromCenter(self,viewObject):
        # viewBRect = viewObject.boundingRectangle()
        # viewObjectBRectCRx,_ = viewBRect.basis_point("CR")[:]
        # viewObjectCRx,_ = viewObject.basis_point("CR")[:]
        # offsetX = abs(viewObjectBRectCRx - viewObjectCRx)+viewObject.L1/2
        offsetX = self.zoneOffset(viewObject=viewObject, zone='R') + viewObject.L1 / 2

        return offsetX


    def getLeftHExtentFromCenter(self,viewObject):
        # viewBRect = viewObject.boundingRectangle()
        # viewObjectBRectCLx,_ = viewBRect.basis_point("CL")[:]
        # viewObjectCLx,_ = viewObject.basis_point("CL")[:]
        # offsetX = abs(viewObjectBRectCLx - viewObjectCLx)+viewObject.L1/2
        offsetX = self.zoneOffset(viewObject=viewObject, zone='L') + viewObject.L1 / 2
        return offsetX








    def  attachLeftView(self,parentView,leftChildView):
        relativeView=leftChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY =  ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction

        xDistanceFromCenterView=self.getLeftHExtentFromCenter(ctrView) + self.ctrViewMargin +self.getRightHExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx=ctrView_CTRCoordX-xDistanceFromCenterView
        # adjust relative view's center point in Y-direction which will be same as parent view's center point'
        leftView_TargetCTRy = ctrView_CTRCoordY

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def  attachRightView(self,parentView,rightChildView):
        relativeView=rightChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction
        xDistanceFromCenterView = self.getRightHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getLeftHExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX + xDistanceFromCenterView
        # adjust relative view's center point in Y-direction which will be same as parent view's center point'
        leftView_TargetCTRy = ctrView_CTRCoordY

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def  attachTopView(self,parentView,topChildView):
        relativeView=topChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust relative view's center point in X-direction which will be same as parent view's center point'
        leftViewTargetCTRx = ctrView_CTRCoordX
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY + yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def  attachBottomView(self,parentView,bottomChildView):
        relativeView=bottomChildView
        ctrView=parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust relative view's center point in X-direction which will be same as parent view's center point'
        leftViewTargetCTRx = ctrView_CTRCoordX
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY - yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachRightTopView(self,parentView,rightTopChildView):

        relativeView = rightTopChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction
        xDistanceFromCenterView = self.getRightHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getLeftHExtentFromCenter(relativeView)


        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX + xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY + yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachRightBottomView(self, parentView, rightBottomChildView):

        relativeView = rightBottomChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction
        xDistanceFromCenterView = self.getRightHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getLeftHExtentFromCenter(relativeView)

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX + xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY - yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachLeftBottomView(self, parentView, leftBottomChildView):
        relativeView = leftBottomChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction

        xDistanceFromCenterView = self.getLeftHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getRightHExtentFromCenter(relativeView)

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX - xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY - yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView

    def attachLeftTopView(self, parentView, leftBottomChildView):
        relativeView = leftBottomChildView
        ctrView = parentView

        ctrView_CTRCoordX, ctrView_CTRCoordY = ctrView.basis_point("CTR")[:]

        # find the distance from center of parent view to center of relative view in X-direction

        xDistanceFromCenterView = self.getLeftHExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getRightHExtentFromCenter(relativeView)

        # find the distance from center of parent view to center of relative view in Y-direction
        yDistanceFromCenterView = self.getTopVExtentFromCenter(
            ctrView) + self.ctrViewMargin + self.getBottomVExtentFromCenter(relativeView)

        # adjust the relative view center point in X-direction
        leftViewTargetCTRx = ctrView_CTRCoordX - xDistanceFromCenterView
        # adjust the relative view center point in Y-direction
        leftView_TargetCTRy = ctrView_CTRCoordY + yDistanceFromCenterView

        # set the relative view with the updated anchor tag as center with its updated anchor point.
        relativeView.anchor_tag = "CTR"
        relativeView.anchor_point = Vector(leftViewTargetCTRx, leftView_TargetCTRy)

        return relativeView


    def attachViewBasedOnRelativeOrder(self,centerView,relativeView):
        relativeOrder_AttachChildView={

            #
            'L': self.attachLeftView,
            'R': self.attachRightView,
            'T': self.attachTopView,
            'B': self.attachBottomView,
            'LT': self.attachLeftTopView,
            'LB': self.attachLeftBottomView,
            'RT': self.attachRightTopView,
            'RB': self.attachRightBottomView,

         }
        # print(f"CALL relativeView.rel_order={relativeView.rel_order}")
        return  relativeOrder_AttachChildView[relativeView.rel_order](centerView,relativeView)


    def _arrangeMVP(self):

        unprocessedViews = copy.deepcopy(
            filterRelatedViews(self.viewsIdObjectDict)
        )

        # real OPS roots
        centerViews = {
            vid: vobj
            for vid, vobj in unprocessedViews.items()
            if vobj.view_name == vobj.ctr_view
        }


        processed = set()

        def get_children(parentView):
            return {
                vid: vobj
                for vid, vobj in unprocessedViews.items()
                if vobj.ctr_view == parentView.view_name
                   and vobj.view_name != parentView.view_name
            }

        for centerViewId, centerViewObject in centerViews.items():

            viewsIdObjectDict_ForOPS = {}
            queue = [(centerViewId, centerViewObject)]

            while queue:

                currId, currObj = queue.pop(0)

                if currId in processed:
                    continue

                processed.add(currId)
                viewsIdObjectDict_ForOPS[currId] = currObj

                for childId, childObj in get_children(currObj).items():
                    updatedChild = self.attachViewBasedOnRelativeOrder(
                        centerView=currObj,
                        relativeView=childObj
                    )

                    viewsIdObjectDict_ForOPS[childId] = copy.deepcopy(updatedChild)
                    queue.append((childId, updatedChild))

            self.OPS_Pairs.append(viewsIdObjectDict_ForOPS)
        self.viewsIdObjectDict=self.OPS_Pairs[0]


def run_main1():
    viewsDict=convertJSONToDrawViewsDict(r"C:\Users\vectra\Desktop\Vectra\my_repos\shared_lib\drawview_root\sample_data\drawviews_output_ops.json")
    # create dictionary of views objects with view_id as key and view object as value
    drawViewsIdObjectsDict = viewsDict
    for view_id,viewObject in drawViewsIdObjectsDict.items():
        print(f'{view_id=} : view name={viewObject.view_name}  ctr_view={viewObject.ctr_view=}  rel_order = {viewObject.rel_order}')

    results=OrthographicProjectionSet(drawViewsIdObjectsDict,MVP_Config={'ctrViewMargin': 20})

    print(f"viewsIdObjectDict={results.viewsIdObjectDict}")


    # cluster=ViewCluster(viewsIdObjectDict=results.viewsIdObjectDict)
    # displayViewsCluster(cluster.viewsIdObjectDict)


def run_main2():
    jsonData={
            "UNITS": "mm",
            "VIEWS": [
                {
                    "VIEW_ID": 1,
                    "VIEW_NAME": "C1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "CTR",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 2,
                    "VIEW_NAME": "R1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "R",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 3,
                    "VIEW_NAME": "R2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "R1",
                    "REL_ORDER": "R",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 4,
                    "VIEW_NAME": "L1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "L",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 5,
                    "VIEW_NAME": "L2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "L1",
                    "REL_ORDER": "L",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },

                   {
                    "VIEW_ID": 7,
                    "VIEW_NAME": "T1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "T",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 8,
                    "VIEW_NAME": "T2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "T1",
                    "REL_ORDER": "T",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                   {
                    "VIEW_ID": 9,
                    "VIEW_NAME": "B1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "B",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                {
                    "VIEW_ID": 10,
                    "VIEW_NAME": "B2",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "B1",
                    "REL_ORDER": "B",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                 {
                    "VIEW_ID": 11,
                    "VIEW_NAME": "RT1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "RT",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                 {
                    "VIEW_ID": 12,
                    "VIEW_NAME": "RB1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "RB",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                },
                 {
                    "VIEW_ID": 13,
                    "VIEW_NAME": "LT1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "LT",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                }, {
                    "VIEW_ID": 14,
                    "VIEW_NAME": "LB1",
                    "H": 284.5593750000005,
                    "V": 136.37893220899497,
                    "ANCHOR_TAG": "LB",
                    "ANCHOR_POINT": {
                        "X": 266.2815429687506,
                        "Y": 716.1279743238987
                    },
                    "DRAW_ZONES": {
                        "L": 170.88154296875064,
                        "R": 110.27426986694172,
                        "T": 20.7930934671064733,
                        "B": 64.87733844249453
                    },
                    "CTR_VIEW": "C1",
                    "REL_ORDER": "LB",
                    "SCALE": 0.5,
                    "SHT_ID": 1
                }
            ]
        }
    viewsIdObjectsDict = convertJSONToDrawViewsDict(jsonData)
    results = OrthographicProjectionSet(viewsIdObjectsDict, MVP_Config={'ctrViewMargin': 20})

    print(f"viewsIdObjectDict={results.viewsIdObjectDict}")

    # cluster = ViewCluster(viewsIdObjectDict=results.viewsIdObjectDict)
    # displayViewsCluster(cluster.viewsIdObjectDict)

if __name__ == '__main__':
    # run_main1()
    # run_main2()
    pass