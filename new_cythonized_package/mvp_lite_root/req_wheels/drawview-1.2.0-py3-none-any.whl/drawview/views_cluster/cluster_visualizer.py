import typing
from matplotlib import pyplot as plt, patches
from .cluster import ViewCluster


def displayViewsCluster(viewCluster: typing.Union[list, dict]):
    """Displays a cluster of views as rectangles with view id and name in the center.

    Parameters
    ----------
    viewCluster : list or dict
        A list or dictionary of View objects. If a dictionary, the keys are the
        view ids and the values are the View objects.
    """
    # print('cluster displayed')
    fig, ax = plt.subplots()

    if isinstance(viewCluster, dict):
        viewObjectsList = list(viewCluster.values())
    else:
        viewObjectsList = viewCluster


    for view in viewObjectsList:

        # Extract sample_data properly from the `view` object
        lb = view.basis_point('LB')  # Assuming this returns a tuple (x, y)
        l1 = view.L1
        l2 = view.L2
        view_id = view.view_id
        view_name = view.view_name
        drawZones = view.drawZones

        # Create rectangle for the main view
        rect = patches.Rectangle(
            xy=lb,
            width=l1,
            height=l2,
            linewidth=3,
            facecolor='#ffe033',
            edgecolor='red',
            alpha=0.8,
            linestyle='solid'
        )
        ax.add_patch(rect)

        # Add text to the rectangle
        center_x = lb[0] + l1 / 2
        center_y = lb[1] + l2 / 2
        view_text = f"{view_id}:{view_name}"
        ax.text(center_x, center_y, s=view_text, ha='center', va='center', color='red')

        # Draw zones
        for zone_name, zone in drawZones.items():
            zone_lb = zone.basis_point('LB')  # Assuming this returns a tuple (x, y)
            zone_l1 = zone.L1
            zone_l2 = zone.L2

            # Create rectangle for the zone
            rect = patches.Rectangle(
                xy=zone_lb,
                width=zone_l1,
                height=zone_l2,
                linewidth=2,
                edgecolor='green',
                facecolor='#33fcff',
                alpha=0.7,
                linestyle='dashed'
            )
            ax.add_patch(rect)

    # Adjust plot limits to focus on all views and zones
    all_x = [view.basis_point('LB')[0] for view in viewObjectsList] + \
            [view.basis_point('LB')[0] + view.L1 for view in viewObjectsList]
    all_y = [view.basis_point('LB')[1] for view in viewObjectsList] + \
            [view.basis_point('LB')[1] + view.L2 for view in viewObjectsList]

    for view in viewObjectsList:
        # print('vc',view.view_id)
        for zone in view.drawZones.values():
            all_x.extend([zone.basis_point('LB')[0], zone.basis_point('LB')[0] + zone.L1])
            all_y.extend([zone.basis_point('LB')[1], zone.basis_point('LB')[1] + zone.L2])

    all_x = [view.boundingRectangle().basis_point('LB')[0] for view in viewObjectsList]+[
        view.boundingRectangle().basis_point('RT')[0] for view in viewObjectsList
    ]

    all_y = [view.boundingRectangle().basis_point('LB')[1] for view in viewObjectsList] + [
        view.boundingRectangle().basis_point('RT')[1] for view in viewObjectsList
    ]

    x_min, x_max = min(all_x), max(all_x)
    y_min, y_max = min(all_y), max(all_y)
    # print(f'{x_min=} {x_max=} {y_min=} {y_max=}')

    padding_x = (x_max - x_min) * 0.1  # 10% padding
    padding_y = (y_max - y_min) * 0.1

    plt.xlim(x_min - padding_x, x_max + padding_x)
    plt.ylim(y_min - padding_y, y_max + padding_y)

    # Set aspect ratio to equal
    ax.set_aspect('equal', adjustable='box')

    # Show the plot
    plt.show()

def displayViewClusterObject(viewCluster: ViewCluster):
    """Displays a cluster of views as rectangles with view id and name in the center.

    Parameters
    ----------
    viewCluster : ViewCluster Class Obejct
    """
    all_y=[]
    all_x=[]
    fig, ax = plt.subplots()
    ax.relim()
    ax.autoscale_view()
    viewObjectsList= list(viewCluster.viewsIdObjectDict.values())
    clusterPadRect=viewCluster
    clusterLB=clusterPadRect.basis_point('LB')
    # print(clusterLB)

    rect = patches.Rectangle(
        xy=(clusterLB[0],clusterLB[1]),
        width=clusterPadRect.L1,
        height=clusterPadRect.L2,
        linewidth=2,
        edgecolor='red',
        facecolor='green',
        alpha=0.7,
        linestyle='dashed'
    )
    ax.add_patch(rect)
    all_x.append(clusterLB[0])
    all_y.append(clusterLB[1])

    clusterBRect=viewCluster.clusterInnerBoundingRect()
    LBx,LBy=clusterBRect.basis_point('LB')
    rect = patches.Rectangle(
        xy=(LBx, LBy),
        width=clusterBRect.L1,
        height=clusterBRect.L2,
        linewidth=2,
        edgecolor='blue',
        facecolor='white',
        alpha=0.7,
        linestyle='dashed'
    )
    ax.add_patch(rect)
    all_x.append(LBx)
    all_y.append(LBy)

    for view in viewObjectsList:
        # print(view.view_id, view.view_name)
        # Extract sample_data properly from the `view` object
        lb = view.basis_point('LB')  # Assuming this returns a tuple (x, y)
        l1 = view.L1
        l2 = view.L2
        view_id = view.view_id
        view_name = view.view_name
        drawZones = view.drawZones

        # Create rectangle for the main view
        rect = patches.Rectangle(
            xy=lb,
            width=l1,
            height=l2,
            linewidth=3,
            facecolor='#ffe033',
            edgecolor='red',
            alpha=0.8,
            linestyle='solid'
        )
        ax.add_patch(rect)

        # Add text to the rectangle
        center_x = lb[0] + l1 / 2
        center_y = lb[1] + l2 / 2
        view_text = f"{view_id}:{view_name}"
        ax.text(center_x, center_y, s=view_text, ha='center', va='center', color='red')

        # Draw zones
        for zone_name, zone in drawZones.items():
            zone_lb = zone.basis_point('LB')  # Assuming this returns a tuple (x, y)
            zone_l1 = zone.L1
            zone_l2 = zone.L2

            # Create rectangle for the zone
            rect = patches.Rectangle(
                xy=zone_lb,
                width=zone_l1,
                height=zone_l2,
                linewidth=2,
                edgecolor='green',
                facecolor='#33fcff',
                alpha=0.7,
                linestyle='dashed'
            )
            ax.add_patch(rect)

    # Adjust plot limits to focus on all views and zones
    all_x = [view.basis_point('LB')[0] for view in viewObjectsList] + \
            [view.basis_point('LB')[0] + view.L1 for view in viewObjectsList]
    all_y = [view.basis_point('LB')[1] for view in viewObjectsList] + \
            [view.basis_point('LB')[1] + view.L2 for view in viewObjectsList]

    for view in viewObjectsList:

        for zone in view.drawZones.values():
            all_x.extend([zone.basis_point('LB')[0], zone.basis_point('LB')[0] + zone.L1])
            all_y.extend([zone.basis_point('LB')[1], zone.basis_point('LB')[1] + zone.L2])

    # x_min, x_max = min(all_x), max(all_x)
    # y_min, y_max = min(all_y), max(all_y)
    #
    # padding = 100  # Add some padding for better visualization
    # ax.set_xlim(x_min, x_max)
    # ax.set_ylim(y_min, y_max)
    # Set aspect ratio to equal
    ax.set_aspect('equal', adjustable='box')
    # Auto-fit everything
    ax.relim()
    ax.autoscale_view()
    plt.grid(color='green', linestyle='--', linewidth=0.5)
    # Show the plot


    plt.show()