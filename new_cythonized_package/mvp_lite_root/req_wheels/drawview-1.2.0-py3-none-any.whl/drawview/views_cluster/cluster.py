from vct_o_geom.rect_2D import Rect2D
from vct_o_geom.vector import Vector


class ViewCluster(Rect2D):
    """
    A class that represents a cluster of views.

    Attributes:
        viewsIdObjectDict (dict): A dictionary that maps view IDs to view objects.
    """

    def __init__(self, viewsIdObjectDict: dict, clust_pad=0, clusterID=None, setClusterLBAtOrigin=False):
        """
        The constructor for ViewsCluster class.

        Parameters:
            viewObjects (dict OR list): A dictionary or list of view objects.
            Note: Better pass A dictionary where keys are ids and values are view Objects.
        """
        if len(viewsIdObjectDict) <= 0:
            raise ValueError(f"Cluster ID {clusterID=} cannot be formed with ZERO View")

        self.viewsIdObjectDict = viewsIdObjectDict
        self.H_offset = clust_pad
        self.V_Offset = clust_pad
        # TODO: Added clusterId as attibute for the class.
        self.clusterId = clusterID

        # innerBRect=self.clusterInnerBoundingRect()
        # innerBRectLB=innerBRect.basis_point('LB')
        # outerBRectL1 = innerBRect.L1 + (H_offset * 2)
        # outerBRectL2 = innerBRect.L2 + (V_Offset * 2)
        # outerBRectLB=Vector(innerBRectLB[0]-H_offset,innerBRectLB[1]-V_Offset)

        outerBRect = self.clusterOuterBoundingRect()

        outerBRectLB = outerBRect.basis_point('LB')
        outerBRectLB = Vector(outerBRectLB[0], outerBRectLB[1])
        super().__init__(L1=outerBRect.L1, L2=outerBRect.L2, anchor_tag='LB', anchor_point=outerBRectLB)
        if setClusterLBAtOrigin:
            self.repositionCluster(clusterAnchorTag='LB', clusterAnchorPoint=Vector(0, 0))

    # TODO: would this overwrite for boundingRect
    def clusterOuterBoundingRect(self):
        innerBRect = self.clusterInnerBoundingRect()
        innerBRectLB = innerBRect.basis_point('LB')
        innerBRectLBx, innerBRectLBy = innerBRectLB

        clusterPadBRectL1 = innerBRect.L1 + (self.H_offset * 2)
        clusterPadBRectL2 = innerBRect.L2 + (self.V_Offset * 2)
        clusterPadRectLB = (innerBRectLBx - self.H_offset, innerBRectLBy - self.V_Offset)

        clusterPadRect = Rect2D(L1=clusterPadBRectL1, L2=clusterPadBRectL2, anchor_tag='LB',
                                anchor_point=clusterPadRectLB)
        return clusterPadRect

    def clusterInnerBoundingRect(self):
        """
        Returns the bounding rectangle of the cluster.
        """

        # get the list of view objects from the dictionary
        viewObjectsList = list(self.viewsIdObjectDict.values())

        # initialize the bounding rectangle with the first view's bounding rectangle
        BRect: Rect2D = viewObjectsList[0].boundingRectangle()

        # if there are more than one view objects, add their bounding rectangles to the combined rectangle
        if len(viewObjectsList) > 1:
            for viewObject in viewObjectsList[1:]:
                BRect += viewObject.boundingRectangle()

        # get the lower left corner of the bounding rectangle
        LBpoint = BRect.basis_point('LB')

        # set the anchor tag and point of the bounding rectangle
        BRect.anchor_tag = 'LB'
        BRect.anchor_point = LBpoint

        # return the bounding rectangle
        return BRect

    def shift(self, dH=0, dV=0):
        """
        Shifts the cluster by the specified horizontal and vertical distances.

        Parameters:
            dH (float): The horizontal distance to shift the cluster.
            dV (float): The vertical distance to shift the cluster.
        """
        for view_id, viewObject in self.viewsIdObjectDict.items():
            viewObject.shift(dH=dH, dV=dV)

    def repositionCluster(self, clusterAnchorPoint=Vector(0, 0), clusterAnchorTag='LB'):
        """
        Repositions the cluster so that the specified anchor point is at the specified coordinates.

        Parameters:
            clusterAnchorPoint (Vector): The point to reposition the cluster relative to.
            clusterAnchorTag (str): The tag of the anchor point.
        """
        if not isinstance(clusterAnchorPoint, Vector):
            # print(f'{(clusterAnchorPoint.__class__)=} {Vector.__class__} is not a Vector')
            # raise TypeError("clusterAnchorPoint must be a Vector object")
            clusterAnchorPoint = Vector(clusterAnchorPoint[0], clusterAnchorPoint[1])
        if not isinstance(clusterAnchorTag, str):
            raise TypeError("clusterAnchorTag must be a string")

        # if clusterAnchorPoint[0] < 0 or clusterAnchorPoint[1] < 0:
        #     raise ValueError("clusterAnchorPoint's coordinates must be positive")

        # oldInnerBRectLB=self.clusterInnerBoundingRect().basis_point('LB')
        oldOuterBRectLB = self.clusterOuterBoundingRect().basis_point('LB')

        newOuterBRect = Rect2D(L1=self.L1, L2=self.L2, anchor_tag=clusterAnchorTag, anchor_point=clusterAnchorPoint)
        # print(newOuterBRect)

        newOuterBRectLB = newOuterBRect.basis_point('LB')

        deltaXShift = -oldOuterBRectLB[0] + newOuterBRectLB[0]
        deltaYShift = - oldOuterBRectLB[1] + newOuterBRectLB[1]
        # print(f'{deltaXShift=} {deltaYShift=}')

        for view_id, viewObj in self.viewsIdObjectDict.items():
            viewObjBRectLBx, viewObjectBRectLBy = viewObj.boundingRectangle().basis_point('LB')
            viewObjectBRect_NewLB = Vector(viewObjBRectLBx + deltaXShift, viewObjectBRectLBy + deltaYShift)
            viewObj.repositionBRectView(BRectAnchorTag='LB', BRectTargetAnchorPoint=viewObjectBRect_NewLB)

        self.anchor_point = newOuterBRectLB
        self.anchor_tag = 'LB'

    def widthToHeightRatio(self):
        return self.L1 / self.L2

    def aspectRatio(self):
        """Orientation-independent aspect ratio."""
        return max(self.L1, self.L2) / min(self.L1, self.L2)
    def area(self):
        """The area of the cluster."""
        return self.L1 * self.L2
