import json
from .classes import DrawView
from  vct_o_geom.vector import Vector


# -------------------- Utility -------------------- #
def loadJSON(jsonFilePath):
    """Loads and parses JSON data from a specified file path.

    Args:
        jsonFilePath (str): The full path to the JSON file.

    Returns:
        dict or list: The JSON data loaded from the file.

    Raises:
        ValueError: If the file is not found at the specified path or
                    if the file contains invalid JSON (e.g., malformed).
    """
    try:
        with open(jsonFilePath, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        # Re-raise FileNotFoundError as a ValueError for consistent API error handling.
        raise ValueError(f"File not found: {jsonFilePath}")
    except json.JSONDecodeError:
        # Re-raise JSONDecodeError as a ValueError to signal bad file content.
        raise ValueError(f"Invalid JSON in file: {jsonFilePath}")


# -------------------- View Deserialization -------------------- #
class _DrawViewsDeserialize:
    """
    Internal helper class to deserialize JSON data into DrawView objects.

    This class "rehydrates" raw JSON data into a collection of DrawView
    Python objects, optionally merging in data from a separate scale
    configuration.
    """

    def __init__(self, jsonPathOrData, scaleConfig=None, setStartSheetId=None,applyInnerViewScale=True):
        """Initializes the deserializer, loading and processing data immediately.

        Args:
            jsonPathOrData (str or dict): A file path (str) to the views JSON file
                or a pre-loaded dictionary with the views data.
            scaleConfig (str or dict, optional): A file path (str) to a
                scale configuration JSON or a pre-loaded dictionary with that
                config. Defaults to None.
            setStartSheetId (str, optional): If provided, this ID will be
                forcibly set as the `sheet_id` for *all* views being
                deserialized. If None, each view's `SHT_ID` from the JSON
                will be used. Defaults to None.
            defaultScale (int or float, optional): The initial scale to apply
                to all views. Defaults to 1.
        """
        # This will hold the final, rehydrated DrawView objects.
        self.viewsIdObjectDict = {}
        self.scaleConfigDict=scaleConfig
        # --- 1. Load and parse the scale configuration (if provided) ---
        # scaleConfigData = None
        #
        # if scaleConfig:
        #     # Load the scale config from path or use the provided dict
        #     scaleConfigJSON = (
        #         loadJSON(scaleConfig) if isinstance(scaleConfig, str) else scaleConfig
        #     )
        #
        #     # Extract common scale properties
        #     scaleTypeName = scaleConfigJSON['type']
        #     scaleIncrementDirection = scaleConfigJSON['incr_dir']
        #     startScale = scaleConfigJSON['start_scale']
        #     scaleType = scaleConfigJSON['scale_type'][scaleTypeName]
        #
        #     # Branch based on the type of scale configuration
        #     if scaleTypeName == 'absolute':
        #         # Absolute scale uses a fixed set of scales
        #         scale_step =None
        #         scaleSet = scaleType['scale_set']
        #         max_scale =max(scaleSet)
        #         hard_min_scale = min(scaleSet)
        #     else:
        #         # Other types (e.g., incremental) use step/min/max
        #         scale_step = scaleType['scale_step']
        #         max_scale = scaleType['max_scale']
        #         hard_min_scale = scaleType['hard_min_scale']
        #         scaleSet = None
        #
        #     # Assemble the final scale config dictionary for DrawView
        #     scaleConfigData = {
        #         'type': scaleTypeName,
        #         'scale_step': scale_step,
        #         'start_scale': startScale,
        #         'max_scale': max_scale,
        #         'hard_min_scale': hard_min_scale,
        #         'incr_dir': scaleIncrementDirection,
        #         'scale_set': scaleSet,
        #     }

        # --- 2. Load and parse the main views data ---
        viewJSONData = (
            loadJSON(jsonPathOrData) if isinstance(jsonPathOrData, str) else jsonPathOrData
        )

        # --- 3. Iterate and create DrawView objects ---
        for view in viewJSONData['VIEWS']:
            # Determine the starting sheet ID.
            # Use the override if present, otherwise use the ID from the JSON.
            startSheetId = setStartSheetId or view['SHT_ID']

            # Create the DrawView instance
            viewInstance = DrawView(
                view_id=view['VIEW_ID'],
                view_name=view['VIEW_NAME'],
                L1=view["H"],
                L2=view["V"],
                anchor_tag=view["ANCHOR_TAG"],
                anchor_point=Vector(  # Convert X, Y dict to a Vector object
                    view["ANCHOR_POINT"]["X"], view["ANCHOR_POINT"]["Y"]
                ),
                drawZonesDict=view['DRAW_ZONES'],
                ctr_view=view['CTR_VIEW'],
                rel_order=view['REL_ORDER'],
                sheet_id=startSheetId,

                scaleConfigDict=self.scaleConfigDict,  # Pass the (optional) scale config
                view_scale=view.get('SCALE'),
                applyViewScale=applyInnerViewScale


            )
            # Store the new instance in our dictionary, keyed by its ID.
            self.viewsIdObjectDict[viewInstance.view_id] = viewInstance

    def getViewsDict(self):
        """Returns the dictionary of created DrawView objects.

        Returns:
            dict: A dictionary where keys are view IDs and values are
                  the corresponding DrawView objects.
        """
        return self.viewsIdObjectDict

    def getViewsList(self):
        """Returns a list of all created DrawView objects.

        Returns:
            list: A list containing all the created DrawView objects.
        """
        return list(self.viewsIdObjectDict.values())


def convertJSONToDrawViewsDict(jsonPathOrData, scaleConfig=None, setStartSheetId=None,applyInnerViewScale=True):
    """Converts JSON data into a dictionary of DrawView objects, keyed by view ID.

    This is a public-facing wrapper for the _DrawViewsDeserialize class.

    Args:
        jsonPathOrData (str or dict): Path to the views JSON file or a
            pre-loaded dictionary.
        scaleConfig (str or dict, optional): Path to the scale config JSON or
            a pre-loaded dictionary. Defaults to None.
        setStartSheetId (str, optional): If provided, overrides the sheet ID
            for all created views. Defaults to None.

    Returns:
        dict: A dictionary mapping view IDs to their respective DrawView objects.
    """

    return _DrawViewsDeserialize(jsonPathOrData, scaleConfig=scaleConfig, setStartSheetId=setStartSheetId,applyInnerViewScale=applyInnerViewScale).getViewsDict()


def convertJSONToDrawViewsList(jsonPathOrData, scaleConfig=None, setStartSheetId=None):
    """Converts JSON data into a list of DrawView objects.

    This is a public-facing wrapper for the _DrawViewsDeserialize class.

    Args:
        jsonPathOrData (str or dict): Path to the views JSON file or a
            pre-loaded dictionary.
        scaleConfig (str or dict, optional): Path to the scale config JSON or
            a pre-loaded dictionary. Defaults to None.
        setStartSheetId (str, optional): If provided, overrides the sheet ID
            for all created views. Defaults to None.

    Returns:
        list: A list of all created DrawView objects.
    """
    return _DrawViewsDeserialize(jsonPathOrData, scaleConfig, setStartSheetId).getViewsList()