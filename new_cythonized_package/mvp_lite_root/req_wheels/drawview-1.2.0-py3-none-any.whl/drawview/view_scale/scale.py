import abc
import math
from decimal import Decimal, ROUND_UP
from fractions import Fraction


class Scale(abc.ABC):
    """Abstract Base Class for defining a scale interface.

    This class ensures that all concrete scale implementations (like
    Additive, Multiplicative, etc.) provide the necessary methods.
    """
    @abc.abstractmethod
    def nextScale(self, incr_dir):
        """Get the next scale value in the sequence."""
        raise NotImplementedError("Operation 'nextScale' is not possible for this scale.")

    @abc.abstractmethod
    def prevScale(self, incr_dir):
        """Get the previous scale value in the sequence."""
        raise NotImplementedError("Operation 'prevScale' is not possible for this scale.")
class AdditiveScale(Scale):
    def __init__(self, scale_val=1, scale_step=0.1, max_scale=1, hard_min_scale=0.1, incr_dir=-1, scale_set=None):
        """Initializes an Additive Scale.

        In this scale, the 'scale_step' is added to or subtracted from
        the 'scale_val' to get the next/previous scale.

        Args:
            scale_val (float or int, optional): The initial scale value.
            scale_step (float or int, optional): The value to add/subtract.
            max_scale (float or int, optional): The maximum allowed scale value.
            hard_min_scale (float or int, optional): The minimum allowed scale value.
            incr_dir (int, optional): The default direction. Not strongly used
                by next/prevScale but sets the reset behavior. Defaults to -1.
            scale_set (list, optional): Ignored by this class. Included for
                API compatibility.
        """
        self.scaleType = 'additive'
        self._scale_val = self._to_decimal(scale_val)
        self._scale_step = self._to_decimal(scale_step)
        self._max_scale = self._to_decimal(max_scale)
        self._hard_min_scale = self._to_decimal(hard_min_scale)
        self._incr_dir = incr_dir
        self._validate_step_size()
        self.resetInitialScale()

        if scale_set is not None:
            self.scale_set = None  # scale_set is not used in additive scaling.

    def _to_decimal(self, value):
        """Converts a value to Decimal safely.

        Converts to string first to avoid floating-point inaccuracies
        (e.g., float(0.1) becoming Decimal('0.1000...001')).

        Args:
            value (int or float or str): The value to convert.

        Returns:
            Decimal: The converted Decimal object.
        """
        try:
            return Decimal(str(value))  # Convert float to string first to avoid floating-point errors
        except (InvalidOperation, TypeError):
            raise ValueError(f"Invalid value {value}. Must be convertible to Decimal.")

    def nextScale(self, incr_dir):
        """Calculate the next scale value based on the increment direction.

        Args:
            incr_dir (int): +1 for increasing, -1 for decreasing.

        Returns:
            float: The next scale value if within limits, else the current scale_val.
        """
        new_scale = self._scale_val + (Decimal(incr_dir) * self._scale_step)
        if self.hard_min_scale <= new_scale <= self.max_scale:
            return float(new_scale.quantize(Decimal('0.1')))  # Convert to float for clean output
        return self.scale_val

    def prevScale(self, incr_dir):
        """Calculate the previous scale value based on the decrement direction.

        Note: The 'incr_dir' logic here is reversed from nextScale.
        A positive 'incr_dir' will subtract the step.

        Args:
            incr_dir (int): -1 for increasing, +1 for decreasing.

        Returns:
            float: The previous scale value if within limits, else the current scale_val.
        """
        new_scale = self._scale_val - (Decimal(incr_dir) * self._scale_step)
        if self.hard_min_scale <= new_scale <= self.max_scale:
            return float(new_scale.quantize(Decimal('0.1')))  # Convert to float for clean output
        return self.scale_val

    @property
    def scale_val(self):
        """float: The current scale value. Read-only, returns a float."""
        return float(self._scale_val)  # Ensure getter returns a clean float

    @scale_val.setter
    def scale_val(self, new_scale):
        """Sets the new scale value if it is within the allowed limits."""
        new_scale = self._to_decimal(new_scale)
        if self.hard_min_scale <= new_scale <= self.max_scale:
            self._scale_val = new_scale.quantize(Decimal('0.1'))  # Keep precision to 1 decimal place
        else:
            raise ValueError("scale_val is out of range.")

    @property
    def max_scale(self):
        """float: The maximum scale value. Read-only."""
        return float(self._max_scale)

    @max_scale.setter
    def max_scale(self, new_max_scale):
        """max_scale cannot be changed after initialization."""
        raise ValueError("max_scale cannot be changed.")

    @property
    def incr_dir(self):
        """int: The default increment direction. Read-only."""
        return self._incr_dir

    @incr_dir.setter
    def incr_dir(self, new_incr_dir):
        """incr_dir cannot be changed after initialization."""
        raise ValueError("incr_dir cannot be changed.")

    @property
    def scale_step(self):
        """float: The additive step value. Read-only."""
        return float(self._scale_step)

    @scale_step.setter
    def scale_step(self, new_scale_step):
        """scale_step cannot be changed after initialization."""
        raise ValueError("scale_step cannot be changed.")

    @property
    def hard_min_scale(self):
        """float: The minimum scale value. Read-only."""
        return float(self._hard_min_scale)

    @hard_min_scale.setter
    def hard_min_scale(self, new_hard_min_scale):
        """hard_min_scale cannot be changed after initialization."""
        raise ValueError("hard_min_scale cannot be changed.")

    def _validate_step_size(self):
        """Ensures that the step size perfectly divides the range (max - min)."""
        total_range = self._max_scale - self._hard_min_scale
        # Using Decimal's modulo operator ensures precision.
        if total_range % self._scale_step != 0:
            raise ValueError(
                f"❌ Invalid scale_step {self._scale_step}! It must perfectly divide the range ({self._hard_min_scale} to {self._max_scale})."
            )
    def resetInitialScale(self):
        """Resets scale_val if it's not a valid step in the scale range.

        Sets it to the minimum or maximum bound based on 'incr_dir'.
        """
        # if not (self._hard_min_scale <= self._scale_val <= self._max_scale):
        if not (self.scale_val in self.getAllScales()):
            self.scale_val = self._hard_min_scale if self._incr_dir == 1 else self._max_scale


    def randomScale(self, custom_scale):
        """
        Sets the scale to a custom value and returns the scale factor.

        The 'custom_scale' must be within the min/max bounds, but does not
        have to be a valid "step".

        Args:
            custom_scale (float or int): The target scale value.

        Returns:
            float or None: The scale factor (custom_scale / old_scale_val)
                applied, or None if the custom_scale was out of bounds.
        """
        custom_scale = self._to_decimal(custom_scale)

        if not (self.hard_min_scale <= custom_scale <= self.max_scale):
            print(f" Custom scale {custom_scale} is out of bounds!")
            return None

        scale_factor = custom_scale / self._scale_val
        self.scale_val = custom_scale  # Apply the new scale
        return float(scale_factor)

    def getAllScales(self):
        """Generates a list of all valid scale values based on the step size.

        Returns:
            list[float]: A list of all valid scale values from
                hard_min_scale to max_scale.
        """
        scales = []
        current = self._hard_min_scale

        # Determine the decimal precision based on the scale_step
        precision = abs(self._scale_step.as_tuple().exponent)  # Extract decimal places dynamically

        while current <= self._max_scale:
            scales.append(float(current.quantize(Decimal(f'1e-{precision}'))))  # Dynamic precision
            current += self._scale_step

        return scales


from decimal import Decimal, InvalidOperation


class MultiplicativeScale(Scale):
    def __init__(self, scale_val:(int,float)=1, scale_step=0.5, max_scale=1, hard_min_scale=0.001, incr_dir=-1, scale_set=None):
        """Initializes a Multiplicative Scale.

        The 'scale_val' is multiplied or divided by the 'scale_step'.

        Args:
            scale_val (float or int, optional): The initial scale value.
            scale_step (float or int, optional): The multiplication factor.
                If < 1, its reciprocal (1/scale_step) is used.
            max_scale (float or int, optional): The maximum allowed scale value.
            hard_min_scale (float or int, optional): The minimum allowed scale value.
            incr_dir (int, optional): Default direction. Not used by next/prevScale
                but sets the reset behavior. Defaults to -1.
            scale_set (list, optional): Ignored by this class. Included for
                API compatibility.
        """
        self.scaleType = "multiplicative"
        self._scale_val = self._to_decimal(abs(scale_val))
        # Ensure scale_step is >= 1 for consistent multiplication/division logic
        self._scale_step = self._to_decimal(scale_step) if abs(scale_step) >= 1 else Decimal('1') / self._to_decimal(
            scale_step)
        self._max_scale = self._to_decimal(max_scale)
        self._hard_min_scale = self._to_decimal(hard_min_scale)
        self._incr_dir = incr_dir
        self._validate_step_size()
        self.resetInitialScale()
        if scale_set is not None:
            self.scale_set = None  # Not used in multiplicative scaling.

    def _to_decimal(self, value):
        """Converts a value to Decimal safely.

        Converts to string first to avoid floating-point inaccuracies.

        Args:
            value (int or float or str): The value to convert.

        Returns:
            Decimal: The converted Decimal object.
        """
        try:
            return Decimal(str(value))
        except (InvalidOperation, TypeError):
            raise ValueError(f"Invalid value {value}. Must be convertible to Decimal.")

    def nextScale(self, incr_dir):
        """Get the next scale value based on the increment direction.

        Args:
            incr_dir (int): +1 for increase (multiply), -1 for decrease (divide).

        Returns:
            float: The next scale value if within limits, else current scale value.
        """
        new_scale = self._scale_val * self._scale_step if incr_dir == 1 else self._scale_val / self._scale_step

        if self.hard_min_scale <= new_scale <= self.max_scale:
            return float(new_scale.quantize(Decimal('0.0001')))  # Keep precision

        return self.scale_val

    def prevScale(self, incr_dir):
        """Get the previous scale value based on the decrement direction.

        Note: The 'incr_dir' logic here is reversed from nextScale.
        A positive 'incr_dir' will divide, negative will multiply.

        Args:
            incr_dir (int): -1 for increase (multiply), +1 for decrease (divide).

        Returns:
            float: The previous scale value if within limits, else current scale value.
        """
        new_scale = self._scale_val / self._scale_step if incr_dir == 1 else self._scale_val * self._scale_step

        if self.hard_min_scale <= new_scale <= self.max_scale:
            return float(new_scale.quantize(Decimal('0.0001')))

        return self.scale_val

    @property
    def scale_val(self):
        """float: The current scale value. Read-only, returns a float."""
        return float(self._scale_val)

    @scale_val.setter
    def scale_val(self, new_scale):
        """Set the new scale value if it is within the allowed limits."""
        new_scale = self._to_decimal(new_scale)
        if self.hard_min_scale <= new_scale <= self.max_scale:
            self._scale_val = new_scale.quantize(Decimal('0.0001'))
        else:
            raise ValueError("scale_val is out of range.")

    @property
    def max_scale(self):
        """float: The maximum scale value. Read-only."""
        return float(self._max_scale)

    @max_scale.setter
    def max_scale(self, _):
        """max_scale cannot be changed after initialization."""
        raise ValueError("max_scale cannot be changed.")

    @property
    def incr_dir(self):
        """int: The default increment direction. Read-only."""
        return self._incr_dir

    @incr_dir.setter
    def incr_dir(self, _):
        """incr_dir cannot be changed after initialization."""
        raise ValueError("incr_dir cannot be changed.")

    @property
    def scale_step(self):
        """float: The multiplicative step value (always >= 1). Read-only."""
        return float(self._scale_step)

    @scale_step.setter
    def scale_step(self, _):
        """scale_step cannot be changed after initialization."""
        raise ValueError("scale_step cannot be changed.")

    @property
    def hard_min_scale(self):
        """float: The minimum scale value. Read-only."""
        return float(self._hard_min_scale)

    @hard_min_scale.setter
    def hard_min_scale(self, _):
        """hard_min_scale cannot be changed after initialization."""
        raise ValueError("hard_min_scale cannot be changed.")

    def _dynamic_precision(self):
        """Determines the required decimal precision dynamically.

        Finds the smallest magnitude value (min, max, or step) and
        uses its exponent to set the precision level.

        Returns:
            Decimal: A Decimal object representing the quantization
                level (e.g., '1e-3' for 0.001).
        """
        min_value = min(self._hard_min_scale, self._scale_step, self._max_scale)
        precision_level = abs(min_value.log10().to_integral_value(rounding=ROUND_UP))
        return Decimal(f'1e-{int(precision_level)}')

    def getAllScales(self):
        """Generate all valid scale values within the defined range.

        Returns:
            list[float]: A list of valid scale values.
        """
        scales = []
        current = self._hard_min_scale
        precision = self._dynamic_precision()

        # Ensure the step size properly divides the range.
        if (self._max_scale / self._hard_min_scale).log10() % self._scale_step.log10() != 0:
            raise ValueError("Step size must be a perfect multiplier within the range.")

        while current <= self._max_scale:
            scales.append(float(current.quantize(precision)))
            current *= self._scale_step

        return scales

    # def _validate_step_size(self):
    #     """Ensure step size evenly divides the range."""
    #     ratio = self._max_scale / self._hard_min_scale
    #     log_ratio = math.log10(float(ratio))
    #     log_step = math.log10(float(self._scale_step))
    #
    #     if log_ratio % log_step != 0:
    #         raise ValueError(f"Step size {self._scale_step} must be a power of {ratio}")


    def _validate_step_size(self):
        """Ensure step size evenly divides the range using exact rational math.

        This check verifies that 'max_scale' is reachable from 'hard_min_scale'
        by multiplying by 'scale_step' an integer number of times.
        """
        ratio = Fraction(self._max_scale) / Fraction(self._hard_min_scale)
        step = Fraction(self._scale_step)

        # Check if ratio is an exact power of the step
        current = Fraction(1)
        while current < ratio:
            current *= step

        if current != ratio:
            raise ValueError("Step size must be a perfect multiplier within the range.")

    def resetInitialScale(self):
        """Resets scale_val if it's not a valid step in the scale range.

        Sets it to the minimum or maximum bound based on 'incr_dir'.
        """
        # if not (self._hard_min_scale <= self._scale_val <= self._max_scale):
        if not (self._scale_val in self.getAllScales()):
            self.scale_val = self._hard_min_scale if self._incr_dir == 1 else self._max_scale

    def randomScale(self, custom_scale):
        """Adjusts the scale to a custom value and returns the new value.

        The 'custom_scale' must be within the min/max bounds. This method
        calculates a scale factor but ultimately returns the quantized
        'custom_scale' if it's valid.

        Args:
            custom_scale (float or int): The desired scale value.

        Returns:
            float or None: The quantized 'custom_scale' if valid, else None.
        """
        custom_scale = self._to_decimal(custom_scale)

        if not (self._hard_min_scale <= custom_scale <= self._max_scale):
            return None  # Out of valid range

        scale_factor = custom_scale / self._scale_val
        new_scale = self._scale_val * scale_factor  # Apply scale factor

        if self._hard_min_scale <= new_scale <= self._max_scale:
            return float(new_scale.quantize(self._dynamic_precision()))

        return None






class AbsoluteScale(Scale):
    def __init__(self, scale_val, scale_step=None, max_scale=None, hard_min_scale=None, incr_dir=-1, scale_set=None):
        """Initializes an Absolute Scale.

        This scale type uses a fixed list ('scale_set') of allowed values.
        'scale_step', 'max_scale', and 'hard_min_scale' are ignored, as
        they are derived from the 'scale_set' itself.

        Args:
            scale_val (float or int): The initial scale value.
            scale_step (None, optional): Ignored.
            max_scale (None, optional): Ignored.
            hard_min_scale (None, optional): Ignored.
            incr_dir (int, optional): Sets the reset behavior. Defaults to -1.
            scale_set (list or set, optional): A collection of allowed
                scale values. Defaults to {1} if not provided.
        """
        if scale_set is None:
            scale_set = {1}



        self.scaleType = "absolute"
        self._scale_set = sorted([self._to_decimal(val) for val in scale_set])  # Convert scale set to Decimal
        self._incr_dir = incr_dir
        self._scale_val = self._to_decimal(scale_val)  # Convert input scale value
        self._max_scale = max_scale
        self._hard_min_scale = hard_min_scale

        self.resetInitialScale()

        # Unused attributes in Absolute Scaling
        # These are set to be reflective of the scale_set for consistency.
        self._scale_step = None


    def _to_decimal(self, value):
        """Converts a value to Decimal safely.

        Converts to string first to avoid floating-point inaccuracies.

        Args:
            value (int or float or str): The value to convert.

        Returns:
            Decimal: The converted Decimal object.
        """
        try:
            return Decimal(str(value))
        except (InvalidOperation, TypeError):
            raise ValueError(f"Invalid value {value}. Must be convertible to Decimal.")

    @property
    def scale_val(self):
        """float: The current scale value. Read-only, returns a float."""
        return float(self._scale_val)  # Return as float for user-friendly output

    @scale_val.setter
    def scale_val(self, new_scale):
        """Sets the new scale value, but only if it exists in the 'scale_set'."""
        new_scale = self._to_decimal(new_scale)
        if new_scale not in self._scale_set:
            raise ValueError(f"scale_val must be in the fixed scale_set: {self._scale_set}")
        self._scale_val = new_scale

    def nextScale(self, incr_dir: int):
        """Get the next scale value from the fixed 'scale_set'.

        Args:
            incr_dir (int): +1 to move to the next item in the sorted list,
                -1 to move to the previous item.

        Returns:
            float: The next or previous scale value. Returns the current
                value if at the beginning or end of the list.
        """
        try:
            idx = self._scale_set.index(self._scale_val)
        except ValueError:
            raise ValueError(f"Value {self._scale_val} not found in the fixed scale set.")

        if incr_dir == 1:
            if idx < len(self._scale_set) - 1:
                return float(self._scale_set[idx + 1])
            # print("You have reached the maximum scale value.")
        elif incr_dir == -1:
            if idx > 0:
                return float(self._scale_set[idx - 1])
            # print("You have reached the minimum scale value.")
        else:
            raise ValueError("Invalid increment direction. Use 1 for forward or -1 for backward.")
        return self.scale_val

    def prevScale(self, incr_dir: int):
        """Get the previous scale value from the fixed 'scale_set'.

        This method cleverly inverts the 'incr_dir' and passes it
        to 'nextScale'.

        Args:
            incr_dir (int): The direction. This is inverted before use.
                e.g., +1 becomes -1.

        Returns:
            float: The previous or next scale value.
        """
        return self.nextScale(-incr_dir)

    def resetInitialScale(self):
        """Resets scale_val if it's not in the 'scale_set'.

        Sets it to the minimum or maximum value of the set based
        on the 'incr_dir'.
        """
        if self._scale_val is None or self._scale_val not in self._scale_set:
            # print(f"Resetting scale_val to the closest value in {self._scale_set}")
            # Sets to min if incr_dir is 1, max if incr_dir is -1
            self._scale_val = min(self._scale_set) if self._incr_dir == 1 else max(self._scale_set)

    @property
    def scale_step(self):
        """None: 'scale_step' is not applicable to AbsoluteScale."""
        return None

    @scale_step.setter
    def scale_step(self, _):
        """scale_step cannot be set in Absolute Scaling."""
        raise ValueError("scale_step cannot be set in Absolute Scaling.")

    @property
    def scale_set(self):
        """list[float]: A list of the allowed scale values."""
        return [float(val) for val in self._scale_set]  # Return list of floats

    @scale_set.setter
    def scale_set(self, _):
        """scale_set cannot be modified after initialization."""
        raise ValueError("scale_set cannot be modified after initialization.")

    @property
    def incr_dir(self):
        """int: The default increment direction. Read-only."""
        return self._incr_dir

    @incr_dir.setter
    def incr_dir(self, _):
        """incr_dir cannot be changed after initialization."""
        raise ValueError("incr_dir cannot be changed after initialization.")

    @property
    def max_scale(self):
        """float: The maximum value from the 'scale_set'. Read-only."""
        return self._max_scale

    @max_scale.setter
    def max_scale(self, _):
        """max_scale is derived from 'scale_set' and cannot be set."""
        raise ValueError("max_scale is not used in Absolute Scaling.")

    @property
    def hard_min_scale(self):
        """float: The minimum value from the 'scale_set'. Read-only."""
        return float(self._hard_min_scale)

    @hard_min_scale.setter
    def hard_min_scale(self, _):
        """hard_min_scale is derived from 'scale_set' and cannot be set."""
        raise ValueError("hard_min_scale is not used in Absolute Scaling.")


    def getAllScales(self):
        """Get the list of all valid scale values from the 'scale_set'.

        Returns:
            list[float]: The list of allowed scale values.
        """
        return [float(val) for val in self._scale_set]

    def _dynamic_precision(self):
        """Determines the required decimal precision dynamically.

        Note: This method is not used by 'randomScale' in this class.

        Returns:
            Decimal: A Decimal object representing the quantization
                level (e.g., '1e-3' for 0.001).
        """
        min_value = min(self._hard_min_scale, self._scale_step, self._max_scale)
        precision_level = abs(min_value.log10().to_integral_value(rounding=ROUND_UP))
        return Decimal(f'1e-{int(precision_level)}')

    def randomScale(self, custom_scale):
        """Checks if a custom scale is valid and returns it.

        This method does *not* set the internal 'scale_val'. It only
        checks if the 'custom_scale' exists in the 'scale_set'.

        Args:
            custom_scale (float or int): The desired scale value.

        Returns:
            float or None: The 'custom_scale' as a float if it's in the
                'scale_set', otherwise None.
        """
        custom_scale = self._to_decimal(custom_scale)

        if not (custom_scale in self.getAllScales()):
            return None  # Out of valid range

        scale_factor = custom_scale / self._scale_val
        new_scale = self._scale_val * scale_factor  # Apply scale factor

        # This method seems to be missing a quantize step, unlike other classes.
        # It just returns the calculated new_scale.
        return float(new_scale.quantize(self._dynamic_precision()))



if __name__ == '__main__':
    pass
    # This is a test block for the AbsoluteScale class
    # abs=AbsoluteScale(scale_val=1, scale_set=[1,2,3,4,5],hard_min_scale=1,max_scale=10,incr_dir=-1)
    #
    #
    #
    # print(f'{abs.scale_val=} {abs.scale_set=} {abs.hard_min_scale=} {abs.max_scale=}')
    #
    # # --- Test for nextScale (incrementing) ---
    # # incr=1
    # # print(f'{abs.scale_val=}')
    # # abs.scale_val=abs.nextScale(incr_dir=incr)
    # # print(f'{abs.scale_val=}')
    # # abs.scale_val=abs.nextScale(incr_dir=incr)
    # # print(f'{abs.scale_val=}')
    # # abs.scale_val=abs.nextScale(incr_dir=incr)
    # # print(f'{abs.scale_val=}')
    # # abs.scale_val=abs.nextScale(incr_dir=incr)
    # # print(f'{abs.scale_val=}')
    # # abs.scale_val=abs.nextScale(incr_dir=incr)
    # # print(f'{abs.scale_val=}')
    # # abs.scale_val=abs.nextScale(incr_dir=incr)
    #
    # # --- Test for prevScale (decrementing) ---
    # incr=-1
    # print(f'{abs.scale_val=}')
    # abs.scale_val=abs.prevScale(incr_dir=incr)
    # print(f'{abs.scale_val=}')
    # abs.scale_val=abs.prevScale(incr_dir=incr)
    # print(f'{abs.scale_val=}')
    # abs.scale_val=abs.prevScale(incr_dir=incr)
    # print(f'{abs.scale_val=}')
    # abs.scale_val=abs.prevScale(incr_dir=incr)
    # print(f'{abs.scale_val=}')
    # abs.scale_val=abs.prevScale(incr_dir=incr)
    # print(f'{abs.scale_val=}')
    # abs.scale_val=abs.prevScale(incr_dir=incr)