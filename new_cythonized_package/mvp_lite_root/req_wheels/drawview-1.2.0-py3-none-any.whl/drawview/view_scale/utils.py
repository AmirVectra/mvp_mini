from . import AdditiveScale as ADD, MultiplicativeScale as MUL, AbsoluteScale as ABS


def buildScaleManager(scaleConfigDict):
    """Builds a specific Scale object from a configuration dictionary.

    This is a factory function that reads a dictionary, determines the
    desired scale type ('additive', 'multiplicative', or 'absolute'),
    and constructs the corresponding scale object with the correct
    parameters.

    Args:
        scaleConfigDict (dict): A dictionary containing the scale
            configuration. See inline logic for keys like 'type',
            'start_scale', 'scale_step', 'max_scale', 'hard_min_scale',
            and 'scale_set'.

    Returns:
        Scale: An instance of AdditiveScale, MultiplicativeScale, or
               AbsoluteScale, configured as specified.

    Raises:
        ValueError: If the configuration parameters are contradictory
            or incomplete for the specified scale type.
    """
    # A map of scale type strings to their respective classes.
    scaleObjectBuilder = {
        'additive': ADD,
        'multiplicative': MUL,
        'absolute': ABS
    }

    # Guard against None input; provide a minimal default.

    if scaleConfigDict is None:
        return None
        # if minimalConfig is None or minimalConfig == '' or minimalConfig not in ['additive','multiplicative','absolute']:
        #     return None
        # scaleConfigDict = {'type': str(minimalConfig).lower(),
        #                    'scale_type': {str(minimalConfig).lower(): { }
        #                                   }
        #                    }



    # Determine the scale type, defaulting to 'additive'.
    scale_type = scaleConfigDict.get('type')


    # Initialize all possible config variables that will be pulled from the dict.
    incr_dir = scaleConfigDict.get('incr_dir', 1)
    max_scale = None
    hard_min_scale = None
    scale_step = None
    scale_val = None
    scale_set = None
    scaleConfigBasedOnType = scaleConfigDict['scale_type'][scale_type]
    # --- Block for 'additive' and 'multiplicative' scales ---
    if scale_type in ['additive', 'multiplicative']:

        # Set defaults specific to additive scale
        if scale_type == 'additive':

            scale_val = scaleConfigDict.get('start_scale', 1)
            scale_step = scaleConfigBasedOnType.get('scale_step', 0.5)
            hard_min_scale = scaleConfigBasedOnType.get('hard_min_scale', 0)
            max_scale = scaleConfigBasedOnType.get('max_scale', 2)
            scale_set = scaleConfigBasedOnType.get('scale_set', None)  # Not used, but pulled for completeness

        # Set defaults specific to multiplicative scale
        if scale_type == 'multiplicative':

            scale_val = scaleConfigDict.get('start_scale', 1)
            scale_step = scaleConfigBasedOnType.get('scale_step', 0.25)
            hard_min_scale = scaleConfigBasedOnType.get('hard_min_scale', 0.256)
            max_scale = scaleConfigBasedOnType.get('max_scale', 2)
            scale_set = scaleConfigBasedOnType.get('scale_set', None)  # Not used

        # Basic validation for range-based scales.
        # Check: scale type is correct, max > min, and step is positive.
        condition1 = scale_type != 'absolute' and max_scale > hard_min_scale and scale_step > 0.0

        if condition1:
            # Build and return the object.
            # Note: scale_set is explicitly passed as None for these types.
            return scaleObjectBuilder[scale_type.lower()](scale_val=scale_val, scale_step=scale_step,
                                                          max_scale=max_scale,
                                                          hard_min_scale=hard_min_scale,
                                                          incr_dir=incr_dir, scale_set=None)

    # --- Block for 'absolute' scale ---
    if scale_type == 'absolute':

        # Set defaults specific to absolute scale.

        scale_val = scaleConfigDict.get('start_scale',1)
        scale_set = scaleConfigBasedOnType.get('scale_set', [1])
        hard_min_scale = min(scale_set)
        max_scale =  max(scale_set)
        # Basic validation for absolute scale.
        # Check: scale type is correct and scale_set is a list or set.
        condition2 = scale_type == 'absolute' and isinstance(scale_set, (set, list))

        if condition2:
            # Build and return the object.
            return scaleObjectBuilder[scale_type.lower()](scale_val=scale_val, max_scale=max_scale,
                                                          hard_min_scale=hard_min_scale,incr_dir=incr_dir, scale_set=scale_set)

    # If neither block returned, the config was invalid.
    raise ValueError('Improper parameter passed on , please correct it.')

    # for absolute: only scale_val(optional), scale_set and scale_type:

    # TODO: some argument might come like min_scale ,max_scale, this value would be generated prior to SHEET ALLOC algo.

    #
    # # some pre-conditions checks to be done:
    # if scale_type in scaleObjectBuilder.keys() and incr_dir in [-1, 1]:
    #
    #     # check the validation for absolute scale
    #     # TODO: ask about len of set as constraint
    #     condition1 = scale_type == 'absolute' and isinstance(scale_set, (set, list))
    #     if condition1:
    #         if scale_set is None:
    #             scale_set=[1] #default scale set
    #         return scaleObjectBuilder[scale_type.lower()](scale_val=scale_val, incr_dir=incr_dir, scale_set=scale_set)
    #
    #     # check the validation for additive or multiplicative
    #     condition2 =
    #
    #
    #     if condition2:
    #
    # else:
    #     raise ValueError('Improper parameter passed on , please correct it.')