from ..view_scale.scale import AdditiveScale,MultiplicativeScale,AbsoluteScale
from ..view_scale.utils import buildScaleManager