import json
from pathlib import Path


def _createJSONFile(file_path, data=None):
    """
    Internal function to create a JSON file with specified data.

    This helper safely serializes a dictionary and writes it to a .json file,
    ensuring the directory structure exists. It also performs a read-back
    check to verify the contents were written correctly.

    Args:
        file_path (str or Path): The full path to the output JSON file.
        data (dict, optional): The data to be written to the JSON file.
            Defaults to an empty dictionary.

    Returns:
        bool: True if the file was created and verified successfully, False otherwise.
    """
    path = Path(file_path)

    # Ensure the file has a .json extension
    if path.suffix.lower() != ".json":
        print("Invalid file extension. Please use a .json extension.")
        return False

    # Ensure the directory exists
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"Error creating directory: {e}")
        return False

    # Default data if none is provided
    if data is None:
        data = {}

    # Create and write JSON data to file
    try:
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

        # Verify if the data was written correctly by reading it back
        with path.open("r", encoding="utf-8") as f:
            read_data = json.load(f)

        if read_data == data:
            print(f"JSON file created successfully: {path}")
            return True
        else:
            print("JSON file content mismatch after writing.")
            return False

    except Exception as e:
        print(f"Error creating JSON file: {e}")
        return False


class _DrawViewsSerialize:
    """
    Internal class to convert a dictionary of DrawView objects to a
    JSON-compatible data structure.

    This acts as a "translator" from the Python DrawView objects to the
    specific dictionary schema required for the JSON output.
    """

    def __init__(self, viewsIdObjectDict: dict, viewsAnchorTag="LB"):
        """
        Initializes the converter.

        Args:
            viewsIdObjectDict (dict): A dictionary where keys are view IDs
                and values are DrawView objects.
            viewsAnchorTag (str, optional): The anchor tag (e.g., "LB", "RT")
                to use for *all* views being serialized. Defaults to "LB".
        """
        self.viewsIdObjectDict = viewsIdObjectDict
        self.viewsAnchorTag = self.validAnchorTag(viewsAnchorTag)

    def validAnchorTag(self, viewAnchorTag, default="LB"):
        """
        Validates the anchor tag.

        If the tag is not one of the allowed values, it returns the default.

        Args:
            viewAnchorTag (str): The desired anchor tag.
            default (str, optional): The fallback tag. Defaults to "LB".

        Returns:
            str: A valid anchor tag.
        """
        # Ensures the anchor tag is one of the valid, expected strings.
        if viewAnchorTag in ["LB", "RT", "RB", "LT", "CTR"]:
            return viewAnchorTag
        else:
            return default

    def _createJSONStruct(self):
        """
        Creates a JSON-compatible dictionary structure from the DrawView objects.

        This method iterates through all DrawView objects and maps their
        attributes to the target JSON format.

        Returns:
            dict: A dictionary representing the JSON structure of the views
                  configuration.
        """
        # Define the root of the JSON structure.
        viewsConfig = {"UNITS": "mm",
                       "VIEWS": []}

        for viewId, viewObject in self.viewsIdObjectDict.items():
            # --- Scale Handling ---

            currentScale = viewObject.view_scale
            if viewObject.scaleManager:
                currentScale = float(viewObject.scaleManager.scale_val)


            anchorPointX=viewObject.basis_point(self.viewsAnchorTag)[0]
            anchorPointY=viewObject.basis_point(self.viewsAnchorTag)[1]


            # --- View Configuration Mapping ---
            viewConfig = {
                "VIEW_ID": viewObject.view_id,
                "VIEW_NAME": viewObject.view_name,
                "H": viewObject.L1,
                "V": viewObject.L2,
                "ANCHOR_TAG": self.viewsAnchorTag,
                "ANCHOR_POINT": {
                    # Get the X, Y coords for the *specified* anchor tag
                    "X": float(anchorPointX),
                    "Y": float(anchorPointY)
                },
                "DRAW_ZONES": {
                    # Flatten the DrawZones objects into simple key-value pairs
                    "L": viewObject.drawZones['L'].L1,
                    "R": viewObject.drawZones['R'].L1,
                    "T": viewObject.drawZones['T'].L2,
                    "B": viewObject.drawZones['B'].L2
                },
                "CTR_VIEW": viewObject.ctr_view,
                "REL_ORDER": viewObject.rel_order,
                # TODO: need to handle this when working with scale class
                # "SCALE": currentScale,
                "SCALE": currentScale,
                "SHT_ID": viewObject.sheet_id
            }

            viewsConfig['VIEWS'].append(viewConfig)

        return viewsConfig

    def getData(self):
        """
        Retrieves the JSON-compatible data structure.

        Returns:
            dict: The JSON data structure created by _createJSONStruct.
        """
        return self._createJSONStruct()


def convertDrawViewsToJSONData(viewsIdObjectDict: dict, viewsAnchorTag="LB"):
    """
    Converts a dictionary of DrawView objects to a JSON-compatible data structure.

    This is the public-facing wrapper for just getting the data as a dictionary.

    Args:
        viewsIdObjectDict (dict): A dictionary where keys are view IDs
            and values are DrawView objects.
        viewsAnchorTag (str, optional): The anchor tag to use for all the
            views. Defaults to "LB".

    Returns:
        dict: A dictionary representing the JSON structure of the
              views configuration.
    """
    drawViewConverter = _DrawViewsSerialize(viewsIdObjectDict=viewsIdObjectDict, viewsAnchorTag=viewsAnchorTag)
    return drawViewConverter.getData()


def convertDrawViewsToJSONFile(viewsIdObjectDict: dict, outputJSONFilePath=None, viewsAnchorTag="LB"):
    """
    Converts a dictionary of DrawView objects and saves them to a JSON file.

    This function is a one-stop-shop that handles both conversion and file writing.

    Args:
        viewsIdObjectDict (dict): A dictionary where keys are view IDs
            and values are DrawView objects.
        outputJSONFilePath (str or Path): The path to the output JSON file.
        viewsAnchorTag (str, optional): The anchor tag to use for all the
            views. Defaults to "LB".
    """
    # 1. Convert the Python objects to a serializable dictionary.
    drawViewConverter = _DrawViewsSerialize(viewsIdObjectDict=viewsIdObjectDict, viewsAnchorTag=viewsAnchorTag)

    # 2. Write that dictionary to the specified file.
    _createJSONFile(file_path=outputJSONFilePath, data=drawViewConverter.getData())