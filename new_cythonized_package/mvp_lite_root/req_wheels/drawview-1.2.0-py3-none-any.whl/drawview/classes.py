from .view_scale import buildScaleManager
from vct_o_geom.vector import  Vector
from vct_o_geom.rect_2D import  Rect2D
from functools import wraps
def config_required(func):
    """A decorator to ensure scaleConfigDict is set before execution."""
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        if self.scaleConfigDict is None:
            raise ValueError(
                f"Configuration is missing. Cannot run {func.__name__}."
            )
        return func(self, *args, **kwargs)
    return wrapper

class StandardDrawZones(Rect2D):
    """
        StandardDrawZones represents a rectangle drawZones located at Vertical(L,R) /Horizontal(T,B) sides of the DrawView Object.
        This class inheirts the Rect2D class.

        Parameters:
            - drawZoneConfig (dict): A dictionary containing configuration parameters for the drawZone.
            - 'L1' (float): The length of the drawZone along Horizontal(H) extent.
            - 'L2' (float): The length of the drawZone along the Vertical(V) extent.
            - 'anchor_tag' (str): A tag identifying the anchor point of the drawZone.
            - 'anchor_point' (tuple): The coordinates of the anchor point.

        Attributes:
        - Inherits attributes from Rect2D.

        NOTE: A drawView can have zero or more  standard drawZones. (L-drawZone, R-drawZone, T-drawZone, B-drawZone)
    """

    def __init__(self, drawZoneConfig):
        """
           Initializes an instance of the StandardDrawZones class.

           Parameters:
           - drawZoneConfig (dict): A dictionary containing configuration parameters for the  drawZone.
        """
        super().__init__(L1=drawZoneConfig['L1'], L2=drawZoneConfig['L2'], anchor_tag=drawZoneConfig['anchor_tag'],
                         anchor_point=drawZoneConfig['anchor_point'])


class CornerDrawZones(Rect2D):
    """
        CornerDrawZones represents a rectangle drawZones located at corners(LT,RT,RB,LB) of the DrawView Object.
        This class inherits the Rect2D class. This class needs to be enchanted for future scope.
    """

    def __init__(self, drawZoneConfig):
        pass


class DrawView(Rect2D):
    """
    Represents a drawing view, which is a rectangular area on a sheet.
    It can contain drawing zones and can be scaled and positioned.
    """

    def __init__(self, view_name, L1, L2, drawZonesDict, anchor_point:Vector, ctr_view="", rel_order="", scaleConfigDict=None,
                 anchor_tag="CTR",
                 sheet_id: int = None, view_id: int = None, view_scale=1, applyViewScale=True):
        """
        Initializes a DrawView object.

        Args:
            view_name (str): The name of the view.
            L1 (float): The width of the view.
            L2 (float): The height of the view.
            drawZonesDict (dict): A dictionary defining the drawing zones within the view.
            anchor_point (tuple): A tuple (x, y) representing the anchor point of the view.
            ctr_view (str, optional): The center view. Defaults to "".
            rel_order (str, optional): The relative order of the view. Defaults to "".
            scaleConfigDict (dict, optional): A dictionary for scale configuration. Defaults to None.
            anchor_tag (str, optional): The anchor tag for the view. Defaults to "CTR".
            sheet_id (int, optional): The ID of the sheet this view belongs to. Defaults to None.
            view_id (int, optional): The ID of the view. Defaults to None.
            view_scale (int, optional): The scale of the view. Defaults to 1.
            applyViewScale (bool, optional): Whether to apply the view scale to L1 and L2. Defaults to True.
        """
        # L1 corresponds to width and L2 corresponds to height
        newL1, newL2 = L1, L2
        self.view_scale = view_scale
        # Apply view scale to the dimensions if required
        if applyViewScale:
            newL1 = L1 * self.view_scale
            newL2 = L2 * self.view_scale

        self.scaleConfigDict = scaleConfigDict

        # Set default anchor tag if not provided
        if anchor_tag is None:
            anchor_tag = "CTR"

        # Initialize the parent Rect2D class
        if anchor_point[0] is None and anchor_point[1] is None:
            super().__init__(L1=newL1, L2=newL2, anchor_tag=anchor_tag)
        if anchor_point[0] is not None and anchor_point[1] is not None:
            super().__init__(L1=newL1, L2=newL2, anchor_tag=anchor_tag, anchor_point=anchor_point)

        # additional attributes

        self.view_id = view_id
        self.view_name = view_name
        # Initialize drawing zones
        self.drawZones = self.__drawZones(drawZonesDict)

        self.ctr_view = ctr_view
        self.rel_order = rel_order
        self.sheet_id = sheet_id

        # Initialize scale manager if scale configuration is provided
        self.scaleManager = None
        if scaleConfigDict is not None:
            self.scaleManager = buildScaleManager(scaleConfigDict=self.scaleConfigDict)
            # override view's scale to 1 regardless of their view extents
            self.resetViewScaleToOne()

        # Attributes for storing current and next scale values
        self.curValue = None
        self.nextValue = None

    def resetViewScaleToOne(self):
        self.view_scale=1


    @Rect2D.anchor_tag.setter
    def anchor_tag(self, BRectAnchorTag):

        self._anchor_tag = BRectAnchorTag
        self.updateDrawZones()

    @Rect2D.anchor_point.setter
    def anchor_point(self, BRectAnchorPoint):

        self._anchor_point = BRectAnchorPoint
        self.updateDrawZones()

    def updateDrawZones(self):

        for drawZoneName, drawZoneObject in self.drawZones.items():
            getAnchorPoint = {
                'RT': None,
                'RB': None,
                'LT': None,
                'LB': None,
                # consider only DrawView's LB and RT , using anchor_point as reference for various DrawZones
                'L': {'anchor_point': self.basis_point('LB')},
                'R': {'anchor_point': self.basis_point('RT')},
                'T': {'anchor_point': self.basis_point('RT')},
                'B': {'anchor_point': self.basis_point('LB')}

            }
            drawZoneObject._anchor_point = getAnchorPoint[drawZoneName]['anchor_point']
            # print(drawZoneObject.basis_point("RT"),drawZoneObject.basis_point("LB"))

    def __drawZones(self, drawZonesDict: dict):
        dictDrawZones = {}
        # getcurrentAT and AP

        classBuilder = {'L': StandardDrawZones, 'R': StandardDrawZones, 'T': StandardDrawZones, 'B': StandardDrawZones,
                        'RT': CornerDrawZones, 'RB': CornerDrawZones, 'LT': CornerDrawZones, 'LB': CornerDrawZones}

        for drawZoneName, drawZoneExtents in drawZonesDict.items():
            if drawZoneExtents is not None:  # TODO: if extents for LRTB is not given.(L:None) for example
                constructorArgsBuilder = {
                    'RT': None,
                    'RB': None,
                    'LT': None,
                    'LB': None,
                    # consider only DrawView's LB and RT , using anchor_point as reference for various DrawZones
                    'L': {'L1': drawZoneExtents, 'L2': self.L2, 'anchor_tag': 'RB', 'anchor_point': self.basis_point('LB')},
                    'R': {'L1': drawZoneExtents, 'L2': self.L2, 'anchor_tag': 'LT', 'anchor_point': self.basis_point('RT')},
                    'T': {'L1': self.L1, 'L2': drawZoneExtents, 'anchor_tag': 'RB', 'anchor_point': self.basis_point('RT')},
                    'B': {'L1': self.L1, 'L2': drawZoneExtents, 'anchor_tag': 'LT', 'anchor_point': self.basis_point('LB')}

                }

                dictDrawZones[drawZoneName] = classBuilder[drawZoneName](constructorArgsBuilder[drawZoneName])

        return dictDrawZones

    # def shiftSteps(self, directionVector, distance):
    #     self.anchor_point = self.anchor_point.point_at_distance(distance=distance, dir_vector=directionVector)
    ## this shiftSteps is NOW shift for Rect2D class, we override in DrawView class as well.

    def shift(self, dH=0, dV=0):

        super().shift(directionVector=Vector(1, 0), distance=dH)  # shift DrawView object towards right(+ve)/left(-ve) direction.

        super().shift(directionVector=Vector(0, 1), distance=dV)  # shift DrawView object towards top(+ve)/bottom(-ve) direction.

        drawZoneShiftBuilder = {
            "L": {'zoneAnchorTag': 'RB', 'drawViewBasisPoint': 'LB'},
            "R": {'zoneAnchorTag': 'LB', 'drawViewBasisPoint': 'RB'},
            "T": {'zoneAnchorTag': 'LB', 'drawViewBasisPoint': 'LT'},
            "B": {'zoneAnchorTag': 'LT', 'drawViewBasisPoint': 'LB'},
        }

        # shifting the DrawZones of the current DrawView object.
        for zone, drawZoneObj in self.drawZones.items():
            if drawZoneObj is not None:
                drawZoneObj.anchor_tag = drawZoneShiftBuilder[zone]['zoneAnchorTag']
                drawZoneObj.anchor_point = self.basis_point(drawZoneShiftBuilder[zone]['drawViewBasisPoint'])

    def move(self, newSheetId: int):
        """
        The move operation is changing the sheet for the current DrawView object.
        Args:
            newSheetId: The sheetId which the current view will move onto.

        Returns:None

        """

        self.sheet_id = newSheetId

    def scale(self, scaleFactor):
        # scale the drawView using uniform scaling (centralized way)

        self.scale_rect_uniform(scaleFactor=scaleFactor)

        for zone, drawZoneObj in self.drawZones.items():
            if zone in ["L", "R", "T", "B"] and drawZoneObj is not None:

                if zone in ["L", "R"]:  # scale L and R drawZones where width-extent(H) will not change.
                    # changing the height of the drawZones equal to the height of the DrawView
                    drawZoneObj.scale_rect_bv2(scaleFactor=scaleFactor)

                elif zone in ['T', 'B']:  # scale the T and B drawZones where height-extent(V) will not change.
                    # changing the width of the drawZones equal to the width of the DrawView
                    drawZoneObj.scale_rect_bv1(scaleFactor=scaleFactor)

                # TODO: ensuring the DrawZones are intact with the Parent DrawView basis_points

                # adjust the anchor_point of drawZones with reference anchor_point of the DrawView.
                if zone in ['T', 'R']:
                    # T-drawZone RB and R-drawZone LT is same as DrawView's RT

                    drawZoneObj.anchor_point = self.basis_point('RT')

                if zone in ['B', 'L']:
                    # B-drawZone LT and R-drawZone RB is same as DrawView's LB
                    drawZoneObj.anchor_point = self.basis_point('LB')

    def boundingRectangle(self):
        BRect = self
        for zoneName, drawZoneObj in self.drawZones.items():
            if drawZoneObj is not None:
                BRect += drawZoneObj
        return BRect

    def is_overlap(self, other):
        """

        Check if the current rectangle overlaps with another rectangle.

        Args:
            self: The current DrawView object.
            other: The other DrawView object to compare with.

        Returns:
            bool: True if the DrawViews overlap, False otherwise.

        NOTE:
             1) If the DrawViews are just touching to each other at the edges, it will return True.
             2) This overlap check consider rectangle region that covers the DrawView and its DrawZones.

        """

        # we have rectangle which is the summation of the DrawView and its DrawZones
        self_DrawViewAndDrawZones = self.boundingRectangle()
        other_DrawViewAndDrawZones = other.boundingRectangle()
        return self_DrawViewAndDrawZones.is_overlap(other_DrawViewAndDrawZones)

        # self_DrawViewAndDrawZones = self
        # other_DrawViewAndDrawZones = other

        # for zoneName, drawZoneObj in self.drawZones.items():
        #     if drawZoneObj is not None:
        #         self_DrawViewAndDrawZones += drawZoneObj

        #     if drawZoneObj is not None:
        #         other_DrawViewAndDrawZones += drawZoneObj

        # return self_DrawViewAndDrawZones.is_overlap(other_DrawViewAndDrawZones)

    def overlap_extents(self, other):
        """

        Check if the current rectangle overlaps with another rectangle.

        Args:
           self: The current DrawView object.
           other: The other DrawView object to compare with.

        Returns:
           bool: True if the DrawViews overlap, False otherwise.

        NOTE:
            1) If the DrawViews are just touching to each other at the edges, it will return True.
            2) This overlap check consider rectangle region that covers the DrawView and its DrawZones.

        """

        self_DrawViewAndDrawZones = self.boundingRectangle()
        other_DrawViewAndDrawZones = other.boundingRectangle()
        overlap_dH, overlap_dV = self_DrawViewAndDrawZones.overlap_extents(other_DrawViewAndDrawZones)

        return [overlap_dH, overlap_dV]

        # self_DrawViewAndDrawZones = self
        # other_DrawViewAndDrawZones = other
        #
        # for zoneName, drawZoneObj in self.drawZones.items():
        #     if drawZoneObj is not None:
        #         self_DrawViewAndDrawZones += drawZoneObj
        #
        # for zoneName, drawZoneObj in other.drawZones.items():
        #     if drawZoneObj is not None:
        #         other_DrawViewAndDrawZones += drawZoneObj
        # overlap_dH, overlap_dV = self_DrawViewAndDrawZones.overlap_extents(other_DrawViewAndDrawZones)
        #
        # return [overlap_dH, overlap_dV]

    def repositionBRectView(self, BRectAnchorTag: str, BRectTargetAnchorPoint: Vector):
        """
        This function reposition the DrawView based on the bounding rectangle of the DrawView ,specify the BRectAnchorTag and BRectAnchorPoint.


        Args:
            BRectAnchorTag (str): The   anchor tag reference for the view's BRect.
            BRectAnchorPoint (Vector): The   anchor point for the BRect of the view, that requires to reposition the DrawView.
        """

        # store old brectangle information
        oldBRect = self.boundingRectangle()
        oldBRect_LBx, oldBRect_LBy = oldBRect.basis_point('LB')[0], oldBRect.basis_point('LB')[1]

        # store old anchor tag
        oldTag = self.anchor_tag

        # store view position
        viewLBx, viewLBy = self.basis_point('LB')[0], self.basis_point('LB')[1]

        # calculate offset from old DrawView's BRect to DrawView
        viewLB_OffsetX = abs(viewLBx - oldBRect_LBx)
        viewLB_OffsetY = abs(viewLBy - oldBRect_LBy)

        # create   New BRect with given anchor tag and point, keeping its extents same
        newBRect = self.boundingRectangle()
        newBRect.anchor_tag = BRectAnchorTag
        newBRect.anchor_point = BRectTargetAnchorPoint
        # get new LB of new BRect
        newBRect_LBx, newBRect_LBy = newBRect.basis_point('LB')[0], newBRect.basis_point('LB')[1]
        # calculate LB of DrawView position wrt to New BRect
        updatedViewLBx, updatedViewLBy = newBRect_LBx + viewLB_OffsetX, newBRect_LBy + viewLB_OffsetY

        # update anchor tag and point
        self.anchor_tag = 'LB'
        self.anchor_point = Vector(updatedViewLBx, updatedViewLBy)
        self.anchor_point = self.basis_point(oldTag)
        self.anchor_tag = oldTag

    @config_required
    def canNextScale(self):
        """Check if forward scaling is possible."""
        scaleDir = self.scaleManager.incr_dir

        if self.curValue is None:
            return True  # First time, allow scaling

        nextScaleVal = self.scaleManager.nextScale(incr_dir=scaleDir)
        return self.curValue != nextScaleVal  # ✅ Direct equality check

    @config_required
    def applyNextScale(self):
        """Apply forward scaling if possible."""
        scaleDir = self.scaleManager.incr_dir

        if self.curValue is None:
            # First time: Scale from unit scale (1) to start_scale
            self.curValue = 1  # Start with unit scale
            startScale = self.scaleManager.scale_val  # Get start scale
            scaleFactor = startScale / self.curValue
            # print(f"Scaling by: {scaleFactor:.4f}  (First: {startScale} / {self.curValue})")
            self.scale(scaleFactor)

            # Update values for next step
            self.curValue = startScale
            self.scaleManager.scale_val = self.curValue  # ✅ Ensure nextScale() works correctly
            self.nextValue = self.scaleManager.nextScale(incr_dir=scaleDir)
            return True

        if self.canNextScale():
            scaleFactor = self.nextValue / self.curValue
            # print(f"Scaling by: {scaleFactor:.4f}  ({self.nextValue} / {self.curValue})")
            self.scale(scaleFactor)

            # Update values for next step
            self.curValue = self.nextValue  # Move to next scale
            self.scaleManager.scale_val = self.curValue  # ✅ Update scaleManager.scale_val
            self.nextValue = self.scaleManager.nextScale(incr_dir=scaleDir)

            return True  # Scaling performed
        return False  # No scaling needeed

    @config_required
    def canPreviousScale(self):
        """Check if backward scaling is possible."""
        scaleDir = self.scaleManager.incr_dir  # Keep the same direction

        if self.curValue is None:
            return False  # Can't go backward from nothing

        prevScaleVal = self.scaleManager.prevScale(incr_dir=scaleDir)
        return self.curValue != prevScaleVal  # ✅ Direct equality check

    @config_required
    def applyPreviousScale(self):
        """Apply backward scaling if possible."""
        scaleDir = self.scaleManager.incr_dir  # Keep the same direction

        if self.curValue is None:
            return False  # No scale to revert from

        if self.canPreviousScale():
            prevValue = self.scaleManager.prevScale(incr_dir=scaleDir)
            scaleFactor = prevValue / self.curValue
            # print(f"Scaling by: {scaleFactor:.4f}  ({prevValue} / {self.curValue})")
            self.scale(scaleFactor)

            # Update values for next step
            self.curValue = prevValue
            self.scaleManager.scale_val = self.curValue  # ✅ Keep scaleManager in sync
            self.nextValue = self.scaleManager.nextScale(incr_dir=scaleDir)  # Prepare forward step

            return True
        return False


if __name__ == '__main__':

    pass
    # scaleConfigDict = {
    #     "type": "absolute",
    #     "incr_dir": 1,
    #     "start_scale": 0.6,
    #     "scale_type": {
    #         "additive": {
    #
    #             "scale_step": 0.2,
    #             "max_scale": 1.5,
    #             "hard_min_scale": 0.1
    #         },
    #         "multiplicative": {
    #
    #             "scale_step": 0.25,
    #             "max_scale": 0.5,
    #             "hard_min_scale": 0.001
    #         },
    #         "absolute": {
    #             "scale_set": [0.1,0.4, 0.2, 0.6, 1.2, 1.04, 1.5]
    #         }
    #     }
    # }
    # v1=DrawView('demo',100,40,{'L':10,'R':4,'T':6,'B':5},anchor_point=Vector(50,50),anchor_tag='LB',view_id=1,scaleConfigDict=scaleConfigDict)
    # sf1=v1.scaleManager.hard_min_scale
    # v3=copy.deepcopy(v1)
    # v2=copy.deepcopy(v1)
    # print(f'{v2.L1} {v2.L2} {v2.scaleManager.scale_val} scaling by {sf1}')
    # v2.scale(scaleFactor=sf1)
    # print(f'{v2.L1} {v2.L2} {v2.scaleManager.scale_val}')
    # print(f'----------------------------------------------------------')
    #
    #
    # print(f'BEFORE {v3.L1} {v3.L2} scale_val {v3.scaleManager.scale_val}')
    # v3.applyNextScale()
    # print(f'AFTER {v3.L1} {v3.L2} {v3.scaleManager.scale_val}')
    # print()
    # print(f'BEFORE {v3.L1} {v3.L2} scale_val {v3.scaleManager.scale_val}')
    # v3.applyNextScale()
    # print(f'AFTER {v3.L1} {v3.L2} {v3.scaleManager.scale_val}')
    # print()
    # v4=copy.deepcopy(v3)
    # print('f v4 is deep copied v3')
    # while True:
    #     # print(f'BEFORE {v4.L1} {v4.L2} scale_val {v4.scaleManager.scale_val}')
    #     # v4.applyNextScale()
    #     # print(f'AFTER {v4.L1} {v4.L2} {v4.scaleManager.scale_val}')
    #     # print()
    #
    #     print(v4.canNextScale())
    #     if v4.canNextScale():
    #         v4.applyNextScale()
    #     else:
    #         print(v4.scaleManager.scale_val, ' stopped')
    #         break
    #
